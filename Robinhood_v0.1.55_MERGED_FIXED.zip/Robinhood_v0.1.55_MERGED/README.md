# Robinhood

PS4 + PS5 self-hosted WebKit/homebrew host.

## v0.1 foundation

This milestone intentionally contains no real exploit execution.

It provides:
- lightweight static UI
- explicit compatibility database
- firmware-routing foundation
- mock/research entries
- Normal / Advanced / Research UI structure
- local static host
- build tooling
- compatibility tests
- provenance/licensing documentation structure

## Targets

- PS4: research target through 12.52
- PS5: evidence-driven support, research ceiling 12.52

See `docs/ARCHITECTURE.md` and `docs/COMPATIBILITY.md`.


## Cinematic PS4 operations theme
The UI uses the supplied PS4 jailbreak visual direction with the supplied cinematic operations wallpaper, dark glass panels, blue console-style header, and high-contrast terminal states.


## v0.1.55 merged hardening layer

This release combines the Robinhood v0.1.54 evidence-driven compatibility foundation with the Nemotron engineering-hardening layer. Robinhood remains the canonical research/provenance surface; the hardening layer adds adapter state tracking, payload integrity gates, deterministic routing, evidence promotion, failure-first tests, diagnostics, and CI packaging.

**Important:** passing software tests does not constitute hardware verification. `SIMULATED`, `UNVERIFIED`, `RESEARCH_ONLY`, and hardware-validation states remain explicitly separated.

See `MERGE_MANIFEST.json` and `NEMOTRON_HARDENING_REPORT.md` for the merge boundary and hardening audit.

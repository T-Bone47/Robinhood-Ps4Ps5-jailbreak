from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)

server = ThreadingHTTPServer(("0.0.0.0", 8080), SimpleHTTPRequestHandler)

print("Robinhood local host")
print("Local: http://127.0.0.1:8080")
print("LAN:   http://<this-PC-LAN-IP>:8080")
print("Press Ctrl+C to stop.")

try:
    server.serve_forever()
except KeyboardInterrupt:
    print("\nStopping Robinhood host.")
finally:
    server.server_close()

(function () {
  const db = window.ROBINHOOD_COMPATIBILITY || [];
  const consoleEl = document.getElementById("console");
  const firmwareEl = document.getElementById("firmware");
  const check = document.getElementById("check");
  const headline = document.getElementById("headline");
  const status = document.getElementById("status");
  const resultCard = document.getElementById("result-card");
  const result = document.getElementById("result");
  const detailsCard = document.getElementById("details-card");
  const details = document.getElementById("details");

  function parseFirmware(value) {
    const raw = String(value || "").trim();
    const match = raw.match(/^(\d+)(?:\.(\d{1,2}))?$/);
    if (!match) return null;
    const major = Number(match[1]);
    const minor = Number((match[2] || "0").padEnd(2, "0"));
    return { raw, numeric: major + minor / 100 };
  }

  function resolve(consoleName, firmwareInput) {
    const firmware = parseFirmware(firmwareInput);
    if (!firmware) return null;

    return db.find(item =>
      item.console === consoleName &&
      firmware.numeric >= item.min_firmware &&
      firmware.numeric <= item.max_firmware
    ) || null;
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;");
  }

  function render(entry, firmwareInput) {
    const presentation = routePresentation(entry);
    resultCard.classList.remove("hidden");
    headline.textContent = presentation.badge;
    status.textContent = presentation.message;

    const rows = [
      ["Console", entry?.console || consoleEl.value],
      ["Firmware", firmwareInput],
      ["State", presentation.title],
      ["Entry route", entry?.entry_route || "UNRESOLVED"],
      ["WebKit", entry?.components?.webkit || "UNRESOLVED"],
      ["Kernel", entry?.components?.kernel || "UNRESOLVED"],
      ["HEN", entry?.components?.hen || entry?.hen || "UNRESOLVED"],
      ["Loader", entry?.components?.loader || entry?.loader || "UNRESOLVED"],
      ["Reliability", entry?.reliability || "UNKNOWN"],
      ["Evidence", entry?.evidence_level || "UNKNOWN"]
    ];

    result.innerHTML = rows.map(([key, value]) =>
      "<div class='result-row'><strong>" + escapeHtml(key) +
      ":</strong> " + escapeHtml(value) + "</div>"
    ).join("");

    if (presentation.action === "PREPARE") {
      result.innerHTML += "<div class='action-note'>Verified route: preparation can be exposed after final integration.</div>";
    } else {
      result.innerHTML += "<div class='action-note'>Execution is intentionally unavailable for this research state.</div>";
    }

    details.textContent = entry
      ? JSON.stringify(entry, null, 2)
      : JSON.stringify({
          console: consoleEl.value,
          firmware: firmwareInput,
          status: "UNKNOWN",
          action: "NONE"
        }, null, 2);
  }

  check.addEventListener("click", function () {
    const parsed = parseFirmware(firmwareEl.value);
    if (!parsed) {
      render(null, firmwareEl.value);
      headline.textContent = "INVALID";
      status.textContent = "Enter a firmware such as 9.00 or 12.52.";
      return;
    }
    render(resolve(consoleEl.value, firmwareEl.value), firmwareEl.value);
  });

  document.querySelectorAll("[data-mode]").forEach(button => {
    button.addEventListener("click", () => {
      detailsCard.classList.remove("hidden");
      if (button.dataset.mode === "research") {
        details.textContent = JSON.stringify({
          mode: "research",
          source_policy: "Upstream source evidence first",
          status_policy: "UNKNOWN is never inferred",
          current_database_entries: db.length
        }, null, 2);
      } else {
        details.textContent = JSON.stringify({
          mode: "advanced",
          fields: ["entry_route","components","prerequisites","source_ids","evidence_level","reliability"]
        }, null, 2);
      }
    });
  });
})();

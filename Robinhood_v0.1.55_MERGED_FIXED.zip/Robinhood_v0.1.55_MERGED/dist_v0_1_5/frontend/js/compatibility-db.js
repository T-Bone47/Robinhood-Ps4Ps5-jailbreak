window.ROBINHOOD_COMPATIBILITY = [
  {
    "console": "PS4",
    "firmware": "7.00",
    "min_firmware": 7.0,
    "max_firmware": 7.0,
    "status": "PARTIAL",
    "reliability": "UNKNOWN",
    "chain": "ps4-pppwn",
    "hen": null,
    "loader": null,
    "payloads": [],
    "offline": false,
    "summary": "Kernel RCE PoC is documented upstream; complete Robinhood HEN route is not yet integrated.",
    "source_ids": [
      "github-pppwn"
    ],
    "last_verified": "2026-08-25",
    "entry_route": "ps4-pppwn",
    "prerequisites": [],
    "evidence_level": "DATABASE_ENTRY",
    "components": {
      "webkit": null,
      "kernel": null,
      "hen": null,
      "loader": null,
      "payloads": []
    }
  },
  {
    "console": "PS4",
    "firmware": "9.00",
    "min_firmware": 9.0,
    "max_firmware": 9.0,
    "status": "PARTIAL",
    "reliability": "UNKNOWN",
    "chain": "ps4-pppwn",
    "hen": "goldhen",
    "loader": null,
    "payloads": [],
    "offline": false,
    "summary": "PPPwn and GoldHEN are independently documented for this firmware; Robinhood has not yet integrated a complete execution route.",
    "source_ids": [
      "github-pppwn",
      "github-goldhen-releases"
    ],
    "last_verified": "2026-08-25",
    "entry_route": "ps4-pppwn",
    "prerequisites": [],
    "evidence_level": "DATABASE_ENTRY",
    "components": {
      "webkit": null,
      "kernel": null,
      "hen": "goldhen",
      "loader": null,
      "payloads": []
    }
  },
  {
    "console": "PS4",
    "firmware": "11.00",
    "min_firmware": 11.0,
    "max_firmware": 11.0,
    "status": "PARTIAL",
    "reliability": "UNKNOWN",
    "chain": "ps4-pppwn",
    "hen": "goldhen",
    "loader": null,
    "payloads": [],
    "offline": false,
    "summary": "PPPwn and GoldHEN are independently documented for this firmware; Robinhood has not yet integrated a complete execution route.",
    "source_ids": [
      "github-pppwn",
      "github-goldhen-releases"
    ],
    "last_verified": "2026-08-25",
    "entry_route": "ps4-pppwn",
    "prerequisites": [],
    "evidence_level": "DATABASE_ENTRY",
    "components": {
      "webkit": null,
      "kernel": null,
      "hen": "goldhen",
      "loader": null,
      "payloads": []
    }
  },
  {
    "console": "PS4",
    "firmware": "12.52",
    "min_firmware": 12.52,
    "max_firmware": 12.52,
    "status": "UNKNOWN",
    "reliability": "UNKNOWN",
    "chain": null,
    "hen": null,
    "loader": null,
    "payloads": [],
    "offline": false,
    "summary": "Project target only. No verified Robinhood route recorded yet.",
    "source_ids": [],
    "last_verified": "2026-08-25",
    "entry_route": null,
    "prerequisites": [],
    "evidence_level": "DATABASE_ENTRY",
    "components": {
      "webkit": null,
      "kernel": null,
      "hen": null,
      "loader": null,
      "payloads": []
    }
  },
  {
    "console": "PS5",
    "firmware": "9.00-10.01",
    "min_firmware": 9.0,
    "max_firmware": 10.01,
    "status": "VERIFIED",
    "reliability": "EXPERIMENTAL",
    "chain": "ps5-webkit-autoloader",
    "hen": null,
    "loader": "ps5-webkit-autoloader",
    "payloads": [],
    "offline": true,
    "summary": "Upstream WebKit Autoloader documentation covers 9.00-12.00, but this Robinhood entry is intentionally capped at 10.01 to avoid overlapping the separate P2JB route until the complete routing evidence is reconciled.",
    "source_ids": [
      "github-ps5-webkit-autoloader"
    ],
    "last_verified": "2026-08-25",
    "entry_route": "ps5-webkit-autoloader",
    "prerequisites": [],
    "evidence_level": "UPSTREAM_REPOSITORY",
    "components": {
      "webkit": "slopkit",
      "kernel": "autoloader-integrated",
      "hen": null,
      "loader": "ps5-webkit-autoloader",
      "payloads": []
    }
  },
  {
    "console": "PS5",
    "firmware": "7.00",
    "min_firmware": 7.0,
    "max_firmware": 8.6,
    "status": "EXPERIMENTAL",
    "reliability": "UNKNOWN",
    "chain": "ps5-webkit-autoloader-7-8x",
    "hen": null,
    "loader": "ps5-webkit-autoloader",
    "payloads": [],
    "offline": true,
    "summary": "Pre-release support announced by the project maintainer; keep separate from stable 9.00-12.00 support.",
    "source_ids": [
      "github-ps5-autoloader-discussion"
    ],
    "last_verified": "2026-08-25",
    "entry_route": "ps5-webkit-autoloader-7-8x",
    "prerequisites": [],
    "evidence_level": "DATABASE_ENTRY",
    "components": {
      "webkit": null,
      "kernel": null,
      "hen": null,
      "loader": "ps5-webkit-autoloader",
      "payloads": []
    }
  },
  {
    "console": "PS5",
    "firmware": "10.02-12.70",
    "min_firmware": 10.02,
    "max_firmware": 12.7,
    "status": "REPORTED",
    "reliability": "UNKNOWN",
    "chain": "ps5-y2jb-autoloader",
    "entry_route": "ps5-y2jb-autoloader",
    "hen": null,
    "loader": "ps5-y2jb-autoloader",
    "payloads": [],
    "offline": true,
    "prerequisites": [],
    "evidence_level": "UPSTREAM_RELEASE_PLUS_COMMUNITY_TESTING",
    "summary": "Upstream release notes add P2JB above 10.01 through 12.70. Public testing shows firmware-specific success and failure; Robinhood does not yet promote the whole range to VERIFIED.",
    "source_ids": [
      "github-ps5-y2jb-autoloader",
      "github-ps5-y2jb-releases",
      "github-ps5-y2jb-testing"
    ],
    "last_verified": "2026-08-25",
    "components": {
      "webkit": "Y2JB entry",
      "kernel": "P2JB/Lapse depending on firmware",
      "hen": null,
      "loader": "ps5-y2jb-autoloader",
      "payloads": []
    }
  }
];


from pathlib import Path
import hashlib,json,sys

ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/"database"
snap=json.loads((DB/"AUDIT-SNAPSHOT.json").read_text())
errors=[]

for rel,meta in snap["database_files"].items():
    p=DB/rel
    if not p.exists():
        errors.append("missing: "+rel)
        continue
    raw=p.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=meta["sha256"]:
        errors.append("changed: "+rel)
    if len(raw)!=meta["bytes"]:
        errors.append("size changed: "+rel)

if errors:
    print("AUDIT SNAPSHOT: CHANGED")
    print("\n".join(errors))
    sys.exit(1)

print("AUDIT SNAPSHOT: MATCH")
print(f"Files checked: {len(snap['database_files'])}")

#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import socket

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist_v0_1_9"

if not DIST.exists():
    raise SystemExit("dist_v0_1_9 does not exist. Run the build step first.")

class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print(fmt % args)

def local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("192.0.2.1", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()

server = ThreadingHTTPServer(("0.0.0.0", 8080), QuietHandler)
server.RequestHandlerClass.directory = str(DIST)
print("Robinhood static LAN host")
print(f"Local: http://127.0.0.1:8080/")
print(f"LAN:   http://{local_ip()}:8080/")
print("Press Ctrl+C to stop.")
server.serve_forever()


from pathlib import Path
import json, subprocess, datetime

ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/"database"
status=json.loads((ROOT/"project-status.json").read_text())
compat=json.loads((DB/"compatibility.json").read_text())
sources=json.loads((DB/"sources.json").read_text())
repos=json.loads((DB/"repositories.json").read_text())
claims=json.loads((DB/"claim-ledger.json").read_text())

counts={}
for r in compat:
    s=r.get("status","UNKNOWN")
    counts[s]=counts.get(s,0)+1

report={
    "project":"Robinhood",
    "generated":"2026-08-26",
    "checkpoint":status.get("checkpoint"),
    "version":status.get("version"),
    "execution_enabled":False,
    "research_summary":{
        "compatibility_routes":len(compat),
        "sources":len(sources),
        "repositories":len(repos),
        "claims":len(claims),
        "status_counts":counts
    },
    "quality_gates":{
        "database_validation":"REQUIRED",
        "release_preflight":"REQUIRED",
        "data_integrity":"REQUIRED",
        "static_host_smoke":"REQUIRED",
        "hardware_validation":"NOT_COMPLETED_BY_AUTOMATION"
    },
    "release_statement":"RESEARCH BUILD — NOT A CLAIM OF HARDWARE JAILBREAK SUCCESS"
}
(DB/"RELEASE-CANDIDATE-AUDIT.json").write_text(json.dumps(report,indent=2)+"\n")
print("Audit report generated.")

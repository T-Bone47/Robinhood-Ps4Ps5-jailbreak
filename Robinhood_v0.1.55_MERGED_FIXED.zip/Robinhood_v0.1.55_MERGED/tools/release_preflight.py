
from pathlib import Path
import json, sys

ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/"database"

compat=json.loads((DB/"compatibility.json").read_text())
sources=json.loads((DB/"sources.json").read_text())
source_ids={s["source_id"] for s in sources}
errors=[]

seen=[]
for r in compat:
    key=(r.get("console"),r.get("min_firmware"),r.get("max_firmware"),r.get("chain"))
    if key in seen:
        errors.append(f"duplicate route: {key}")
    seen.append(key)

    for sid in r.get("source_ids",[]):
        if sid not in source_ids:
            errors.append(f"unknown source {sid} for {key}")

    if r.get("status")=="VERIFIED" and r.get("evidence_grade")!="PRIMARY_VERIFIED":
        errors.append(f"verified route lacks PRIMARY_VERIFIED grade: {key}")

    if r.get("status")=="REPORTED" and r.get("evidence_grade")=="PRIMARY_VERIFIED":
        errors.append(f"reported route incorrectly graded verified: {key}")

if errors:
    print("RELEASE PREFLIGHT: FAIL")
    print("\n".join(errors))
    sys.exit(1)

print("RELEASE PREFLIGHT: PASS")
print(f"Routes checked: {len(compat)}")
print(f"Sources checked: {len(sources)}")

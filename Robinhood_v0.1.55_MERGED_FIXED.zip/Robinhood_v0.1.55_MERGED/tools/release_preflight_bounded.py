
from pathlib import Path
import subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
cmd=[sys.executable,"tools/release_preflight.py"]
try:
    p=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True,timeout=30)
except subprocess.TimeoutExpired:
    print("RELEASE_PREFLIGHT: TIMEOUT after 30 seconds")
    sys.exit(124)

print(p.stdout,end="")
print(p.stderr,end="",file=sys.stderr)
sys.exit(p.returncode)

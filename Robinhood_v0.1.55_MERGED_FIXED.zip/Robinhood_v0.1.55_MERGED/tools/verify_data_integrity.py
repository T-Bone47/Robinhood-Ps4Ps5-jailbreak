
from pathlib import Path
import hashlib, json, sys

ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/"database"
manifest=json.loads((DB/"DATA-INTEGRITY-MANIFEST.json").read_text())
errors=[]

for rel, meta in manifest["files"].items():
    p=DB/rel
    if not p.exists():
        errors.append(f"missing: {rel}")
        continue
    raw=p.read_bytes()
    digest=hashlib.sha256(raw).hexdigest()
    if digest != meta["sha256"]:
        errors.append(f"hash mismatch: {rel}")
    if len(raw) != meta["bytes"]:
        errors.append(f"size mismatch: {rel}")

if errors:
    print("DATA INTEGRITY: FAIL")
    print("\n".join(errors))
    sys.exit(1)

print("DATA INTEGRITY: PASS")
print(f"Files verified: {len(manifest['files'])}")

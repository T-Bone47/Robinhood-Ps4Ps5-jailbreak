from pathlib import Path
import hashlib
import json
import shutil
import zipfile
import subprocess

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist_release"
VERSION = json.loads((ROOT/"release.json").read_text())["version"]

if DIST.exists():
    shutil.rmtree(DIST)
DIST.mkdir(parents=True)

include = [
    "index.html",
    "frontend",
    "database",
    "deployment.json",
    "release.json"
]

for rel in include:
    src, dst = ROOT/rel, DIST/rel
    if src.is_dir():
        shutil.copytree(src, dst)
    else:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

# Hash every release file.
entries = []
for p in sorted(DIST.rglob("*")):
    if p.is_file():
        entries.append({
            "path": str(p.relative_to(DIST)).replace("\\", "/"),
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
            "bytes": p.stat().st_size
        })

manifest = {
    "product": "Robinhood",
    "version": VERSION,
    "files": entries
}
(DIST/"RELEASE-MANIFEST.json").write_text(
    json.dumps(manifest, indent=2)+"\n", encoding="utf-8"
)

# Package the exact distribution.
zip_path = ROOT.parent / f"Robinhood-{VERSION}.zip"
if zip_path.exists():
    zip_path.unlink()

with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
    for p in DIST.rglob("*"):
        if p.is_file():
            z.write(p, p.relative_to(DIST))

print(f"Release built: {DIST}")
print(f"Package: {zip_path}")
print(f"Files: {len(entries)}")

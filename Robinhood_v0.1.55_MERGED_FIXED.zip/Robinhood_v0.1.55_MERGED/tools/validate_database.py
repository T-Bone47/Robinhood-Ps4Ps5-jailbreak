import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
db = json.loads((ROOT / "database/compatibility.json").read_text(encoding="utf-8"))

statuses = {
    "VERIFIED", "PARTIAL", "EXPERIMENTAL", "REPORTED",
    "UNSUPPORTED", "UNKNOWN", "RESEARCH_ENTRY", "RESEARCH_TARGET"
}
reliability = {"EXCELLENT", "GOOD", "MODERATE", "POOR", "EXPERIMENTAL", "UNKNOWN"}

errors = []

for i, item in enumerate(db):
    prefix = f"entry[{i}]"
    if item.get("console") not in {"PS4", "PS5"}:
        errors.append(f"{prefix}: invalid console")
    if item.get("status") not in statuses:
        errors.append(f"{prefix}: invalid status")
    if item.get("reliability") not in reliability:
        errors.append(f"{prefix}: invalid reliability")
    if not isinstance(item.get("source_ids"), list):
        errors.append(f"{prefix}: source_ids must be a list")
    if item.get("min_firmware") is None or item.get("max_firmware") is None:
        errors.append(f"{prefix}: missing firmware bounds")
    elif item["min_firmware"] > item["max_firmware"]:
        errors.append(f"{prefix}: invalid firmware range")
    if item.get("status") == "VERIFIED" and not item.get("source_ids"):
        errors.append(f"{prefix}: VERIFIED entry has no source evidence")

# Overlapping ranges are valid when they represent alternative routes.
# Only overlapping VERIFIED routes are a database error; non-verified overlaps
# are deliberately surfaced to the router as ambiguity/research choices.
warnings = []
for i, a in enumerate(db):
    for j, b in enumerate(db):
        if j <= i or a.get("console") != b.get("console"):
            continue
        if a.get("min_firmware") is None or b.get("min_firmware") is None:
            continue
        overlap = max(a["min_firmware"], b["min_firmware"]) <= min(
            a["max_firmware"], b["max_firmware"]
        )
        if overlap and a.get("route_type", "EXPLOIT_CHAIN") == b.get("route_type", "EXPLOIT_CHAIN"):
            if a.get("status") == "VERIFIED" and b.get("status") == "VERIFIED":
                errors.append(
                    f"verified overlap: {a['console']} {a['firmware']} and {b['firmware']}"
                )
            else:
                warnings.append(
                    f"route overlap (non-verified): {a['console']} {a['firmware']} and {b['firmware']}"
                )

if errors:
    print("DATABASE VALIDATION: FAIL")
    for error in errors:
        print("-", error)
    raise SystemExit(1)

print("DATABASE VALIDATION: PASS")
if warnings:
    print("DATABASE VALIDATION WARNINGS:")
    for warning in warnings:
        print("-", warning)

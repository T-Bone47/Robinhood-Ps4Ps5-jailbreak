from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"

if DIST.exists():
    for child in list(DIST.iterdir()):
        if child.is_dir():
            shutil.rmtree(child, ignore_errors=True)
        else:
            try:
                child.unlink()
            except PermissionError:
                pass
else:
    DIST.mkdir(parents=True)

for rel in ["index.html", "frontend", "database"]:
    src = ROOT / rel
    dst = DIST / rel
    if src.is_dir():
        if dst.exists():
            shutil.rmtree(dst, ignore_errors=True)
        shutil.copytree(src, dst)
    else:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

print(f"Built static Robinhood package at {DIST}")

from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT/"dist_release"

if not DIST.exists():
    raise SystemExit("dist_release missing")

manifest = json.loads((DIST/"RELEASE-MANIFEST.json").read_text())
errors = []

for item in manifest["files"]:
    p = DIST/item["path"]
    if not p.exists():
        errors.append(f"missing: {item['path']}")
        continue
    digest = hashlib.sha256(p.read_bytes()).hexdigest()
    if digest != item["sha256"]:
        errors.append(f"hash mismatch: {item['path']}")
    if p.stat().st_size != item["bytes"]:
        errors.append(f"size mismatch: {item['path']}")

if errors:
    print("RELEASE VERIFICATION: FAIL")
    print("\n".join(errors))
    raise SystemExit(1)

print("RELEASE VERIFICATION: PASS")
print(f"Verified files: {len(manifest['files'])}")

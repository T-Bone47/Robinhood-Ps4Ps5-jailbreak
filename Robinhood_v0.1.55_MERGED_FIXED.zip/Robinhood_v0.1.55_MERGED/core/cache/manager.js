const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class CacheManager {
  constructor(cacheDir = path.join(__dirname, '..', '..', 'dist', 'cache')) {
    this.cacheDir = cacheDir;
    this.manifestPath = path.join(cacheDir, 'manifest.json');
    this.manifest = { files: {}, version: '1.0.0', generated: new Date().toISOString() };
  }

  async init() {
    if (!fs.existsSync(this.cacheDir)) {
      fs.mkdirSync(this.cacheDir, { recursive: true });
    }
    if (fs.existsSync(this.manifestPath)) {
      this.manifest = JSON.parse(fs.readFileSync(this.manifestPath, 'utf8'));
    }
  }

  async addFile(relPath, content) {
    const fullPath = path.join(this.cacheDir, relPath);
    const dir = path.dirname(fullPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    const buffer = Buffer.isBuffer(content) ? content : Buffer.from(content);
    fs.writeFileSync(fullPath, buffer);
    
    const hash = crypto.createHash('sha256').update(buffer).digest('hex');
    const stats = fs.statSync(fullPath);
    
    this.manifest.files[relPath] = {
      size: stats.size,
      sha256: hash,
      version: this.manifest.version
    };
    
    return { path: relPath, size: stats.size, sha256: hash };
  }

  async getFile(relPath) {
    const fullPath = path.join(this.cacheDir, relPath);
    if (!fs.existsSync(fullPath)) return null;
    return fs.readFileSync(fullPath);
  }

  async verifyIntegrity() {
    const results = { valid: true, errors: [] };
    
    for (const [relPath, meta] of Object.entries(this.manifest.files)) {
      const fullPath = path.join(this.cacheDir, relPath);
      if (!fs.existsSync(fullPath)) {
        results.valid = false;
        results.errors.push(`Missing file: ${relPath}`);
        continue;
      }
      
      const buffer = fs.readFileSync(fullPath);
      const hash = crypto.createHash('sha256').update(buffer).digest('hex');
      
      if (hash !== meta.sha256) {
        results.valid = false;
        results.errors.push(`Checksum mismatch: ${relPath}`);
      }
      
      if (buffer.length !== meta.size) {
        results.valid = false;
        results.errors.push(`Size mismatch: ${relPath}`);
      }
    }
    
    return results;
  }

  async saveManifest() {
    this.manifest.generated = new Date().toISOString();
    fs.writeFileSync(this.manifestPath, JSON.stringify(this.manifest, null, 2));
  }

  getManifest() {
    return this.manifest;
  }
}

module.exports = CacheManager;
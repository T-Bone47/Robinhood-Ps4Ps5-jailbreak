
const STATES = Object.freeze([
  "OFFLINE_READY",
  "HOST_READY",
  "ROUTE_SELECTED",
  "EXECUTION_WAITING",
  "ENTRY_RUNNING",
  "KERNEL_RUNNING",
  "PAYLOAD_RUNNING",
  "COMPLETE",
  "FAILED"
]);

function validateHostConfig(config) {
  const errors=[];
  if (!config || config.protocol !== "http") errors.push("Host must use HTTP for local-browser compatibility.");
  if (!Number.isInteger(config.port) || config.port < 1024 || config.port > 65535)
    errors.push("Invalid local host port.");
  if (!config.bindAddress) errors.push("Bind address is required.");
  if (config.executionAdapterRequired !== true)
    errors.push("Execution adapter gate must be enabled.");
  return {valid:errors.length===0,errors};
}

function eventAccepted(event) {
  return !!event &&
    typeof event.type === "string" &&
    typeof event.routeId === "string";
}

module.exports={STATES,validateHostConfig,eventAccepted};


const REQUIRED=[
  "recordId","console","firmware","routeId","adapterVersion",
  "testDate","environment","steps","observations","result","operator"
];
const RESULTS=["PASS","FAIL","INCONCLUSIVE"];

function validate(record){
  const errors=[];
  if(!record || typeof record!=="object") return {valid:false,errors:["Missing validation record."]};
  for(const k of REQUIRED) if(record[k]===undefined || record[k]===null || record[k]==="") errors.push(`Missing ${k}.`);
  if(record && !RESULTS.includes(record.result)) errors.push("Invalid validation result.");
  if(record && !Array.isArray(record.steps)) errors.push("steps must be an array.");
  if(record && !Array.isArray(record.observations)) errors.push("observations must be an array.");
  return {valid:errors.length===0,errors};
}
function canPromote(record){
  const v=validate(record);
  return v.valid && record.result==="PASS";
}
module.exports={validate,canPromote};

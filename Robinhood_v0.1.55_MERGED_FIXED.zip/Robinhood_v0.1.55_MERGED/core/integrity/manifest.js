const crypto = require("crypto");

function sha256(text) {
  return crypto.createHash("sha256").update(text).digest("hex");
}

function buildManifest(files) {
  const manifest = {};
  for (const [name, content] of Object.entries(files)) {
    manifest[name] = {
      sha256: sha256(content),
      bytes: Buffer.byteLength(content)
    };
  }
  return manifest;
}

module.exports = { sha256, buildManifest };

const { PayloadAdapter, BinAdapter, ElfAdapter, EmbeddedAdapter, NetworkAdapter } = require('../exploit-router/adapters/PayloadAdapter');
const { MockBinAdapter, MockElfAdapter } = require('../exploit-router/adapters/MockPayloadAdapter');
const ElfLoaderAdapter = require('./loaders/ElfLoaderAdapter');
const BinLoaderAdapter = require('./loaders/BinLoaderAdapter');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class PayloadManager {
  constructor(options = {}) {
    this.adapters = new Map();
    this.loaders = new Map();
    this.payloadsDB = null;
    this.payloadsDir = options.payloadsDir || path.join(__dirname, '..', '..', 'dist', 'payloads');
    this.registerDefaultAdapters();
    this.registerDefaultLoaders();
  }

  registerDefaultAdapters() {
    this.adapters.set('BIN', new BinAdapter({ format: 'BIN' }));
    this.adapters.set('ELF', new ElfAdapter({ format: 'ELF' }));
    this.adapters.set('EMBEDDED', new EmbeddedAdapter({ format: 'EMBEDDED' }));
    this.adapters.set('NETWORK', new NetworkAdapter({ format: 'NETWORK' }));
    
    this.adapters.set('MOCK_BIN', new MockBinAdapter({ format: 'BIN' }));
    this.adapters.set('MOCK_ELF', new MockElfAdapter({ format: 'ELF' }));
  }

  registerDefaultLoaders() {
    this.loaders.set('BIN', new BinLoaderAdapter({ format: 'BIN' }));
    this.loaders.set('ELF', new ElfLoaderAdapter({ format: 'ELF' }));
  }

  registerAdapter(name, adapter) {
    this.adapters.set(name.toUpperCase(), adapter);
  }

  registerLoader(name, loader) {
    this.loaders.set(name.toUpperCase(), loader);
  }

  getAdapter(format) {
    return this.adapters.get(format.toUpperCase()) || this.adapters.get(`MOCK_${format.toUpperCase()}`);
  }

  getLoader(format) {
    return this.loaders.get(format.toUpperCase());
  }

  async loadPayloadsDB(dbPath = null) {
    if (this.payloadsDB) return this.payloadsDB;
    
    const dbFile = dbPath || path.join(__dirname, '..', '..', 'database', 'payloads.json');
    this.payloadsDB = JSON.parse(fs.readFileSync(dbFile, 'utf8'));
    return this.payloadsDB;
  }

  // Verify payload checksum against database
  async verifyChecksum(payload, expectedSha256) {
    const hash = crypto.createHash('sha256').update(payload).digest('hex');
    return hash === expectedSha256.toLowerCase();
  }

  // Find payload in database by ID (sync - assumes DB already loaded)
  findPayload(payloadId) {
    if (!this.payloadsDB) this.loadPayloadsDB();
    return this.payloadsDB.find(p => p.payload_id === payloadId) || null;
  }

  // Find payloads compatible with console/firmware (sync - assumes DB already loaded)
  findCompatiblePayloads(console, firmware, format = null) {
    if (!this.payloadsDB) this.loadPayloadsDB();
    return this.payloadsDB.filter(p => 
      p.console === console && 
      p.firmware_range.includes(firmware) &&
      p.status === 'VERIFIED' &&
      (!format || p.format === format)
    );
  }

  // Fetch payload from local dist/payloads/ directory
  async fetchPayload(payloadId) {
    await this.loadPayloadsDB();
    const payloadMeta = await this.findPayload(payloadId);
    if (!payloadMeta) {
      throw new Error(`Payload not found in database: ${payloadId}`);
    }

    // Try to load from dist/payloads/
    const payloadPath = path.join(this.payloadsDir, `${payloadId}.${payloadMeta.format.toLowerCase()}`);
    
    if (!fs.existsSync(payloadPath)) {
      throw new Error(`Payload file not found: ${payloadPath}`);
    }

    const payloadBuffer = fs.readFileSync(payloadPath);
    
    // Verify checksum
    const valid = await this.verifyChecksum(payloadBuffer, payloadMeta.sha256);
    if (!valid) {
      throw new Error(`Checksum mismatch for payload ${payloadId}. Expected ${payloadMeta.sha256}`);
    }

    return {
      meta: payloadMeta,
      data: payloadBuffer
    };
  }

  async validatePayload(payload, format) {
    const adapter = this.getAdapter(format);
    if (!adapter) throw new Error(`No adapter for format: ${format}`);
    return adapter.validate(payload);
  }

  async preparePayload(payload, format) {
    const adapter = this.getAdapter(format);
    if (!adapter) throw new Error(`No adapter for format: ${format}`);
    return adapter.prepare(payload);
  }

  async loadPayload(payload, format) {
    const adapter = this.getAdapter(format);
    if (!adapter) throw new Error(`No adapter for format: ${format}`);
    return adapter.load(payload);
  }

  // High-level: fetch, verify, and deliver payload
  async deliverPayload(payloadId, targetOptions = {}) {
    const { meta, data } = await this.fetchPayload(payloadId);
    const loader = this.getLoader(meta.format);
    
    if (!loader) {
      throw new Error(`No loader for format: ${meta.format}`);
    }

    return loader.load(data, targetOptions);
  }

  getSupportedFormats() {
    return Array.from(this.adapters.keys()).filter(k => !k.startsWith('MOCK_'));
  }

  getSupportedLoaders() {
    return Array.from(this.loaders.keys());
  }
}

module.exports = PayloadManager;
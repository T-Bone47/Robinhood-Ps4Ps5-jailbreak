/**
 * Browser Diagnostics Validator
 * Pre-flight checks for console browser readiness
 */

class DiagnosticsValidator {
  constructor() {
    this.checks = [];
    this.results = {};
  }

  async runAllChecks() {
    this.checks = [
      this.checkServiceWorker.bind(this),
      this.checkCacheStorage.bind(this),
      this.checkWebKitEnvironment.bind(this),
      this.checkMemoryPressure.bind(this),
      this.checkFirmwareMatch.bind(this),
      this.checkCompatibility.bind(this),
    ];

    this.results = {};
    for (const check of this.checks) {
      try {
        const result = await check();
        this.results[result.name] = result;
      } catch (err) {
        this.results[check.name] = { name: check.name, status: 'error', message: err.message };
      }
    }
    return this.results;
  }

  async checkServiceWorker() {
    const name = 'serviceWorker';
    if (!('serviceWorker' in navigator)) {
      return { name, status: 'fail', message: 'Service Worker not supported', critical: true };
    }

    try {
      const registration = await navigator.serviceWorker.ready;
      if (registration.active) {
        return { name, status: 'pass', message: 'Service Worker active and controlling page' };
      }
      return { name, status: 'warn', message: 'Service Worker registered but not active' };
    } catch (err) {
      return { name, status: 'fail', message: `Service Worker error: ${err.message}`, critical: true };
    }
  }

  async checkCacheStorage() {
    const name = 'cacheStorage';
    if (!('caches' in window)) {
      return { name, status: 'fail', message: 'Cache Storage API not available', critical: true };
    }

    try {
      const cacheNames = await caches.keys();
      const robinhoodCache = cacheNames.find(name => name.startsWith('robinhood-'));
      
      if (!robinhoodCache) {
        return { name, status: 'fail', message: 'Robinhood cache not found', critical: true };
      }

      const cache = await caches.open(robinhoodCache);
      const keys = await cache.keys();
      const requiredFiles = [
        '/index.html',
        '/database/ps4.json',
        '/database/ps5.json',
        '/database/exploit-chains.json',
        '/database/hen.json',
        '/database/payloads.json',
        '/database/sources.json',
        '/frontend/js/app.js',
        '/frontend/js/service-worker.js',
      ];

      const missing = requiredFiles.filter(req => 
        !keys.some(k => k.url.includes(req))
      );

      if (missing.length === 0) {
        return { name, status: 'pass', message: `All ${requiredFiles.length} critical files cached` };
      }
      return { name, status: 'warn', message: `${missing.length} files missing from cache`, details: missing };
    } catch (err) {
      return { name, status: 'error', message: `Cache check failed: ${err.message}` };
    }
  }

  async checkWebKitEnvironment() {
    const name = 'webkitEnvironment';
    const ua = navigator.userAgent;
    const isPS4 = ua.includes('PlayStation 4');
    const isPS5 = ua.includes('PlayStation 5');
    
    if (!isPS4 && !isPS5) {
      return { name, status: 'warn', message: 'Not running on PlayStation browser' };
    }

    // Check for known good WebKit versions
    const webkitMatch = ua.match(/AppleWebKit\/(\d+)/);
    const webkitVersion = webkitMatch ? parseInt(webkitMatch[1], 10) : 0;

    if (webkitVersion >= 600) {
      return { name, status: 'pass', message: `WebKit ${webkitVersion} detected` };
    }
    return { name, status: 'warn', message: `Old WebKit version: ${webkitVersion}` };
  }

  async checkMemoryPressure() {
    const name = 'memoryPressure';
    if ('memory' in performance) {
      const mem = performance.memory;
      const usedMB = Math.round(mem.usedJSHeapSize / 1024 / 1024);
      const limitMB = Math.round(mem.jsHeapSizeLimit / 1024 / 1024);
      const usage = (mem.usedJSHeapSize / mem.jsHeapSizeLimit) * 100;

      if (usage > 85) {
        return { name, status: 'fail', message: `High memory usage: ${usedMB}MB/${limitMB}MB (${usage.toFixed(1)}%)`, critical: true };
      }
      if (usage > 70) {
        return { name, status: 'warn', message: `Elevated memory: ${usedMB}MB/${limitMB}MB (${usage.toFixed(1)}%)` };
      }
      return { name, status: 'pass', message: `Memory OK: ${usedMB}MB/${limitMB}MB (${usage.toFixed(1)}%)` };
    }
    return { name, status: 'skip', message: 'Memory API not available' };
  }

  async checkFirmwareMatch() {
    const name = 'firmwareMatch';
    const ua = navigator.userAgent;
    const ps4Match = ua.match(/PlayStation 4 (\d+\.\d+)/);
    const ps5Match = ua.match(/PlayStation 5 (\d+\.\d+)/);
    
    if (ps4Match) {
      return { name, status: 'pass', message: `PS4 FW ${ps4Match[1]} detected`, data: { console: 'PS4', firmware: ps4Match[1] } };
    }
    if (ps5Match) {
      return { name, status: 'pass', message: `PS5 FW ${ps5Match[1]} detected`, data: { console: 'PS5', firmware: ps5Match[1] } };
    }
    return { name, status: 'fail', message: 'Could not detect PlayStation firmware', critical: true };
  }

  async checkCompatibility() {
    const name = 'compatibility';
    try {
      // This will be populated by the main app after compatibility check
      return { name, status: 'pending', message: 'Waiting for compatibility check' };
    } catch (err) {
      return { name, status: 'error', message: err.message };
    }
  }

  updateCompatibility(compat) {
    if (this.results.compatibility) {
      if (compat?.compatible) {
        this.results.compatibility = { 
          name: 'compatibility', 
          status: 'pass', 
          message: `${compat.status} - ${compat.reason}`,
          data: compat
        };
      } else {
        this.results.compatibility = { 
          name: 'compatibility', 
          status: 'fail', 
          message: `Incompatible: ${compat.reason}`,
          critical: true
        };
      }
    }
  }

  getOverallStatus() {
    const statuses = Object.values(this.results).map(r => r.status);
    if (statuses.some(s => s === 'fail' && this.results[s.name]?.critical)) return 'fail';
    if (statuses.some(s => s === 'fail')) return 'fail';
    if (statuses.some(s => s === 'warn')) return 'warn';
    if (statuses.every(s => s === 'pass')) return 'pass';
    return 'pending';
  }

  getSummary() {
    const overall = this.getOverallStatus();
    return {
      overall,
      checks: this.results,
      ready: overall === 'pass',
      canExecute: overall === 'pass' || overall === 'warn'
    };
  }
}

if (typeof module !== 'undefined') {
  module.exports = DiagnosticsValidator;
}
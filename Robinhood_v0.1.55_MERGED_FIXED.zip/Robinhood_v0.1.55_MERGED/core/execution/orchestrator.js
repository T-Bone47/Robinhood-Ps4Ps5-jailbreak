const PHASES = Object.freeze([
  "IDLE",
  "ENVIRONMENT",
  "ROUTE_RESOLVED",
  "ASSETS_READY",
  "ENTRY_READY",
  "KERNEL_READY",
  "PAYLOAD_READY",
  "COMPLETE",
  "FAILED",
  "BLOCKED"
]);

function makeOrchestrator({ route, adapter } = {}) {
  const state = {
    phase: "IDLE",
    route: route || null,
    adapter: adapter || null,
    log: [],
    error: null
  };

  const emit = (phase, message) => {
    state.phase = phase;
    if (message) state.log.push(message);
    return snapshot();
  };

  const snapshot = () => JSON.parse(JSON.stringify(state));

  function start() {
    if (!state.route || !state.adapter) {
      return emit("BLOCKED", "[!] No execution adapter is installed for this route.");
    }
    if (state.route.status !== "VERIFIED") {
      return emit("BLOCKED", "[!] Route evidence does not authorize execution.");
    }
    if (state.adapter.execution_enabled !== true) {
      return emit("BLOCKED", "[!] Adapter is declaration-only; hardware execution is disabled.");
    }
    return emit("ENVIRONMENT", "[+] Execution adapter accepted. Starting environment checks.");
  }

  function fail(message) {
    state.error = String(message);
    return emit("FAILED", `[!] ${state.error}`);
  }

  return { start, fail, snapshot, phases: PHASES };
}

module.exports = { PHASES, makeOrchestrator };

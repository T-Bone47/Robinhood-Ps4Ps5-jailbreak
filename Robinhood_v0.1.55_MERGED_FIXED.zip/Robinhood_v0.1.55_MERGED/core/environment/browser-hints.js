function collectBrowserHints(input = {}) {
  const ua = String(input.userAgent || "");
  const platform = String(input.platform || "");
  const language = String(input.language || "");

  return {
    userAgentPresent: ua.length > 0,
    platformPresent: platform.length > 0,
    languagePresent: language.length > 0,
    // Browser hints are deliberately non-authoritative.
    confidence: "NON_AUTHORITATIVE"
  };
}

function mergeEnvironmentEvidence(manual, hints) {
  const result = {
    console: manual?.console || null,
    firmware: manual?.firmware || null,
    evidence: []
  };

  if (manual?.console) result.evidence.push("USER_INPUT");
  if (manual?.firmware) result.evidence.push("USER_INPUT");
  if (hints) result.evidence.push("BROWSER_HINTS");

  return result;
}

module.exports = { collectBrowserHints, mergeEnvironmentEvidence };

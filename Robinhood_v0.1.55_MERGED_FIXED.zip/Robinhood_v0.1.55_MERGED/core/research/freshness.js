function daysBetween(a,b){
  const da=new Date(a+"T00:00:00Z");
  const db=new Date(b+"T00:00:00Z");
  return Math.floor(Math.abs(db-da)/86400000);
}

function freshnessStatus(checkedAt, now, maxAgeDays){
  if(!checkedAt || !now || typeof maxAgeDays!=="number") return "UNKNOWN";
  const age=daysBetween(checkedAt,now);
  if(age<=maxAgeDays) return "CURRENT";
  if(age<=maxAgeDays*2) return "AGING";
  return "STALE";
}

module.exports={daysBetween,freshnessStatus};

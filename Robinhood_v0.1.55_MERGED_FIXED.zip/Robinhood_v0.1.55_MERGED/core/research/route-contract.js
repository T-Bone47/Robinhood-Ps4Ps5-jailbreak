function validateRouteContract(route) {
  const errors = [];
  if (!route) return ["route missing"];

  const required = ["console", "status", "source_ids"];
  for (const field of required) {
    if (route[field] === undefined || route[field] === null) {
      errors.push(`missing ${field}`);
    }
  }

  if (!Array.isArray(route.source_ids) || route.source_ids.length === 0) {
    errors.push("route must have at least one source");
  }

  if (route.min_firmware !== undefined &&
      route.max_firmware !== undefined &&
      route.min_firmware > route.max_firmware) {
    errors.push("firmware range is inverted");
  }

  return errors;
}

module.exports = { validateRouteContract };

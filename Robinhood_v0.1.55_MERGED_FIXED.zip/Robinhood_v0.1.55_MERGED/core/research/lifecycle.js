const STATES = [
  "DISCOVERED","CORROBORATED","REPORTED","VERIFIED","DEPRECATED","BLOCKED"
];

function canTransition(from, to) {
  const transitions = {
    DISCOVERED:["CORROBORATED","BLOCKED"],
    CORROBORATED:["REPORTED","BLOCKED"],
    REPORTED:["VERIFIED","DEPRECATED","BLOCKED"],
    VERIFIED:["DEPRECATED","BLOCKED"],
    DEPRECATED:["CORROBORATED"],
    BLOCKED:[]
  };
  return STATES.includes(from) && (transitions[from] || []).includes(to);
}

function validateTransition(route, nextState) {
  if (!route || !STATES.includes(route.status)) {
    return {valid:false, reason:"invalid current state"};
  }
  if (!canTransition(route.status, nextState)) {
    return {valid:false, reason:`invalid transition ${route.status} -> ${nextState}`};
  }
  if (nextState === "VERIFIED") {
    if (route.evidence_grade !== "PRIMARY_VERIFIED") {
      return {valid:false, reason:"primary verified evidence required"};
    }
    if (route.validation && route.validation.device_tested === false) {
      return {valid:false, reason:"device validation explicitly failed"};
    }
  }
  return {valid:true};
}

module.exports = { STATES, canTransition, validateTransition };

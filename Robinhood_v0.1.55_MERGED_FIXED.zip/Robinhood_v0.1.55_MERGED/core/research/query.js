function filterRecords(records, predicate) {
  return (records || []).filter(predicate);
}

function byConsole(records, consoleName) {
  return filterRecords(records, r => r.console === consoleName);
}

function byStatus(records, status) {
  return filterRecords(records, r => r.status === status);
}

function byFirmware(records, consoleName, firmware) {
  const n = Number(firmware);
  return filterRecords(records, r =>
    r.console === consoleName &&
    typeof r.min_firmware === "number" &&
    typeof r.max_firmware === "number" &&
    n >= r.min_firmware && n <= r.max_firmware
  );
}

module.exports = { filterRecords, byConsole, byStatus, byFirmware };

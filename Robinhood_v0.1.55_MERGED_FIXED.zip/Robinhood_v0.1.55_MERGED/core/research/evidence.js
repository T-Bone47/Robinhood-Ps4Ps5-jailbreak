const GRADES = Object.freeze([
  "PRIMARY_VERIFIED",
  "PRIMARY_REPORTED",
  "SECONDARY_CORROBORATED",
  "COMMUNITY_REPORTED",
  "INFERENCE",
  "UNKNOWN"
]);

function evidenceGrade(record) {
  if (!record) return "UNKNOWN";
  if (record.evidence_level && GRADES.includes(record.evidence_level)) {
    return record.evidence_level;
  }
  if (record.status === "VERIFIED") return "PRIMARY_VERIFIED";
  if (record.status === "REPORTED") return "PRIMARY_REPORTED";
  return "UNKNOWN";
}

function executionState(record) {
  const grade = evidenceGrade(record);
  if (grade !== "PRIMARY_VERIFIED") return "RESEARCH_ONLY";
  if (record.reliability === "UNKNOWN") return "RESEARCH_ONLY";
  return "ELIGIBLE_FOR_VERIFICATION_REVIEW";
}

module.exports = { GRADES, evidenceGrade, executionState };

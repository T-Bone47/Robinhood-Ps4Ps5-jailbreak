function parseFirmware(value) {
  const raw = String(value ?? "").trim();
  const match = raw.match(/^(\d+)(?:\.(\d{1,2}))?$/);
  if (!match) return null;

  const major = Number(match[1]);
  const minorText = match[2] ?? "0";
  const minor = Number(minorText.padEnd(2, "0"));

  return {
    raw,
    major,
    minor,
    numeric: major + minor / 100
  };
}

function compareFirmware(a, b) {
  const left = typeof a === "object" ? a : parseFirmware(a);
  const right = typeof b === "object" ? b : parseFirmware(b);
  if (!left || !right) return null;
  return left.numeric === right.numeric ? 0 : (left.numeric < right.numeric ? -1 : 1);
}

module.exports = { parseFirmware, compareFirmware };

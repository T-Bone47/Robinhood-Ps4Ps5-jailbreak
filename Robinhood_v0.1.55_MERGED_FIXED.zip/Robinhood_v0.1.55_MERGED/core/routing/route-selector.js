
function versionParts(v){return String(v).split(".").map(Number);}
function cmp(a,b){
  const A=versionParts(a),B=versionParts(b);
  for(let i=0;i<3;i++){const x=A[i]||0,y=B[i]||0;if(x!==y)return x>y?1:-1;}
  return 0;
}
function inRange(firmware, spec){
  const s=String(spec);
  const m=s.match(/^(\d+\.\d+)(?:-(\d+\.\d+))?$/);
  if(!m) return false;
  if(!m[2]) return cmp(firmware,m[1])===0;
  return cmp(firmware,m[1])>=0 && cmp(firmware,m[2])<=0;
}
function selectRoute(consoleName,firmware,routes){
  if(consoleName!=="PS4") return {status:"UNSUPPORTED",reason:"Console not supported by current route table."};
  const matches=routes.filter(r=>inRange(firmware,r.firmware));
  if(!matches.length) return {status:"UNSUPPORTED",reason:"No route matches the detected firmware."};
  matches.sort((a,b)=>String(a.status).localeCompare(String(b.status)));
  const route=matches[0];
  return {status:route.status,route,reason:"Firmware route selected; execution remains subject to adapter gates."};
}
module.exports={selectRoute};

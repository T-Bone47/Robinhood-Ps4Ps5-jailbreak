
function parseUserAgent(ua) {
  const text=String(ua||"");
  const m=text.match(/PlayStation 4(?:[^\d]*)(\d+\.\d+(?:\.\d+)?)/i);
  if(!m) return {console:null,firmware:null};
  return {console:"PS4",firmware:m[1]};
}
function normalizeFirmware(v){
  const m=String(v||"").match(/^(\d+\.\d+)(?:\.\d+)?$/);
  if(!m) return null;
  return `${m[1]}.${m[2]||"0"}${m[3] ? "."+m[3] : ""}`;
}
module.exports={parseUserAgent,normalizeFirmware};

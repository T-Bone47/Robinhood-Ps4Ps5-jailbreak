function classify(entry) {
  if (!entry) return "UNKNOWN";
  if (entry.status === "VERIFIED") return "READY";
  if (entry.status === "REPORTED") return "RESEARCH";
  if (entry.status === "EXPERIMENTAL") return "EXPERIMENTAL";
  if (entry.status === "PARTIAL") return "PARTIAL";
  return "UNKNOWN";
}

function canShowStartButton(entry) {
  return Boolean(entry && entry.status === "VERIFIED");
}

module.exports = { classify, canShowStartButton };

/**
 * Evidence Promotion Lifecycle
 * 
 * Strict lifecycle for compatibility evidence:
 * REPORTED → RESEARCHED → VERIFIED → IMPLEMENTED → VALIDATED → HARDWARE_VERIFIED
 * 
 * Only the compatibility/provenance layer may promote evidence.
 * UI must never promote evidence state.
 */

const PromotionState = {
  REPORTED: 'REPORTED',
  RESEARCHED: 'RESEARCHED',
  VERIFIED: 'VERIFIED',
  IMPLEMENTED: 'IMPLEMENTED',
  VALIDATED: 'VALIDATED',
  HARDWARE_VERIFIED: 'HARDWARE_VERIFIED'
};

// Promotion hierarchy - higher = more verified
const PROMOTION_HIERARCHY = {
  [PromotionState.REPORTED]: 0,
  [PromotionState.RESEARCHED]: 1,
  [PromotionState.VERIFIED]: 2,
  [PromotionState.IMPLEMENTED]: 3,
  [PromotionState.VALIDATED]: 4,
  [PromotionState.HARDWARE_VERIFIED]: 5
};

// Evidence requirements for each promotion level
const PROMOTION_REQUIREMENTS = {
  [PromotionState.REPORTED]: {
    minConfidence: 0.1,
    requiredSources: 1,
    requiredTypes: [],
    description: 'Community report or initial discovery'
  },
  [PromotionState.RESEARCHED]: {
    minConfidence: 0.3,
    requiredSources: 1,
    requiredTypes: ['TECHNICAL_ARTICLE', 'SOURCE_FILE'],
    description: 'Analyzed by researcher, source code reviewed'
  },
  [PromotionState.VERIFIED]: {
    minConfidence: 0.7,
    requiredSources: 2,
    requiredTypes: ['UPSTREAM_REPOSITORY', 'UPSTREAM_RELEASE'],
    description: 'Multiple independent reproductions, upstream releases'
  },
  [PromotionState.IMPLEMENTED]: {
    minConfidence: 0.8,
    requiredSources: 2,
    requiredTypes: ['UPSTREAM_REPOSITORY'],
    description: 'Working implementation exists in codebase'
  },
  [PromotionState.VALIDATED]: {
    minConfidence: 0.9,
    requiredSources: 3,
    requiredTypes: ['UPSTREAM_REPOSITORY', 'UPSTREAM_RELEASE', 'TECHNICAL_ARTICLE'],
    description: 'Validated against multiple test scenarios'
  },
  [PromotionState.HARDWARE_VERIFIED]: {
    minConfidence: 1.0,
    requiredSources: 3,
    requiredTypes: ['UPSTREAM_REPOSITORY', 'UPSTREAM_RELEASE', 'TECHNICAL_ARTICLE'],
    description: 'Confirmed working on actual target hardware'
  }
};

/**
 * Evidence Promotion Manager
 * Handles promotion/demotion of evidence states
 * Only the compatibility/provenance layer may use this
 */
class EvidencePromotion {
  constructor() {
    this.promotionLog = [];
  }

  /**
   * Check if evidence meets requirements for a promotion level
   */
  canPromote(evidence, targetState) {
    const requirements = PROMOTION_REQUIREMENTS[targetState];
    if (!requirements) return { allowed: false, reason: 'Invalid target state' };

    if (!evidence) return { allowed: false, reason: 'No evidence provided' };

    // Check confidence
    if (evidence.confidence < requirements.minConfidence) {
      return { allowed: false, reason: `Confidence ${evidence.confidence} below required ${requirements.minConfidence}` };
    }

    // Check source count
    if (evidence.sourceIds.length < requirements.requiredSources) {
      return { allowed: false, reason: `Need ${requirements.requiredSources} sources, have ${evidence.sourceIds.length}` };
    }

    // Check evidence types (if specified)
    if (requirements.requiredTypes.length > 0) {
      // Would check actual evidence types in real implementation
    }

    return { allowed: true };
  }

  /**
   * Promote evidence to a new state
   * Only callable by compatibility/provenance layer
   */
  promote(evidence, targetState, reason, actor = 'system') {
    const check = this.canPromote(evidence, targetState);
    if (!check.allowed) {
      return { success: false, reason: check.reason };
    }

    const oldState = evidence.promotionState || 'REPORTED';
    evidence.promotionState = targetState;
    
    this.promotionLog.push({
      timestamp: new Date().toISOString(),
      fromState: oldState,
      toState: targetState,
      reason,
      actor,
      evidenceId: evidence.sourceIds.join(',')
    });

    return { success: true, oldState, newState: targetState };
  }

  /**
   * Demote evidence (e.g., when contradiction found)
   */
  demote(evidence, targetState, reason, actor = 'system') {
    const currentState = evidence.promotionState || 'REPORTED';
    const currentPriority = this.getPriority(evidence.promotionState || 'REPORTED');
    const targetPriority = this.getPriority(targetState);
    
    if (targetPriority >= currentPriority) {
      return { success: false, reason: 'Cannot demote to higher or equal state' };
    }

    evidence.promotionState = targetState;
    
    this.promotionLog.push({
      timestamp: new Date().toISOString(),
      fromState: currentState,
      toState: targetState,
      reason: `DEMOTION: ${reason}`,
      actor,
      evidenceId: evidence.sourceIds?.join(',')
    });

    return { success: true, oldState: currentState, newState: targetState };
  }

  getPriority(state) {
    const hierarchy = {
      'REPORTED': 0,
      'RESEARCHED': 1,
      'VERIFIED': 2,
      'IMPLEMENTED': 3,
      'VALIDATED': 4,
      'HARDWARE_VERIFIED': 5
    };
    return hierarchy[state] || -1;
  }

  getPromotionLog() {
    return [...this.promotionLog];
  }

  getRequirements(state) {
    return PROMOTION_REQUIREMENTS[state] || null;
  }
}

// Promotion state constants
const PromotionState = {
  REPORTED: 'REPORTED',
  RESEARCHED: 'RESEARCHED',
  VERIFIED: 'VERIFIED',
  IMPLEMENTED: 'IMPLEMENTED',
  VALIDATED: 'VALIDATED',
  HARDWARE_VERIFIED: 'HARDWARE_VERIFIED'
};

const PROMOTION_REQUIREMENTS = {
  REPORTED: {
    minConfidence: 0.1,
    requiredSources: 1,
    requiredTypes: [],
    description: 'Community report or initial discovery'
  },
  RESEARCHED: {
    minConfidence: 0.3,
    requiredSources: 1,
    requiredTypes: ['TECHNICAL_ARTICLE', 'SOURCE_FILE'],
    description: 'Analyzed by researcher, source code reviewed'
  },
  VERIFIED: {
    minConfidence: 0.7,
    requiredSources: 2,
    requiredTypes: ['UPSTREAM_REPOSITORY', 'UPSTREAM_RELEASE'],
    description: 'Multiple independent reproductions, upstream releases'
  },
  IMPLEMENTED: {
    minConfidence: 0.8,
    requiredSources: 2,
    requiredTypes: ['UPSTREAM_REPOSITORY'],
    description: 'Working implementation exists in codebase'
  },
  VALIDATED: {
    minConfidence: 0.9,
    requiredSources: 3,
    requiredTypes: ['UPSTREAM_REPOSITORY', 'UPSTREAM_RELEASE', 'TECHNICAL_ARTICLE'],
    description: 'Validated against multiple test scenarios'
  },
  HARDWARE_VERIFIED: {
    minConfidence: 1.0,
    requiredSources: 3,
    requiredTypes: ['UPSTREAM_REPOSITORY', 'UPSTREAM_RELEASE', 'TECHNICAL_ARTICLE'],
    description: 'Confirmed working on actual target hardware'
  }
};

module.exports = {
  PromotionState,
  PROMOTION_HIERARCHY: {
    REPORTED: 0,
    RESEARCHED: 1,
    VERIFIED: 2,
    IMPLEMENTED: 3,
    VALIDATED: 4,
    HARDWARE_VERIFIED: 5
  },
  PROMOTION_REQUIREMENTS,
  EvidencePromotion
};
function makePlan(entry) {
  if (!entry) {
    return { state: "UNKNOWN", action: "NONE", reasons: ["No database entry"] };
  }

  if (entry.status === "AMBIGUOUS") {
    return {
      state: "AMBIGUOUS",
      action: "RESEARCH",
      reasons: [
        "More than one compatibility route matches this firmware.",
        "Robinhood must not silently choose an exploit chain."
      ],
      matches: entry.matches || []
    };
  }

  if (entry.status !== "VERIFIED") {
    return {
      state: entry.status,
      action: "RESEARCH",
      reasons: [
        "This route is not VERIFIED.",
        "Robinhood must not expose an execution action for it."
      ],
      source_ids: entry.source_ids || []
    };
  }

  return {
    state: "READY",
    action: "PREPARE_VERIFIED_ROUTE",
    console: entry.console,
    firmware: entry.firmware,
    entry_route: entry.entry_route || entry.chain || null,
    components: entry.components || {},
    prerequisites: entry.prerequisites || [],
    source_ids: entry.source_ids || []
  };
}

module.exports = { makePlan };

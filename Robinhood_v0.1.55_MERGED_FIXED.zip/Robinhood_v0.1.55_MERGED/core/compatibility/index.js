const fs = require("fs");
const path = require("path");
const { resolve, validateEntry } = require("./engine");
const { makePlan } = require("./planner");

function loadDatabase(rootDir) {
  const file = path.join(rootDir, "database", "compatibility.json");
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function getRoutePlan(rootDir, consoleName, firmware) {
  const db = loadDatabase(rootDir);
  const entry = resolve(db, consoleName, firmware);
  return makePlan(entry);
}

module.exports = { loadDatabase, getRoutePlan, validateEntry };

function parseFirmware(value) {
  const raw=String(value ?? "").trim();
  const m=raw.match(/^(\d+)(?:\.(\d{1,2}))?$/);
  if(!m) return null;
  const major=Number(m[1]);
  const minor=Number((m[2]||"0").padEnd(2,"0"));
  return {raw,major,minor,numeric:major+minor/100};
}

function inRange(version,min,max) {
  const v=parseFirmware(version);
  if(!v || typeof min!=="number" || typeof max!=="number") return false;
  return v.numeric>=min && v.numeric<=max;
}

function normalizeRange(min,max) {
  if(typeof min!=="number" || typeof max!=="number" || min>max) return null;
  return {min,max};
}

module.exports={parseFirmware,inRange,normalizeRange};

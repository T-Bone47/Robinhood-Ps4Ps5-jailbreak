function normalizeConsole(value) {
  const raw = String(value || "").trim().toUpperCase();
  if (raw === "PS4" || raw === "PLAYSTATION 4") return "PS4";
  if (raw === "PS5" || raw === "PLAYSTATION 5") return "PS5";
  return null;
}

function parseFirmware(value) {
  const raw = String(value || "").trim();
  const m = raw.match(/^(\d+)(?:\.(\d{1,2}))?$/);
  if (!m) return null;

  const major = Number(m[1]);
  const minorText = m[2] || "0";
  const minor = Number(minorText.padEnd(2, "0"));

  return {
    raw,
    major,
    minor,
    numeric: major + minor / 100
  };
}

function validateEnvironment(consoleValue, firmwareValue) {
  const consoleName = normalizeConsole(consoleValue);
  const firmware = parseFirmware(firmwareValue);
  const errors = [];

  if (!consoleName) errors.push("Unknown console");
  if (!firmware) errors.push("Invalid firmware format");

  return {
    valid: errors.length === 0,
    console: consoleName,
    firmware,
    errors
  };
}

module.exports = { normalizeConsole, parseFirmware, validateEnvironment };

function validateDependencyLock(route) {
  const errors = [];
  if (!route) return ["route is missing"];

  for (const dep of route.dependencies || []) {
    if (!dep.repo) errors.push("dependency repository missing");
    if (!dep.version) errors.push(`${dep.repo || "unknown"} is not pinned`);
    if (!dep.source_id) errors.push(`${dep.repo || "unknown"} has no source_id`);
  }

  return errors;
}

function isExecutionEligible(route, licenseEntries) {
  if (!route || !Array.isArray(licenseEntries)) return false;
  if (validateDependencyLock(route).length) return false;

  return licenseEntries
    .filter(x => (route.dependencies || []).some(d => d.repo === x.repository))
    .every(x => x.redistribution !== "REVIEW_REQUIRED");
}

module.exports = { validateDependencyLock, isExecutionEligible };

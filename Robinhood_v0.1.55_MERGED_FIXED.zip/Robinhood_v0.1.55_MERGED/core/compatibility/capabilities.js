function missingRequirements(route, context) {
  const missing = [];
  const required = route.prerequisites || [];

  for (const item of required) {
    if (!(context.prerequisites || []).includes(item)) {
      missing.push(item);
    }
  }

  if (route.host_mode && context.host_mode && route.host_mode !== context.host_mode) {
    missing.push(`host_mode:${route.host_mode}`);
  }

  return missing;
}

function evaluateCapability(route, context={}) {
  if (!route) return {state:"UNKNOWN", selectable:false, missing:["route"]};

  const missing = missingRequirements(route, context);

  if (route.status === "BLOCKED" || route.status === "DEPRECATED") {
    return {state:route.status, selectable:false, missing};
  }

  if (route.evidence_grade !== "PRIMARY_VERIFIED") {
    return {
      state:"RESEARCH_ONLY",
      selectable:false,
      missing,
      reason:"route is not primary-verified"
    };
  }

  if (missing.length) {
    return {
      state:"PREREQUISITES_MISSING",
      selectable:false,
      missing
    };
  }

  return {state:"ELIGIBLE_FOR_VALIDATION", selectable:true, missing:[]};
}

module.exports = {missingRequirements, evaluateCapability};

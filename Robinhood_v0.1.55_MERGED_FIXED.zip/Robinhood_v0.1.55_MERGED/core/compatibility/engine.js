const fs = require('fs');
const path = require('path');

/**
 * Evidence levels for compatibility claims
 */
const EvidenceLevel = {
  TIER_1: 'TIER_1',      // Original developer repository, GitHub source/release/commit, original technical disclosure
  TIER_2: 'TIER_2',      // Established technical research site
  TIER_3: 'TIER_3'       // Community reports
};

/**
 * Evidence types
 */
const EvidenceType = {
  UPSTREAM_REPOSITORY: 'UPSTREAM_REPOSITORY',
  UPSTREAM_RELEASE: 'UPSTREAM_RELEASE',
  SOURCE_FILE: 'SOURCE_FILE',
  ISSUE: 'ISSUE',
  PULL_REQUEST: 'PULL_REQUEST',
  TECHNICAL_ARTICLE: 'TECHNICAL_ARTICLE',
  COMMUNITY_REPORT: 'COMMUNITY_REPORT',
  VIDEO: 'VIDEO'
};

/**
 * Compatibility status levels
 */
const CompatStatus = {
  VERIFIED: 'VERIFIED',
  PARTIAL: 'PARTIAL',
  EXPERIMENTAL: 'EXPERIMENTAL',
  REPORTED: 'REPORTED',
  UNSUPPORTED: 'UNSUPPORTED',
  UNKNOWN: 'UNKNOWN'
};

/**
 * Reliability levels
 */
const Reliability = {
  EXCELLENT: 'EXCELLENT',
  GOOD: 'GOOD',
  MODERATE: 'MODERATE',
  POOR: 'POOR',
  EXPERIMENTAL: 'EXPERIMENTAL',
  UNKNOWN: 'UNKNOWN'
};

// const { PromotionState } = require('./EvidencePromotion');

/**
 * Evidence record for a compatibility claim
 */
class Evidence {
  constructor(data = {}) {
    this.sourceIds = data.sourceIds || [];
    this.evidenceType = data.evidenceType || 'COMMUNITY_REPORT';
    this.confidence = data.confidence || 0.5; // 0.0 to 1.0
    this.description = data.description || '';
    this.contradictions = data.contradictions || [];
    this.resolution = data.resolution || null;
    this.dateRecorded = data.dateRecorded || new Date().toISOString();
    
    // Promotion state tracking
    this.promotionState = data.promotionState || 'REPORTED';
  }

  /**
   * Calculate effective confidence considering contradictions
   */
  getEffectiveConfidence() {
    if (this.contradictions.length > 0 && !this.resolution) {
      return Math.max(0, this.confidence - 0.3);
    }
    return this.confidence;
  }

  /**
   * Get current promotion state
   */
  getPromotionState() {
    return this.promotionState;
  }

  /**
   * Set promotion state (only callable by compatibility/provenance layer)
   */
  setPromotionState(newState, reason, actor = 'system') {
    // In real implementation, would use EvidencePromotion class
    this.promotionState = newState;
  }

  getPromotionPriority() {
    const hierarchy = {
      'REPORTED': 0,
      'RESEARCHED': 1,
      'VERIFIED': 2,
      'IMPLEMENTED': 3,
      'VALIDATED': 4,
      'HARDWARE_VERIFIED': 5
    };
    return hierarchy[this.promotionState] || -1;
  }
}

/**
 * Compatibility record for a specific console/firmware
 */
class CompatibilityRecord {
  constructor(data = {}) {
    this.console = data.console;
    this.firmware = data.firmware;
    this.firmwareFamily = data.firmwareFamily || data.firmware;
    this.status = data.status || CompatStatus.UNKNOWN;
    this.recommendedChain = data.recommendedChain || null;
    this.alternativeChains = data.alternativeChains || [];
    
    // Per-layer status
    this.webkit = data.webkit || CompatStatus.UNKNOWN;
    this.kernel = data.kernel || CompatStatus.UNKNOWN;
    this.hen = data.hen || CompatStatus.UNKNOWN;
    this.loader = data.loader || CompatStatus.UNKNOWN;
    this.payloads = data.payloads || CompatStatus.UNKNOWN;
    
    // Capabilities
    this.offline = data.offline ?? false;
    this.localHost = data.localHost ?? false;
    
    // Reliability
    this.reliability = data.reliability || Reliability.UNKNOWN;
    
    // Evidence
    this.evidence = data.evidence ? new Evidence(data.evidence) : null;
    this.sourceIds = data.sourceIds || [];
    this.lastVerified = data.lastVerified || null;
    
    // Issues
    this.knownIssues = data.knownIssues || [];
    
    // Constraints
    this.constraints = data.constraints || [];
  }

  /**
   * Check if this record has sufficient evidence for VERIFIED status
   */
  hasVerifiedEvidence() {
    if (!this.evidence) return false;
    return this.evidence.getEffectiveConfidence() >= 0.8 && 
           this.evidence.sourceIds.some(id => {
             // Would check if source is TIER_1
             return true; // Placeholder - would check actual source authority
           });
  }

  /**
   * Get overall confidence score
   */
  getConfidence() {
    if (!this.evidence) return 0;
    return this.evidence.getEffectiveConfidence();
  }

  toJSON() {
    return {
      console: this.console,
      firmware: this.firmware,
      firmwareFamily: this.firmwareFamily,
      status: this.status,
      recommendedChain: this.recommendedChain,
      alternativeChains: this.alternativeChains,
      webkit: this.webkit,
      kernel: this.kernel,
      hen: this.hen,
      loader: this.loader,
      payloads: this.payloads,
      offline: this.offline,
      localHost: this.localHost,
      reliability: this.reliability,
      knownIssues: this.knownIssues,
      sourceIds: this.sourceIds,
      lastVerified: this.lastVerified,
      evidence: this.evidence ? {
        sourceIds: this.evidence.sourceIds,
        evidenceType: this.evidence.evidenceType,
        confidence: this.evidence.confidence,
        effectiveConfidence: this.evidence.getEffectiveConfidence(),
        description: this.evidence.description,
        contradictions: this.evidence.contradictions,
        resolution: this.evidence.resolution,
        dateRecorded: this.evidence.dateRecorded
      } : null
    };
  }
}

class CompatibilityEngine {
  constructor(databasePath = path.join(__dirname, '..', 'database')) {
    this.databasePath = databasePath;
    this.ps4DB = null;
    this.ps5DB = null;
    this.chainsDB = null;
    this.henDB = null;
    this.payloadsDB = null;
    this.sourcesDB = null;
    this.loaded = false;
  }

  load() {
    if (this.loaded) return;
    
    this.ps4DB = JSON.parse(fs.readFileSync(path.join(this.databasePath, 'ps4.json'), 'utf8'));
    this.ps5DB = JSON.parse(fs.readFileSync(path.join(this.databasePath, 'ps5.json'), 'utf8'));
    this.chainsDB = JSON.parse(fs.readFileSync(path.join(this.databasePath, 'exploit-chains.json'), 'utf8'));
    this.henDB = JSON.parse(fs.readFileSync(path.join(this.databasePath, 'hen.json'), 'utf8'));
    this.payloadsDB = JSON.parse(fs.readFileSync(path.join(this.databasePath, 'payloads.json'), 'utf8'));
    this.sourcesDB = JSON.parse(fs.readFileSync(path.join(this.databasePath, 'sources.json'), 'utf8'));
    
    this.loaded = true;
  }

  getFirmwareRecord(console, firmware) {
    this.load();
    const db = console === 'PS4' ? this.ps4DB : this.ps5DB;
    return db.find(record => record.firmware === firmware) || null;
  }

  normalizeChain(chain) {
    if (!chain) return null;
    const supported = Array.isArray(chain.supported_firmware)
      ? chain.supported_firmware
      : (Array.isArray(chain.firmware)
        ? chain.firmware
        : (typeof chain.firmware_range === 'string' ? chain.firmware_range.split('-') : []));
    return {
      ...chain,
      id: chain.id || chain.chain_id,
      supported_firmware: supported,
      hen_component: chain.hen_component || null,
      loader_component: chain.loader_component || null,
      payload_formats: chain.payload_formats || []
    };
  }

  getCompatibleChains(console, firmware) {
    this.load();
    return this.chainsDB
      .map(c => this.normalizeChain(c))
      .filter(chain =>
        chain.console === console &&
        chain.supported_firmware.includes(firmware) &&
        ['VERIFIED', 'PARTIAL', 'EXPERIMENTAL'].includes(chain.status)
      );
  }

  getRecommendedChain(console, firmware) {
    const record = this.getFirmwareRecord(console, firmware);
    if (!record || !record.recommended_chain) return null;
    return this.chainsDB
      .map(c => this.normalizeChain(c))
      .find(chain => chain.id === record.recommended_chain) || null;
  }

  getAlternativeChains(console, firmware) {
    const record = this.getFirmwareRecord(console, firmware);
    if (!record || !record.alternative_chains) return [];
    return record.alternative_chains
      .map(id => this.chainsDB.map(c => this.normalizeChain(c)).find(chain => chain.id === id))
      .filter(Boolean);
  }

  getHENOptions(console, firmware) {
    this.load();
    const record = this.getFirmwareRecord(console, firmware);
    if (!record) return [];

    const chains = this.getCompatibleChains(console, firmware);
    const henIds = [...new Set([
      ...chains.map(c => c.hen_component).filter(Boolean),
      record.hen,
      record.components?.hen
    ].filter(Boolean))];

    return henIds
      .map(id => this.henDB.find(hen => hen.id === id))
      .filter(hen => hen && (!hen.firmware_range || hen.firmware_range.includes(firmware)));
  }

  getPayloads(console, firmware, henId = null) {
    this.load();
    return this.payloadsDB.filter(payload => 
      payload.console === console && 
      payload.firmware_range.includes(firmware) &&
      payload.status === 'VERIFIED' &&
      (!henId || payload.loader === henId.replace('-', '-').split('-')[0] + '-loader')
    );
  }

  getSources(sourceIds) {
    this.load();
    return sourceIds
      .map(id => this.sourcesDB.find(s => s.source_id === id))
      .filter(Boolean);
  }

  /**
   * Enhanced compatibility check with evidence tracking
   */
  checkCompatibility(console, firmware) {
    this.load();
    const record = this.getFirmwareRecord(console, firmware);
    
    if (!record) {
      return {
        compatible: false,
        status: CompatStatus.UNKNOWN,
        reason: `No compatibility data for ${console} ${firmware}`,
        console,
        firmware,
        recommended_chain: null,
        alternatives: [],
        hen_options: [],
        payloads: [],
        reliability: Reliability.UNKNOWN,
        warnings: ['Firmware not in database'],
        evidence: null,
        confidence: 0,
        constraints: []
      };
    }

    const recommendedChain = this.getRecommendedChain(console, firmware);
    const alternatives = this.getAlternativeChains(console, firmware);
    const henOptions = this.getHENOptions(console, firmware);
    const payloads = this.getPayloads(console, firmware);
    const sources = this.getSources(record.source_ids);

    const compatible = ['VERIFIED', 'PARTIAL', 'EXPERIMENTAL'].includes(record.status);
    
    let reason = '';
    if (record.status === 'VERIFIED') {
      reason = 'Verified exploit chain available';
    } else if (record.status === 'PARTIAL') {
      reason = 'Partial chain - some components verified';
    } else if (record.status === 'EXPERIMENTAL') {
      reason = 'Experimental - incomplete verification';
    } else if (record.status === 'REPORTED') {
      reason = 'Community reports only';
    } else if (record.status === 'UNSUPPORTED') {
      reason = 'Known incompatible';
    } else {
      reason = 'Insufficient evidence';
    }

    const warnings = [...record.known_issues];
    if (record.status === 'EXPERIMENTAL' || record.status === 'PARTIAL') {
      warnings.push('Do not expect reliable execution');
    }
    if (!record.offline) {
      warnings.push('Requires network connection for exploit delivery');
    }
    if (!record.local_host) {
      warnings.push('Cannot be fully self-hosted offline');
    }

    // Build evidence object
    const evidence = record.evidence ? {
      sourceIds: record.evidence.sourceIds,
      evidenceType: record.evidence.evidenceType,
      confidence: record.evidence.confidence,
      effectiveConfidence: record.evidence.getEffectiveConfidence(),
      description: record.evidence.description,
      contradictions: record.evidence.contradictions,
      resolution: record.evidence.resolution,
      dateRecorded: record.evidence.dateRecorded
    } : null;

    return {
      compatible,
      status: record.status,
      reason,
      console,
      firmware,
      firmwareFamily: record.firmware_family,
      recommended_chain: recommendedChain ? {
        id: recommendedChain.id,
        name: recommendedChain.name,
        status: recommendedChain.status,
        reliability: recommendedChain.reliability,
        payload_formats: recommendedChain.payload_formats
      } : null,
      alternatives: alternatives.map(c => ({
        id: c.id,
        name: c.name,
        status: c.status,
        reliability: c.reliability
      })),
      hen_options: henOptions.map(h => ({
        id: h.id,
        name: h.name,
        version: h.version,
        compatibility: h.compatibility,
        payload_format: h.payload_format
      })),
      payloads: payloads.map(p => ({
        payload_id: p.payload_id,
        name: p.name,
        format: p.format,
        size: p.size,
        sha256: p.sha256,
        status: p.status,
        integrity: p.integrity
      })),
      reliability: record.reliability,
      offline_capable: record.offline,
      local_host_capable: record.local_host,
      known_issues: record.known_issues,
      warnings,
      sources: sources.map(s => ({
        source_id: s.source_id,
        project: s.project,
        type: s.type,
        authority: s.authority,
        url: s.url,
        commit: s.commit,
        release: s.release
      })),
      evidence,
      confidence: evidence ? evidence.getEffectiveConfidence() : 0,
      constraints: record.constraints || []
    };
  }

  detectConsole(userAgent) {
    if (!userAgent) return 'UNKNOWN';
    const ua = userAgent.toLowerCase();
    if (ua.includes('playstation 5') || ua.includes('ps5')) return 'PS5';
    if (ua.includes('playstation 4') || ua.includes('ps4')) return 'PS4';
    return 'UNKNOWN';
  }

  detectFirmware(userAgent) {
    if (!userAgent) return null;
    const match = userAgent.match(/PlayStation \d (\d+\.\d+)/);
    return match ? match[1] : null;
  }
}


/**
 * Legacy resolver API retained for Robinhood v0.1.54 consumers.
 * Uses database/compatibility.json route records and does not mutate evidence state.
 */
function validateEntry(entry) {
  if (!entry) return ["entry missing"];
  const errors = [];
  if (!entry.console) errors.push("console missing");
  if (typeof entry.min_firmware !== "number") errors.push("min_firmware missing");
  if (typeof entry.max_firmware !== "number") errors.push("max_firmware missing");
  if (!entry.status) errors.push("status missing");
  return errors;
}

function resolve(db, consoleName, firmware, options = {}) {
  const routeType = options.route_type || "EXPLOIT_CHAIN";
  const matches = db.filter(item =>
    item.console === consoleName &&
    (item.route_type || "EXPLOIT_CHAIN") === routeType &&
    firmware >= item.min_firmware &&
    firmware <= item.max_firmware
  );
  if (matches.length === 0) return null;
  if (matches.length === 1) return matches[0];
  return { status: "AMBIGUOUS", console: consoleName, firmware, matches };
}

function resolveAll(db, consoleName, firmware) {
  return db.filter(item =>
    item.console === consoleName &&
    firmware >= item.min_firmware &&
    firmware <= item.max_firmware
  );
}

module.exports = {
  CompatibilityEngine,
  Evidence,
  resolve,
  resolveAll,
  validateEntry
};
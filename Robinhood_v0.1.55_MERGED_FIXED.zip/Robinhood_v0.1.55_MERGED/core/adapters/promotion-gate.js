
function promotionDecision(record) {
  const reasons = [];
  if (!record) return {promotable:false,reasons:["Missing provenance record."]};

  if (!record.exact_release_or_commit)
    reasons.push("Exact upstream release/commit is not pinned.");
  if (!Array.isArray(record.required_files) || record.required_files.length === 0)
    reasons.push("Exact upstream files are not pinned.");
  if (!Array.isArray(record.sha256) || record.sha256.length === 0)
    reasons.push("Payload/source checksums are not recorded.");
  if (!record.license || record.license === "REQUIRES_UPSTREAM_REVIEW")
    reasons.push("License has not been reviewed.");
  if (!record.hardware_validation || record.hardware_validation === "NOT_RECORDED")
    reasons.push("Hardware validation is not recorded.");
  if (record.contradictions && record.contradictions.length)
    reasons.push("Unresolved source contradiction exists.");
  if (record.status !== "VERIFIED")
    reasons.push("Provenance record is not VERIFIED.");

  return {promotable:reasons.length===0,reasons};
}
module.exports={promotionDecision};

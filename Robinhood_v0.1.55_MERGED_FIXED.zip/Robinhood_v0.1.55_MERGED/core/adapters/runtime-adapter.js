
const {validateAdapter,canExecute}=require("./contract");
const {validateResult}=require("./result-contract");

function createRuntimeAdapter(adapter, transport){
  function start(){
    const gate=validateAdapter(adapter);
    if(!gate.valid || !canExecute(adapter))
      return {status:"REVIEW_REQUIRED",errors:gate.errors};
    if(!transport || typeof transport.start!=="function")
      return {status:"FAILED",errors:["Runtime transport is not installed."]};
    return transport.start({routeId:adapter.id});
  }

  function acceptEvent(event){
    const result=validateResult(event);
    if(!result.valid) return {accepted:false,errors:result.errors};
    if(event.routeId!==adapter.id)
      return {accepted:false,errors:["Route mismatch."]};
    return {accepted:true,event};
  }

  return {start,acceptEvent};
}
module.exports={createRuntimeAdapter};

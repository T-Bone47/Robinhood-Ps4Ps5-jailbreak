
const TERMINAL = new Set(["COMPLETE","FAILED","REVIEW_REQUIRED"]);

function validateResult(result){
  const errors=[];
  if(!result || typeof result!=="object") return {valid:false,errors:["Missing adapter result."]};
  if(!result.routeId) errors.push("routeId missing.");
  if(!["ENTRY_STARTED","KERNEL_STARTED","PAYLOAD_STARTED","COMPLETE","FAILED"].includes(result.type))
    errors.push("Invalid adapter event type.");
  if(result.type==="COMPLETE" && !result.payloadId)
    errors.push("Completion requires payloadId.");
  if(result.type==="FAILED" && !result.errorCode)
    errors.push("Failure requires errorCode.");
  return {valid:errors.length===0,errors};
}

function terminal(type){ return type==="COMPLETE" || type==="FAILED"; }

module.exports={validateResult,terminal,TERMINAL};

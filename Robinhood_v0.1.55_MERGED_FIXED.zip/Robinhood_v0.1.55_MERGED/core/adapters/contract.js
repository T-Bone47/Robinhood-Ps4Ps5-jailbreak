
const PHASES = Object.freeze(["IDLE","PRECHECK","ENTRY","KERNEL","PAYLOAD","COMPLETE","FAILED","REVIEW_REQUIRED"]);

function validateAdapter(adapter) {
  const required = ["id","console","firmware","sourceIds","status"];
  const missing = required.filter(k => adapter == null || adapter[k] == null);
  if (missing.length) return {valid:false, errors:[`Missing adapter fields: ${missing.join(", ")}`]};
  const errors = [];
  if (!["PS4","PS5"].includes(adapter.console)) errors.push("Unsupported console identifier.");
  if (!Array.isArray(adapter.sourceIds) || !adapter.sourceIds.length) errors.push("Adapter requires provenance source IDs.");
  if (!["VERIFIED","REPORTED","RESEARCH_ONLY","BLOCKED","DEPRECATED"].includes(adapter.status)) errors.push("Invalid adapter status.");
  if (adapter.status !== "VERIFIED") errors.push("Execution adapter is not verified.");
  return {valid:errors.length===0, errors};
}
function canExecute(adapter) { return validateAdapter(adapter).valid === true; }
module.exports = {PHASES,validateAdapter,canExecute};

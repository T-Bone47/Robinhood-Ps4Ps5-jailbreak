const fs = require("fs");
const path = require("path");

function loadRegistry(root = path.resolve(__dirname, "../../database")) {
  const file = path.join(root, "reference", "legacy-host-routes.json");
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function findReferenceRoute(registry, consoleName, firmware) {
  const value = Number(firmware);
  return registry.routes.find(route =>
    route.console === consoleName &&
    value >= route.min_firmware &&
    value <= route.max_firmware
  ) || null;
}

module.exports = { loadRegistry, findReferenceRoute };

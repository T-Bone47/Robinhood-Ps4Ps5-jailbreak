
const CLASSES = Object.freeze([
  "ENTRY_CODE","KERNEL_STAGE","PAYLOAD_LOADER","HEN_PAYLOAD",
  "STATIC_UI","OFFLINE_CACHE"
]);

function validateAsset(asset) {
  const errors=[];
  if (!asset || !CLASSES.includes(asset.class)) errors.push("Invalid asset class.");
  if (!asset || asset.source !== "upstream") errors.push("Asset provenance must be upstream.");
  if (asset && asset.required && asset.integrity_required !== true)
    errors.push("Required assets must require integrity verification.");
  return {valid:errors.length===0,errors};
}

function validatePayloadResult(result) {
  if (!result || result.status !== "LOADED")
    return {valid:false,errors:["Payload loader did not report LOADED."]};
  if (!result.payloadId)
    return {valid:false,errors:["Loaded payload ID missing."]};
  if (!result.routeId)
    return {valid:false,errors:["Route ID missing from payload result."]};
  return {valid:true,errors:[]};
}

module.exports={CLASSES,validateAsset,validatePayloadResult};

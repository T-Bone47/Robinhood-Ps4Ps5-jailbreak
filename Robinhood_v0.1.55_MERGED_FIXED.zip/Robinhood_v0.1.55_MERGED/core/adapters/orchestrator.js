
const {PHASES,canExecute}=require("./contract");
function createOrchestrator(adapter){
  let phase="IDLE"; const log=[];
  const add=m=>log.push(String(m));
  const snapshot=()=>({phase,adapterId:adapter?.id||null,log:[...log]});
  function precheck(){
    phase="PRECHECK"; add("[+] Running route pre-check.");
    if(!canExecute(adapter)){phase="REVIEW_REQUIRED";add("[!] Route is not an approved execution adapter.");return snapshot();}
    add("[+] Adapter provenance and execution gate passed."); return snapshot();
  }
  function start(){const s=precheck();if(s.phase==="REVIEW_REQUIRED")return s;phase="ENTRY";add("[+] Entry stage delegated to the route adapter.");return snapshot();}
  function markKernel(){if(phase!=="ENTRY"){phase="FAILED";add("[!] Invalid lifecycle transition.");return snapshot();}phase="KERNEL";add("[+] Kernel stage delegated to the route adapter.");return snapshot();}
  function markPayload(){if(phase!=="KERNEL"){phase="FAILED";add("[!] Invalid lifecycle transition.");return snapshot();}phase="PAYLOAD";add("[+] GoldHEN/payload stage delegated to the route adapter.");return snapshot();}
  function complete(){if(phase!=="PAYLOAD"){phase="FAILED";add("[!] Invalid lifecycle transition.");return snapshot();}phase="COMPLETE";add("[+] Route completed successfully.");return snapshot();}
  function fail(reason){phase="FAILED";add(`[!] ${reason||"Route failed."}`);return snapshot();}
  return {snapshot,precheck,start,markKernel,markPayload,complete,fail};
}
module.exports={createOrchestrator};

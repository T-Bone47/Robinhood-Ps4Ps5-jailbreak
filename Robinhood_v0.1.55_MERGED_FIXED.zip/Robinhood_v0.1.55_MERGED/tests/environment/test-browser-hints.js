const {
  collectBrowserHints,
  mergeEnvironmentEvidence
} = require("../../core/environment/browser-hints");

function assert(c,m){if(!c)throw new Error(m)}

const hints = collectBrowserHints({
  userAgent:"Mozilla/5.0",
  platform:"Win32",
  language:"en-US"
});

assert(hints.confidence === "NON_AUTHORITATIVE","browser hints must be non-authoritative");

const merged = mergeEnvironmentEvidence(
  {console:"PS4", firmware:"12.52"},
  hints
);

assert(merged.console === "PS4","manual console lost");
assert(merged.firmware === "12.52","manual firmware lost");
assert(merged.evidence.includes("USER_INPUT"),"manual evidence missing");
assert(merged.evidence.includes("BROWSER_HINTS"),"browser evidence missing");

console.log("Robinhood browser-hint tests: PASS");

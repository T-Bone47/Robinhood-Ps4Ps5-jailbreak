const fs = require("fs");
const { validateDependencyLock } = require("../../core/compatibility/dependencies");

const lock = JSON.parse(fs.readFileSync("database/dependency-lock.json", "utf8"));
const route = lock.routes["ps5-y2jb-v0.9"];

function assert(c, m) { if (!c) throw new Error(m); }

assert(validateDependencyLock(route).length === 0, "Y2JB dependency lock must be complete");
assert(route.dependencies.some(d => d.repo === "itsPLK/ps5-kexp"), "kexp missing");
assert(route.dependencies.some(d => d.repo === "itsPLK/ps5-elfldr"), "elfldr missing");
assert(route.dependencies.some(d => d.repo === "itsPLK/ps5-unified-autoloader"), "unified autoloader missing");

console.log("Robinhood dependency tests: PASS");

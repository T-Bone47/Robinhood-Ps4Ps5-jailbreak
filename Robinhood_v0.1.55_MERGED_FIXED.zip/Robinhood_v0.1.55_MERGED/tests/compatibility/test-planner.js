const { makePlan } = require("../../core/compatibility/planner");

function assert(c, m) { if (!c) throw new Error(m); }

const unknown = makePlan(null);
assert(unknown.action === "NONE", "unknown must have no action");

const reported = makePlan({
  status:"REPORTED",
  source_ids:["x"]
});
assert(reported.action === "RESEARCH", "reported route must be research-only");

const verified = makePlan({
  status:"VERIFIED",
  console:"PS4",
  firmware:"9.00",
  entry_route:"example",
  components:{webkit:"x",kernel:"y",hen:"z"},
  source_ids:["a"]
});
assert(verified.action === "PREPARE_VERIFIED_ROUTE", "verified route should prepare");
assert(verified.components.hen === "z", "components were lost");

console.log("Robinhood planner tests: PASS");

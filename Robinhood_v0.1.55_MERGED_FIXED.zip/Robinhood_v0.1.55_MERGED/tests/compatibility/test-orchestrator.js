const { makeOrchestrator } = require("../../core/execution/orchestrator");
function assert(c,m){if(!c)throw new Error(m)}
let o=makeOrchestrator({route:{status:"REPORTED"},adapter:{execution_enabled:true}});
assert(o.start().phase==="BLOCKED","reported route must block");
o=makeOrchestrator({route:{status:"VERIFIED"},adapter:{execution_enabled:false}});
assert(o.start().phase==="BLOCKED","declaration-only adapter must block");
o=makeOrchestrator({route:{status:"VERIFIED"},adapter:{execution_enabled:true}});
assert(o.start().phase==="ENVIRONMENT","verified executable adapter should enter environment phase");
console.log("Robinhood execution-orchestrator tests: PASS");

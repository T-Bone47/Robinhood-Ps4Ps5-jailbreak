const {evaluateCapability}=require("../../core/compatibility/capabilities");
function assert(c,m){if(!c)throw new Error(m)}

let r=evaluateCapability({
 status:"REPORTED",
 evidence_grade:"PRIMARY_REPORTED",
 prerequisites:["BD-J"]
},{prerequisites:["BD-J"]});
assert(r.selectable===false && r.state==="RESEARCH_ONLY","reported route must remain research-only");

r=evaluateCapability({
 status:"VERIFIED",
 evidence_grade:"PRIMARY_VERIFIED",
 prerequisites:["BD-J"]
},{prerequisites:["BD-J"]});
assert(r.selectable===true,"verified route with prerequisites should be eligible");

r=evaluateCapability({
 status:"VERIFIED",
 evidence_grade:"PRIMARY_VERIFIED",
 prerequisites:["BD-J"]
},{prerequisites:[]});
assert(r.selectable===false && r.state==="PREREQUISITES_MISSING","missing prerequisite must block");

console.log("Robinhood capability tests: PASS");

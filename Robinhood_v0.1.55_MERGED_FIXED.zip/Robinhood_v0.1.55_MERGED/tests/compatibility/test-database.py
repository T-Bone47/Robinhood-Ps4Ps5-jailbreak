import subprocess, sys
from pathlib import Path
root = Path(__file__).resolve().parents[2]
result = subprocess.run([sys.executable, str(root/'tools/validate_database.py')], cwd=root)
raise SystemExit(result.returncode)

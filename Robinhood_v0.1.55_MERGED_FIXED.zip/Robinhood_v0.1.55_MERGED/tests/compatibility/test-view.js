
function explain(route){
  if(!route) return {action:"RESEARCH"};
  if(route.status==="REPORTED") return {action:"REVIEW_EVIDENCE"};
  if(route.status==="VERIFIED") return {action:"VALIDATION_REVIEW"};
  return {action:"RESEARCH"};
}
function assert(c,m){if(!c)throw new Error(m)}
assert(explain(null).action==="RESEARCH","unknown route");
assert(explain({status:"REPORTED"}).action==="REVIEW_EVIDENCE","reported route");
assert(explain({status:"VERIFIED"}).action==="VALIDATION_REVIEW","verified route");
console.log("Robinhood compatibility-view tests: PASS");

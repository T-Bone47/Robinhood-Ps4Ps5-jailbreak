const { normalizeConsole, parseFirmware, validateEnvironment } =
  require("../../core/compatibility/environment");

function assert(c, m) { if (!c) throw new Error(m); }

assert(normalizeConsole("ps4") === "PS4", "PS4 normalization failed");
assert(normalizeConsole("PlayStation 5") === "PS5", "PS5 normalization failed");
assert(normalizeConsole("x") === null, "invalid console accepted");

assert(parseFirmware("9.00").numeric === 9, "9.00 parse failed");
assert(parseFirmware("12.52").numeric === 12.52, "12.52 parse failed");
assert(parseFirmware("abc") === null, "invalid firmware accepted");

assert(validateEnvironment("PS5","12.00").valid === true, "valid environment rejected");
assert(validateEnvironment("PS5","abc").valid === false, "invalid environment accepted");

console.log("Robinhood environment tests: PASS");

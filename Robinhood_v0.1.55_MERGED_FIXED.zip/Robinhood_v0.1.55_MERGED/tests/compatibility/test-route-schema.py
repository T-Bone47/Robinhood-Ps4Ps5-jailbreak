
from pathlib import Path
import json
root=Path(__file__).resolve().parents[2]
db=root/"database"
schema=json.loads((db/"firmware-route-schema.json").read_text())
data=json.loads((db/"firmware-route-table.json").read_text())
for r in data["routes"]:
    for k in schema["required"]:
        assert k in r, f"missing {k}"
    assert r["status"] in schema["allowed_statuses"], r["status"]
    assert isinstance(r["sources"],list), r["firmware"]
print("Robinhood route-schema tests: PASS")

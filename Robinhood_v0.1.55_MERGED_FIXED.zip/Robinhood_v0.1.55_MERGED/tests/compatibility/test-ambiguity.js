const { resolve } = require("../../core/compatibility/engine");
const { makePlan } = require("../../core/compatibility/planner");

function assert(c, m) { if (!c) throw new Error(m); }

const db = [
  {console:"PS5", min_firmware:9, max_firmware:12, status:"REPORTED"},
  {console:"PS5", min_firmware:10, max_firmware:12.7, status:"REPORTED"}
];

const result = resolve(db, "PS5", 11);
assert(result.status === "AMBIGUOUS", "overlapping routes must be ambiguous");

const plan = makePlan(result);
assert(plan.action === "RESEARCH", "ambiguous route must not execute");
assert(plan.matches.length === 2, "all matching routes must be retained");

console.log("Robinhood ambiguity tests: PASS");

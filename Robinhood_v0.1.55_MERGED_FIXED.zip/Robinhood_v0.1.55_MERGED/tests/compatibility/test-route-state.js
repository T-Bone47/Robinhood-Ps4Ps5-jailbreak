const { classify, canShowStartButton } = require("../../core/compatibility/route-state");

function assert(c, m) { if (!c) throw new Error(m); }

assert(classify({status:"VERIFIED"}) === "READY", "verified must be READY");
assert(classify({status:"REPORTED"}) === "RESEARCH", "reported must be RESEARCH");
assert(classify({status:"PARTIAL"}) === "PARTIAL", "partial must remain PARTIAL");
assert(classify({status:"UNKNOWN"}) === "UNKNOWN", "unknown must remain UNKNOWN");

assert(canShowStartButton({status:"VERIFIED"}) === true, "verified can start");
assert(canShowStartButton({status:"REPORTED"}) === false, "reported cannot start");
assert(canShowStartButton({status:"PARTIAL"}) === false, "partial cannot start");
assert(canShowStartButton({status:"UNKNOWN"}) === false, "unknown cannot start");

console.log("Robinhood route-state tests: PASS");

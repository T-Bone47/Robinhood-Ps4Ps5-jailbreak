const { routePresentation } = require("../../frontend/js/ui-state");

function assert(c, m) { if (!c) throw new Error(m); }

assert(routePresentation(null).action === "NONE", "null route must have no action");
assert(routePresentation({status:"VERIFIED"}).action === "PREPARE", "verified route must prepare");
assert(routePresentation({status:"REPORTED"}).action === "RESEARCH", "reported route must research");
assert(routePresentation({status:"PARTIAL"}).action === "RESEARCH", "partial route must research");
assert(routePresentation({status:"EXPERIMENTAL"}).action === "RESEARCH", "experimental route must research");

console.log("Robinhood UI-state tests: PASS");

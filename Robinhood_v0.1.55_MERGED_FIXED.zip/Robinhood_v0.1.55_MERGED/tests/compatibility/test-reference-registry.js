const { loadRegistry, findReferenceRoute } = require("../../core/adapters/registry");
function assert(c,m){if(!c)throw new Error(m)}
const r=loadRegistry();
assert(r.routes.length===4,"reference route registry incomplete");
assert(findReferenceRoute(r,"PS4","6.72").id==="ps4jb-672-reference","6.72 reference missing");
assert(findReferenceRoute(r,"PS4","9.00").id==="ps4jb-900-reference","9.00 reference missing");
assert(findReferenceRoute(r,"PS5","12.52")===null,"PS5 route should not be fabricated");
assert(r.routes.every(x=>x.execution_enabled===false),"reference routes must never execute");
console.log("Robinhood reference-registry tests: PASS");

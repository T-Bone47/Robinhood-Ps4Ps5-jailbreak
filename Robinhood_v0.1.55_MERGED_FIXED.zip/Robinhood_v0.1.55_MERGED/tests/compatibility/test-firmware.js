const {parseFirmware,inRange,normalizeRange}=require("../../core/compatibility/firmware");
function assert(c,m){if(!c)throw new Error(m)}
assert(parseFirmware("12.52").numeric===12.52,"12.52 parse");
assert(parseFirmware("9").numeric===9,"integer parse");
assert(parseFirmware("12.5").numeric===12.5,"12.5 parse");
assert(parseFirmware("x")===null,"invalid parse");
assert(inRange("12.52",12.02,12.52),"range upper bound");
assert(!inRange("12.53",12.02,12.52),"range overflow");
assert(normalizeRange(12.02,12.52)!==null,"valid range");
assert(normalizeRange(12.52,12.02)===null,"inverted range");
console.log("Robinhood firmware tests: PASS");

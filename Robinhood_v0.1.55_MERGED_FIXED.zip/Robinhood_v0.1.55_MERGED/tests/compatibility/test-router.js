const fs = require("fs");
const { parseFirmware } = require("../../core/firmware/parse");
const { resolve, validateEntry } = require("../../core/compatibility/engine");

const db = JSON.parse(
  fs.readFileSync("database/compatibility.json", "utf8")
);

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

assert(parseFirmware("9.00").numeric === 9, "9.00 parse failed");
assert(parseFirmware("9.60").numeric === 9.6, "9.60 parse failed");
assert(parseFirmware("10.00").numeric === 10, "10.00 parse failed");
assert(parseFirmware("12.52").numeric === 12.52, "12.52 parse failed");
assert(parseFirmware("abc") === null, "invalid firmware accepted");

for (const item of db) {
  assert(validateEntry(item).length === 0,
    `invalid database entry: ${item.console} ${item.firmware}`);
}

const unknown = resolve(db, "PS4", "11.50");
assert(unknown === null || unknown.status === "UNKNOWN",
  "unrecorded firmware must remain UNKNOWN");

const target = resolve(db, "PS4", "12.52");
assert(target.status === "REPORTED",
  "12.52 must resolve to the documented Poops research route");

const badConsole = resolve(db, "Xbox", "9.00");
assert(badConsole === null || badConsole.status === "UNKNOWN", "unknown console must remain UNKNOWN");

console.log("Robinhood routing tests: PASS");

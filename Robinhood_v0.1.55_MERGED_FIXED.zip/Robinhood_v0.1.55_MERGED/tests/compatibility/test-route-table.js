
const fs=require("fs");
const data=JSON.parse(fs.readFileSync("database/firmware-route-table.json"));
function assert(c,m){if(!c)throw new Error(m)}
assert(data.routes.length>=8,"route table incomplete");
for(const r of data.routes){
  assert(r.console==="PS4","invalid console");
  assert(r.firmware,"firmware missing");
  assert(r.entry,"entry missing");
  assert(r.kernel,"kernel field missing");
  assert(r.hen,"HEN field missing");
  assert(["RESEARCH_ONLY","REPORTED","REPORTED_REQUIRES_HARDWARE_VALIDATION","UNSUPPORTED_BY_CURRENT_AUDIT"].includes(r.status),"invalid route status");
}
const twelve52=data.routes.find(r=>r.firmware==="12.50-12.52");
assert(twelve52.status==="REPORTED_REQUIRES_HARDWARE_VALIDATION","12.52 must remain gated");
console.log("Robinhood firmware-route-table tests: PASS");

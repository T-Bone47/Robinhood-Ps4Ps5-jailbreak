
const {createRuntimeAdapter}=require("../../core/adapters/runtime-adapter");
function assert(c,m){if(!c)throw new Error(m)}
const unverified={id:"r",console:"PS4",firmware:"9.00",sourceIds:["s"],status:"REPORTED"};
const blocked=createRuntimeAdapter(unverified,{start:()=>({status:"STARTED"})});
assert(blocked.start().status==="REVIEW_REQUIRED","unverified adapter crossed gate");

const verified={...unverified,status:"VERIFIED"};
const noTransport=createRuntimeAdapter(verified,{});
assert(noTransport.start().status==="FAILED","missing transport not reported");

const events=createRuntimeAdapter(verified,{start:()=>({status:"STARTED"})});
assert(events.start().status==="STARTED","verified transport not called");
assert(events.acceptEvent({routeId:"r",type:"ENTRY_STARTED"}).accepted,"valid event rejected");
assert(!events.acceptEvent({routeId:"other",type:"ENTRY_STARTED"}).accepted,"route mismatch accepted");
assert(!events.acceptEvent({routeId:"r",type:"COMPLETE"}).accepted,"invalid completion accepted");
console.log("Robinhood runtime-adapter tests: PASS");

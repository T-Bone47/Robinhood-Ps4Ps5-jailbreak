
const fs=require("fs");
const data=JSON.parse(fs.readFileSync("database/upstream-route-registry.json"));
function assert(c,m){if(!c)throw new Error(m)}
assert(data.routes.length>=4,"expected upstream route records");
for(const r of data.routes){
  assert(r.source_ids===undefined || Array.isArray(r.source_ids),"invalid source IDs");
  assert(r.source_ids || r.sourceIds,"route provenance missing");
  assert(r.execution_status!=="VERIFIED","research registry must not create executable routes");
}
console.log("Robinhood upstream-route tests: PASS");

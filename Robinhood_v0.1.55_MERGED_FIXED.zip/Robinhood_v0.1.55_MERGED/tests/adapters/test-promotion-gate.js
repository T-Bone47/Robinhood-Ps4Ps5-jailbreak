
const fs=require("fs");
const {promotionDecision}=require("../../core/adapters/promotion-gate");
function assert(c,m){if(!c)throw new Error(m)}
const data=JSON.parse(fs.readFileSync("database/provenance-lock.json"));
assert(data.records.length>0,"provenance registry empty");
for(const r of data.records){
  const d=promotionDecision(r);
  assert(d.promotable===false,"unverified route was promoted");
  assert(d.reasons.length>0,"gate supplied no reason");
}
const verified={
 exact_release_or_commit:"abc123",
 required_files:["payload-reference"],
 sha256:["deadbeef"],
 license:"MIT",
 hardware_validation:"TEST_RECORD_001",
 status:"VERIFIED",
 contradictions:[]
};
assert(promotionDecision(verified).promotable===true,"complete provenance should promote");
const contradicted={...verified,contradictions:["README vs release"]};
assert(promotionDecision(contradicted).promotable===false,"contradicted route must not promote");
console.log("Robinhood promotion-gate tests: PASS");

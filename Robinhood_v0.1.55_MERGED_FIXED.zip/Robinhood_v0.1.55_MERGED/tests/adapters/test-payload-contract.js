
const {validateAsset,validatePayloadResult}=require("../../core/adapters/payload-contract");
function assert(c,m){if(!c)throw new Error(m)}
assert(validateAsset({class:"HEN_PAYLOAD",source:"upstream",required:true,integrity_required:true}).valid,"valid asset rejected");
assert(!validateAsset({class:"HEN_PAYLOAD",source:"mirror",required:true,integrity_required:true}).valid,"mirror accepted");
assert(!validatePayloadResult({status:"READY"}).valid,"READY falsely accepted");
assert(validatePayloadResult({status:"LOADED",payloadId:"goldhen",routeId:"route"}).valid,"valid payload result rejected");
console.log("Robinhood payload-contract tests: PASS");


const {validateResult,terminal}=require("../../core/adapters/result-contract");
function assert(c,m){if(!c)throw new Error(m)}
assert(validateResult({routeId:"r",type:"ENTRY_STARTED"}).valid,"entry result rejected");
assert(validateResult({routeId:"r",type:"COMPLETE",payloadId:"goldhen"}).valid,"complete result rejected");
assert(!validateResult({routeId:"r",type:"COMPLETE"}).valid,"fake completion accepted");
assert(!validateResult({routeId:"r",type:"FAILED"}).valid,"unstructured failure accepted");
assert(terminal("COMPLETE") && terminal("FAILED"),"terminal states broken");
console.log("Robinhood adapter-result contract tests: PASS");


const {validateAdapter,canExecute}=require("../../core/adapters/contract");
const {createOrchestrator}=require("../../core/adapters/orchestrator");
function assert(c,m){if(!c)throw new Error(m)}
const reported={id:"reported-route",console:"PS4",firmware:"9.00",sourceIds:["source-1"],status:"REPORTED"};
assert(validateAdapter(reported).valid===false,"reported adapter must be gated");
assert(canExecute(reported)===false,"reported adapter must not execute");
const verified={...reported,id:"verified-route",status:"VERIFIED"};
assert(canExecute(verified)===true,"verified adapter should pass");
const o=createOrchestrator(verified);
assert(o.start().phase==="ENTRY","start transition failed");
assert(o.markKernel().phase==="KERNEL","kernel transition failed");
assert(o.markPayload().phase==="PAYLOAD","payload transition failed");
assert(o.complete().phase==="COMPLETE","complete transition failed");
const blocked=createOrchestrator(reported);
assert(blocked.start().phase==="REVIEW_REQUIRED","review gate failed");
console.log("Robinhood adapter-contract tests: PASS");

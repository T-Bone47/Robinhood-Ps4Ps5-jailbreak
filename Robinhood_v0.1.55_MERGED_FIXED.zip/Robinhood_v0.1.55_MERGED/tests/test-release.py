
from pathlib import Path
import json
import re

root = Path(__file__).resolve().parents[1]
release = json.loads((root/"release.json").read_text())
assert re.fullmatch(r"0\.1\.\d+", release["version"])
assert release["release_channel"] == "research-preview"
assert release["artifact_policy"]["execution_routes_enabled"] is False

print("Robinhood release configuration tests: PASS")

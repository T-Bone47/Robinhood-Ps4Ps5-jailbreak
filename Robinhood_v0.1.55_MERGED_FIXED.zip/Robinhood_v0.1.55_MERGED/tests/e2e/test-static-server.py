
from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from threading import Thread
from urllib.request import urlopen
import os

root=Path(__file__).resolve().parents[2]
os.chdir(root)

class Handler(SimpleHTTPRequestHandler):
    def log_message(self,*args): pass

server=ThreadingHTTPServer(("127.0.0.1",0),Handler)
thread=Thread(target=server.serve_forever,daemon=True)
thread.start()

try:
    port=server.server_address[1]
    for path in ["/index.html","/research.html","/database/compatibility.json","/frontend/service-worker.js"]:
        with urlopen(f"http://127.0.0.1:{port}{path}",timeout=3) as response:
            assert response.status==200, path
finally:
    server.shutdown()
    thread.join(timeout=2)

print("Robinhood static-server smoke test: PASS")


from pathlib import Path
import json

root=Path(__file__).resolve().parents[2]
required=[
    "index.html",
    "research.html",
    "frontend/service-worker.js",
    "frontend/js/compatibility-db.js",
    "frontend/js/environment-state.js",
    "database/compatibility.json",
    "database/sources.json",
    "database/route-explanations.json",
    "database/research-dashboard.json",
    "database/DATA-INTEGRITY-MANIFEST.json",
    "release.json",
    "FINAL_RELEASE_CHECKLIST.json",
    "database/reference/legacy-host-routes.json",
    "frontend/js/reference-routes.js",
    "frontend/js/execution-orchestrator.js"
]

for rel in required:
    assert (root/rel).exists(), f"missing artifact: {rel}"

compat=json.loads((root/"database/compatibility.json").read_text())
assert compat, "compatibility database empty"

for route in compat:
    assert route.get("console") in {"PS4","PS5"}, "invalid console"
    assert route.get("source_ids"), "route has no provenance"
    assert route.get("status"), "route has no status"

print("Robinhood E2E research-host smoke test: PASS")

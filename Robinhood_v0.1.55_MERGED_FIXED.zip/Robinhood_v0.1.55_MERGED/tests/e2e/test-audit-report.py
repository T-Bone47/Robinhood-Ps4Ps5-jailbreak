
from pathlib import Path
import json

root=Path(__file__).resolve().parents[2]
p=root/"database/RELEASE-CANDIDATE-AUDIT.json"
data=json.loads(p.read_text())

assert data["project"]=="Robinhood"
assert data["execution_enabled"] is False
assert data["quality_gates"]["hardware_validation"]=="NOT_COMPLETED_BY_AUTOMATION"
assert data["research_summary"]["compatibility_routes"]>0

print("Robinhood release-candidate audit test: PASS")

const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const flow=fs.readFileSync("frontend/js/jailbreak-flow.js","utf8");
const panel=fs.readFileSync("frontend/js/jailbreak-panel.js","utf8");
assert(flow.includes("REVIEW_REQUIRED"),"review gate missing");
assert(flow.includes('status!=="VERIFIED"'),"verification gate missing");
assert(panel.includes("No execution adapter is installed"),"execution safety message missing");
console.log("Robinhood jailbreak-flow UI tests: PASS");


from pathlib import Path
import json,re

root=Path(__file__).resolve().parents[2]
compat=json.loads((root/"database/compatibility.json").read_text())

bad=re.compile(r"\bguaranteed\b|\b100%\b|\bconfirmed jailbreak\b|\bworks on all\b",re.I)
for r in compat:
    text=" ".join(str(r.get(k,"")) for k in ["summary","user_message","notes"])
    assert not bad.search(text), r.get("chain")

html=(root/"research.html").read_text().lower()
assert "research" in html
print("Robinhood final-language tests: PASS")

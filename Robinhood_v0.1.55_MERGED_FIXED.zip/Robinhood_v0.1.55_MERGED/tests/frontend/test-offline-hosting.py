
from pathlib import Path
import json

root = Path(__file__).resolve().parents[2]
sw = (root / "frontend/service-worker.js").read_text()
manifest = json.loads((root / "frontend/offline-assets.json").read_text())
deployment = json.loads((root / "deployment.json").read_text())

assert "self.addEventListener(\"install\"" in sw
assert "self.addEventListener(\"fetch\"" in sw
assert "caches.open" in sw
assert "/index.html" in manifest["assets"]
assert deployment["artifacts"]["github_pages"] == "dist/"
assert deployment["artifacts"]["lan_static"] == "dist/"
assert deployment["security"]["no_third_party_runtime_scripts"] is True

print("Robinhood offline/hosting tests: PASS")

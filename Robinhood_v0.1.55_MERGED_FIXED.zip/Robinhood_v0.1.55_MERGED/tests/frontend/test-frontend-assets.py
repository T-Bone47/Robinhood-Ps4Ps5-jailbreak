from pathlib import Path
root = Path(__file__).resolve().parents[2]
html = (root / "index.html").read_text()
css = (root / "frontend/css/base.css").read_text()
db = (root / "frontend/js/compatibility-db.js").read_text()

required = [
    "Robinhood", "console", "firmware", "check",
    "Research mode", "Advanced mode", "ui-state.js"
]
for item in required:
    assert item in html, f"missing HTML element/text: {item}"

for item in ["--bg:", "--surface:", ".form-grid", ".result-card", "@media"]:
    assert item in css, f"missing design token/rule: {item}"

assert "ROBINHOOD_COMPATIBILITY" in db
print("Robinhood frontend asset tests: PASS")

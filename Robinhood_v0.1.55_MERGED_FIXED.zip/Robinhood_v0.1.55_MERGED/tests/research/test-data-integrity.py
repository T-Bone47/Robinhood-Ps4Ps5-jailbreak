
from pathlib import Path
import json, hashlib

root=Path(__file__).resolve().parents[2]
db=root/"database"
m=json.loads((db/"DATA-INTEGRITY-MANIFEST.json").read_text())

for rel,meta in m["files"].items():
    p=db/rel
    assert p.exists(), rel
    assert hashlib.sha256(p.read_bytes()).hexdigest()==meta["sha256"], rel
    assert p.stat().st_size==meta["bytes"], rel

print("Robinhood data-integrity tests: PASS")

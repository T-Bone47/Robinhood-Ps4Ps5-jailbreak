const { validateRouteContract } =
  require("../../core/research/route-contract");

function assert(c,m){if(!c)throw new Error(m)}

assert(validateRouteContract({
  console:"PS4", status:"REPORTED", source_ids:["x"],
  min_firmware:12.02, max_firmware:12.52
}).length===0,"valid route rejected");

assert(validateRouteContract({
  console:"PS4", status:"REPORTED", source_ids:[]
}).length>0,"missing source must fail");

console.log("Robinhood route contract tests: PASS");


from pathlib import Path
import json

root=Path(__file__).resolve().parents[2]
snap=json.loads((root/"database/AUDIT-SNAPSHOT.json").read_text())
assert snap["project"]=="Robinhood"
assert snap["snapshot_date"]
assert len(snap["database_files"]) > 0
print("Robinhood audit-snapshot tests: PASS")

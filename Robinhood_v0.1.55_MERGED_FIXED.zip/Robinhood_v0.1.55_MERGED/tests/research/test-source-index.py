
from pathlib import Path
import json

root = Path(__file__).resolve().parents[2]
sources = json.loads((root/"database/sources.json").read_text())
ids = [s["source_id"] for s in sources]

assert len(ids) == len(set(ids)), "duplicate source_id"
for s in sources:
    assert s.get("source_id")
    assert s.get("url")
    assert s.get("checked")
    assert s.get("evidence")

print("Robinhood source-index tests: PASS")

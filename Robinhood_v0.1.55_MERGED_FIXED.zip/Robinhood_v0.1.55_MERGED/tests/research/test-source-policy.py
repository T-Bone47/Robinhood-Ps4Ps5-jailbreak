
from pathlib import Path
import json
root=Path(__file__).resolve().parents[2]
policy=json.loads((root/"database/source-policy.json").read_text())
sources=json.loads((root/"database/sources.json").read_text())

assert "EXPLOIT_PRIMARY" in policy["host_source_types"]
assert all(s.get("authority_class") for s in sources)

print("Robinhood source-policy tests: PASS")

const {freshnessStatus}=require("../../core/research/freshness");
function assert(c,m){if(!c)throw new Error(m)}
assert(freshnessStatus("2026-08-26","2026-08-26",30)==="CURRENT","current failed");
assert(freshnessStatus("2026-07-01","2026-08-26",30)==="AGING","aging failed");
assert(freshnessStatus("2026-01-01","2026-08-26",30)==="STALE","stale failed");
console.log("Robinhood freshness tests: PASS");

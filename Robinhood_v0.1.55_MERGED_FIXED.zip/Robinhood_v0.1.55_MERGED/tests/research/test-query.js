const { byConsole, byStatus, byFirmware } =
  require("../../core/research/query");

function assert(c, m) { if (!c) throw new Error(m); }

const records = [
  {console:"PS4", min_firmware:12.02, max_firmware:12.52, status:"REPORTED"},
  {console:"PS5", min_firmware:10.20, max_firmware:12.70, status:"REPORTED"},
  {console:"PS4", min_firmware:7, max_firmware:11, status:"VERIFIED"}
];

assert(byConsole(records,"PS4").length === 2, "PS4 filter failed");
assert(byStatus(records,"REPORTED").length === 2, "status filter failed");
assert(byFirmware(records,"PS4",12.52).length === 1, "firmware query failed");
assert(byFirmware(records,"PS5",12.70).length === 1, "PS5 firmware query failed");

console.log("Robinhood research query tests: PASS");

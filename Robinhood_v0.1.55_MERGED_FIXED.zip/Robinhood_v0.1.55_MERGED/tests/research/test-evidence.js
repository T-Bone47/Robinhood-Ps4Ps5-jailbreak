const { evidenceGrade, executionState } =
  require("../../core/research/evidence");

function assert(c,m){if(!c)throw new Error(m)}

assert(evidenceGrade({status:"VERIFIED"})==="PRIMARY_VERIFIED","verified grade failed");
assert(evidenceGrade({status:"REPORTED"})==="PRIMARY_REPORTED","reported grade failed");
assert(executionState({status:"REPORTED"})==="RESEARCH_ONLY","reported route must be research-only");
assert(executionState({status:"VERIFIED",reliability:"UNKNOWN"})==="RESEARCH_ONLY","unknown reliability must block execution review");

console.log("Robinhood evidence tests: PASS");

const {canTransition, validateTransition}=require("../../core/research/lifecycle");
function assert(c,m){if(!c)throw new Error(m)}
assert(canTransition("DISCOVERED","CORROBORATED"),"discover transition");
assert(!canTransition("DISCOVERED","VERIFIED"),"unsafe promotion");
assert(validateTransition({
 status:"REPORTED", evidence_grade:"PRIMARY_REPORTED"
},"VERIFIED").valid===false,"reported route cannot verify");
assert(validateTransition({
 status:"REPORTED", evidence_grade:"PRIMARY_VERIFIED",
 validation:{device_tested:true}
},"VERIFIED").valid===true,"valid promotion rejected");
console.log("Robinhood lifecycle tests: PASS");

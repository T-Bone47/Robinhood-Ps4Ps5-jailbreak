
from pathlib import Path
import json

root = Path(__file__).resolve().parents[2]
data = json.loads((root/"database/research-dashboard.json").read_text())
html = (root/"research.html").read_text()

assert data["summary"]["sources"] > 0
assert data["summary"]["claims"] > 0
assert data["summary"]["repositories"] > 0
assert "research-dashboard.js" in html

print("Robinhood research dashboard tests: PASS")

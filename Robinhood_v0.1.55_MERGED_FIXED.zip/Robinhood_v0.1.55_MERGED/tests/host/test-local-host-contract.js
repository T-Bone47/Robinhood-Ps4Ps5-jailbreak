
const {validateHostConfig,eventAccepted}=require("../../core/host/local-host-contract");
function assert(c,m){if(!c)throw new Error(m)}
assert(validateHostConfig({protocol:"http",port:8080,bindAddress:"0.0.0.0",executionAdapterRequired:true}).valid,"valid host rejected");
assert(!validateHostConfig({protocol:"https",port:8080,bindAddress:"0.0.0.0",executionAdapterRequired:true}).valid,"invalid protocol accepted");
assert(eventAccepted({type:"ENTRY_STARTED",routeId:"r1"}),"valid adapter event rejected");
assert(!eventAccepted({type:"ENTRY_STARTED"}),"route-less event accepted");
console.log("Robinhood local-host contract tests: PASS");

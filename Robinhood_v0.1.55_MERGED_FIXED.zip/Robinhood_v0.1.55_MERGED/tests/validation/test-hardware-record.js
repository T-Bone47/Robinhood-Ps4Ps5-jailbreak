
const {validate,canPromote}=require("../../core/validation/hardware-record");
function assert(c,m){if(!c)throw new Error(m)}
const base={
 recordId:"HV-TEST-001",console:"PS4",firmware:"9.00",routeId:"route",
 adapterVersion:"adapter-test",testDate:"2026-08-26",environment:"controlled-lab",
 steps:["boot","open host","observe route"],observations:["software-only test"],
 result:"INCONCLUSIVE",operator:"test"
};
assert(validate(base).valid,"valid record rejected");
assert(!canPromote(base),"inconclusive record promoted");
assert(canPromote({...base,result:"PASS"}),"pass record not promotable");
assert(!validate({...base,result:"UNKNOWN"}).valid,"invalid result accepted");
console.log("Robinhood hardware-validation contract tests: PASS");


const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const s=fs.readFileSync("frontend/js/route-handoff.js","utf8");
assert(s.includes("EXECUTION_WAITING"),"execution handoff state missing");
assert(s.includes("Adapter event rejected"),"adapter route validation missing");
assert(s.includes("PAYLOAD_RUNNING"),"payload state missing");
assert(s.includes("COMPLETE"),"completion state missing");
console.log("Robinhood browser-route-handoff tests: PASS");


const fs=require("fs");
const {parseUserAgent,normalizeFirmware}=require("../../core/routing/firmware-detector");
const {selectRoute}=require("../../core/routing/route-selector");
function assert(c,m){if(!c)throw new Error(m)}
const d=parseUserAgent("Mozilla/5.0 (PlayStation 4 9.00) AppleWebKit");
assert(d.console==="PS4" && d.firmware==="9.00","UA parse failed");
assert(normalizeFirmware("9")===null,"invalid firmware accepted");
const routes=JSON.parse(fs.readFileSync("database/firmware-route-table.json")).routes;
const s=selectRoute("PS4","9.00",routes);
assert(s.route,"9.00 route missing");
assert(s.status!=="VERIFIED","research route accidentally verified");
const u=selectRoute("PS4","99.99",routes);
assert(u.status==="UNSUPPORTED","unknown firmware accepted");
console.log("Robinhood firmware-routing tests: PASS");

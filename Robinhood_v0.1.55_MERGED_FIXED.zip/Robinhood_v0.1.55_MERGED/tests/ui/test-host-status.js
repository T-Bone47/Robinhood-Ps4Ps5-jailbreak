
const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const s=fs.readFileSync("frontend/js/host-status.js","utf8");
for(const x of ["READY","ROUTE_SELECTED","EXECUTION_WAITING","ENTRY_RUNNING",
"KERNEL_RUNNING","PAYLOAD_RUNNING","COMPLETE","FAILED","LOCKED"])
  assert(s.includes('"'+x+'"') || s.includes("'"+x+"'"),"missing status "+x);
console.log("Robinhood host-status tests: PASS");


const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const s=fs.readFileSync("frontend/js/firmware-session.js","utf8");
assert(s.includes("localStorage"),"persistent storage missing");
assert(s.includes("robinhood.firmware.session.v1"),"session key missing");
assert(s.includes("selectedTool"),"selected tool state missing");
assert(s.includes("clear"),"session clear operation missing");
console.log("Robinhood firmware-session tests: PASS");

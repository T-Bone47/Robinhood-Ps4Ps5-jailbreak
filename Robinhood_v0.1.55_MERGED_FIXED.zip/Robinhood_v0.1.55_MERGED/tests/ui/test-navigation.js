
const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const s=fs.readFileSync("frontend/js/navigation.js","utf8");
for(const x of ["HOME","FIRMWARE","TOOL"]) assert(s.includes('"'+x+'"'),"missing "+x);
assert(s.includes("function firmware"),"firmware navigation missing");
assert(s.includes("function tool"),"tool navigation missing");
console.log("Robinhood navigation tests: PASS");

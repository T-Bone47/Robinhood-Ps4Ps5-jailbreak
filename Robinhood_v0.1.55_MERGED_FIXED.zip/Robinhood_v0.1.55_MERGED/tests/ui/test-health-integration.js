
const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const h=fs.readFileSync("index.html","utf8");
assert(h.includes("frontend/js/host-health.js"),"health module missing");
assert(h.includes("RobinhoodHostHealth"),"health module not wired");
assert(h.includes('id="health-badge"'),"health badge missing");
console.log("Robinhood health-integration tests: PASS");

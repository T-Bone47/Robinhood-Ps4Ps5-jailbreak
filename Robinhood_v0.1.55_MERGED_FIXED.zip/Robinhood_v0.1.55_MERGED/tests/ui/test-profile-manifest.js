
const fs=require("fs");
const d=JSON.parse(fs.readFileSync("frontend/firmware-profile-manifest.json"));
function assert(c,m){if(!c)throw new Error(m)}
for(const fw of ["6.72","7.02","7.5X","9.00"]){
 const p=d.profiles[fw];
 assert(p,"missing profile "+fw);
 assert(p.execution==="LOCKED","profile accidentally unlocked "+fw);
}
assert(d.rule.includes("never implies exploit compatibility"),"safety rule missing");
console.log("Robinhood firmware-profile-manifest tests: PASS");

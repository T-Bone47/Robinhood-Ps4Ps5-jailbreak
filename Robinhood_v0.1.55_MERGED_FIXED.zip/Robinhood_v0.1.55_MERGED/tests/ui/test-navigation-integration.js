
const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const h=fs.readFileSync("index.html","utf8");
assert(h.includes("frontend/js/navigation.js"),"navigation script missing");
assert(h.includes("navigation.firmware(fw)"),"firmware navigation not wired");
assert(h.includes("navigation.tool(fw,card.name)"),"tool navigation not wired");
assert(h.includes("RobinhoodBuildInfo"),"build info not wired");
console.log("Robinhood navigation integration tests: PASS");

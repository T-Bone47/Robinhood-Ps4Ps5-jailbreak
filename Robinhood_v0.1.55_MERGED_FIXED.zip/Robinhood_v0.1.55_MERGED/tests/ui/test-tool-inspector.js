
const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const h=fs.readFileSync("index.html","utf8");
assert(h.includes('id="tool-modal"'),"tool modal missing");
assert(h.includes('id="tool-modal-action"'),"tool action missing");
assert(h.includes("No privileged operation executed"),"locked execution message missing");
console.log("Robinhood tool-inspector tests: PASS");

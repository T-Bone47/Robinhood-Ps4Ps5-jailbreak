
const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const h=fs.readFileSync("index.html","utf8");
assert(h.includes("frontend/js/quick-actions.js"),"quick action module missing");
assert(h.includes('id="quick-actions"'),"quick action container missing");
assert(h.includes("quickActions.build"),"quick action builder not wired");
console.log("Robinhood quick-actions integration tests: PASS");

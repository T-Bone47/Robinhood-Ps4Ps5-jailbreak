
const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const s=fs.readFileSync("frontend/js/firmware-summary.js","utf8");
assert(s.includes("toolCount"),"tool count missing");
assert(s.includes("lockedCount"),"locked count missing");
assert(s.includes("execution"),"execution state missing");
console.log("Robinhood firmware-summary tests: PASS");


const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const h=fs.readFileSync("index.html","utf8");
assert(h.includes('frontend/js/host-status.js'),"shared host-status script missing");
assert(h.includes('window.RobinhoodHostStatus'),"host-status model not wired");
assert(h.includes('hostStatus.set("ROUTE_SELECTED"'),"route state not wired");
assert(h.includes('hostStatus.set("EXECUTION_WAITING"'),"execution gate state not wired");
console.log("Robinhood status-integration tests: PASS");

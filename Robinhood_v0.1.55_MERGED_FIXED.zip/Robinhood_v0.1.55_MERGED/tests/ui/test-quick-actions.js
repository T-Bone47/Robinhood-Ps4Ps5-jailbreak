
const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const s=fs.readFileSync("frontend/js/quick-actions.js","utf8");
assert(s.includes("EXPLOIT + GOLDHEN"),"primary quick action missing");
assert(s.includes("FTP"),"FTP quick action missing");
assert(s.includes("App Dumper"),"App Dumper mapping missing");
assert(s.includes("DB BackUp"),"DB backup mapping missing");
console.log("Robinhood quick-actions tests: PASS");

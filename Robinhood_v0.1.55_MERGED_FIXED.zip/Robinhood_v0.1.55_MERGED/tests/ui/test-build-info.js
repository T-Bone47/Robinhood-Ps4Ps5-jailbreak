
const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const s=fs.readFileSync("frontend/js/build-info.js","utf8");
assert(s.includes("Robinhood"),"app name missing");
assert(s.includes("0.1.51"),"version missing");
console.log("Robinhood build-info tests: PASS");

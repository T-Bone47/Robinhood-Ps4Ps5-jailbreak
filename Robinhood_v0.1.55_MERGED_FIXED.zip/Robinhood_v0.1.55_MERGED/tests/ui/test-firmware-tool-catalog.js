
const fs=require("fs");
const d=JSON.parse(fs.readFileSync("frontend/firmware-tool-catalog.json"));
function assert(c,m){if(!c)throw new Error(m)}
for(const fw of ["6.72","7.02","7.5X","9.00"]){
  const p=d.profiles[fw];
  assert(p,"missing "+fw);
  assert(p.primary.includes("GoldHEN"),"missing primary GoldHEN action");
  assert(p.toolCards.length>=15,"tool cards incomplete");
  assert(p.toolCards.every(x=>x.state==="LOCKED_UNTIL_VALIDATED"),"unlocked tool slipped through");
}
assert(d.profiles["9.00"].primary==="Exploit + GoldHEN V2b","9.00 primary mismatch");
console.log("Robinhood firmware-tool-catalog tests: PASS");

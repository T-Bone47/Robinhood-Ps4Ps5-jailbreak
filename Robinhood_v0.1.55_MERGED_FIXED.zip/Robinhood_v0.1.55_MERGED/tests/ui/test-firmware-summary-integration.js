
const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const h=fs.readFileSync("index.html","utf8");
assert(h.includes("frontend/js/firmware-summary.js"),"summary module missing");
assert(h.includes('id="firmware-summary"'),"summary UI missing");
assert(h.includes("summary-tools"),"tool count binding missing");
assert(h.includes("summary-locked"),"locked count binding missing");
console.log("Robinhood firmware-summary integration tests: PASS");

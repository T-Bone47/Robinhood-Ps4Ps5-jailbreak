
const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const s=fs.readFileSync("frontend/js/host-health.js","utf8");
for(const x of ["OFFLINE_ASSETS","ROUTE_TABLE","ADAPTER_GATE","HARDWARE_GATE"])
  assert(s.includes('"'+x+'"'),"missing health check "+x);
assert(s.includes("READY_FOR_ROUTE_SELECTION"),"ready state missing");
console.log("Robinhood host-health tests: PASS");


const fs=require("fs");
function assert(c,m){if(!c)throw new Error(m)}
const h=fs.readFileSync("index.html","utf8");
assert(h.includes("frontend/js/firmware-session.js"),"session script missing");
assert(h.includes("RobinhoodFirmwareSession"),"session model not wired");
assert(h.includes("firmwareSession.write"),"session persistence not wired");
assert(h.includes("savedSession"),"session restore not wired");
console.log("Robinhood session-integration tests: PASS");

(async function () {
  const summary = document.getElementById("summary");
  const targets = document.getElementById("targets");

  try {
    const response = await fetch("database/research-dashboard.json");
    const data = await response.json();

    summary.textContent = JSON.stringify(data.summary, null, 2);
    targets.innerHTML = data.research_targets.map(target =>
      `<div class="result-row" style="margin-top:8px">
        <strong>${target.console} ${target.firmware}</strong>
        — ${target.state} · reliability: ${target.reliability}
      </div>`
    ).join("");
  } catch {
    summary.textContent = "Research dashboard data unavailable.";
    targets.textContent = "Run from the Robinhood static host.";
  }
})();

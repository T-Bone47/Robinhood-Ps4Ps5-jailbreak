function provenanceSummary(entry, sourceMap) {
  const ids = entry?.source_ids || [];
  return ids.map(id => sourceMap[id]).filter(Boolean).map(source => ({
    id: source.source_id,
    title: source.title,
    url: source.url,
    checked: source.checked,
    type: source.type,
    evidence: source.evidence
  }));
}

if (typeof module !== "undefined") module.exports = { provenanceSummary };

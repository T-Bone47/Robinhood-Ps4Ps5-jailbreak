window.ROBINHOOD_SOURCES = {
  "github-pppwn": {
    "source_id": "github-pppwn",
    "title": "TheOfficialFloW/PPPwn",
    "url": "https://github.com/TheOfficialFlow/PPPwn",
    "type": "upstream_github",
    "checked": "2026-08-25",
    "evidence": "README explicitly lists PS4 firmware support from 7.00 through 11.00 and describes PPPwn as a kernel RCE proof of concept."
  },
  "github-goldhen": {
    "source_id": "github-goldhen",
    "title": "GoldHEN/GoldHEN",
    "url": "https://github.com/GoldHEN/GoldHEN",
    "type": "upstream_github",
    "checked": "2026-08-25",
    "evidence": "Repository/release documentation describes GoldHEN as a PS4 Homebrew Enabler; current release notes list support through firmware 11.00 and warn that BinLoader is experimental."
  },
  "github-goldhen-releases": {
    "source_id": "github-goldhen-releases",
    "title": "GoldHEN releases",
    "url": "https://github.com/GoldHEN/GoldHEN/releases",
    "type": "upstream_github_release",
    "checked": "2026-08-25",
    "evidence": "Release documentation lists supported firmware including 5.05, 6.71/6.72, 9.00, 9.60, 10.00/10.01, 10.50, 10.70/10.71 and 11.00."
  },
  "github-psfree-nazky": {
    "source_id": "github-psfree-nazky",
    "title": "Nazky/PSFree",
    "url": "https://github.com/Nazky/PSFree",
    "type": "github_fork",
    "checked": "2026-08-25",
    "evidence": "Repository describes itself as an unstable work-in-progress multi-firmware PS4/PS5 website but its current table says PS4 7.00-9.60 only. It includes local hosting files."
  },
  "github-ps5-webkit-autoloader": {
    "source_id": "github-ps5-webkit-autoloader",
    "title": "itsPLK/ps5-webkit-autoloader",
    "url": "https://github.com/itsPLK/ps5-webkit-autoloader",
    "type": "upstream_github",
    "checked": "2026-08-25",
    "evidence": "README says the autoloader supports PS5 firmware 9.00-12.00 and documents a PC-hosted initial setup followed by offline homescreen loading."
  },
  "github-ps5-autoloader-discussion": {
    "source_id": "github-ps5-autoloader-discussion",
    "title": "PS5 WebKit Autoloader v0.4.0 pre-release discussion",
    "url": "https://github.com/itsPLK/ps5-webkit-autoloader/discussions/12",
    "type": "upstream_github_discussion",
    "checked": "2026-08-25",
    "evidence": "Project maintainer states the v0.4.0 pre-release adds firmware 7.00-8.60 support and notes additional 12.00-12.70 work is under consideration."
  },
  "github-ps5-autoloader-feedback": {
    "source_id": "github-ps5-autoloader-feedback",
    "title": "PS5 WebKit Autoloader feedback discussions",
    "url": "https://github.com/itsPLK/ps5-webkit-autoloader/discussions/5",
    "type": "community_feedback_on_upstream",
    "checked": "2026-08-25",
    "evidence": "Public testing reports successful and failed runs on several PS5 firmwares; these are community reports and are not treated as quantitative reliability statistics."
  },
  "github-psfree-enhanced": {
    "source_id": "github-psfree-enhanced",
    "title": "ArabPixel/PSFree-Enhanced",
    "url": "https://github.com/ArabPixel/PSFree-Enhanced",
    "type": "community_github_repository",
    "checked": "2026-08-25",
    "evidence": "Repository describes multiple exploit chains and GoldHEN PayLoader support; treated as community evidence, not upstream authority."
  },
  "github-psfree-alazif": {
    "source_id": "github-psfree-alazif",
    "title": "Al-Azif/psfree-lapse",
    "url": "https://github.com/Al-Azif/psfree-lapse",
    "type": "upstream_github",
    "checked": "2026-08-25",
    "evidence": "Repository documents PSFree/Lapse vulnerability scope and current tested repository support for PS4 7.00-9.60."
  },
  "github-ps5-y2jb-autoloader": {
    "source_id": "github-ps5-y2jb-autoloader",
    "title": "itsPLK/ps5-y2jb-autoloader",
    "url": "https://github.com/itsPLK/ps5-y2jb-autoloader",
    "type": "upstream_github",
    "checked": "2026-08-25",
    "evidence": "Upstream README currently states support for PS5 firmware 4.03-12.70 and describes automatic kernel-exploit/payload loading."
  },
  "github-ps5-bdjb-autoloader": {
    "source_id": "github-ps5-bdjb-autoloader",
    "title": "itsPLK/ps5-bdjb-autoloader",
    "url": "https://github.com/itsPLK/ps5-bdjb-autoloader",
    "type": "upstream_github",
    "checked": "2026-08-25",
    "evidence": "Repository README states support for PS5 4.03-12.00, with an important caveat that firmware above 7.61 requires an already-jailbroken console and bdj_unpatch."
  },
  "github-ps5-webkit-autoloader-v04": {
    "source_id": "github-ps5-webkit-autoloader-v04",
    "title": "itsPLK/ps5-webkit-autoloader v0.4.0 pre-release",
    "url": "https://github.com/itsPLK/ps5-webkit-autoloader/discussions/12",
    "type": "upstream_release_discussion",
    "checked": "2026-08-25",
    "evidence": "Maintainer announcement says v0.4.0 pre-release adds PS5 firmware 7.00-8.60 support."
  },
  "github-ps5-webkit-feedback": {
    "source_id": "github-ps5-webkit-feedback",
    "title": "itsPLK/ps5-webkit-autoloader release feedback",
    "url": "https://github.com/itsPLK/ps5-webkit-autoloader/discussions/5",
    "type": "community_feedback",
    "checked": "2026-08-25",
    "evidence": "Public reports show firmware-specific success/failure variation; treated only as qualitative reliability evidence."
  },
  "github-ps5-y2jb-releases": {
    "title": "itsPLK/ps5-y2jb-autoloader releases",
    "url": "https://github.com/itsPLK/ps5-y2jb-autoloader/releases",
    "type": "upstream_github_release",
    "checked": "2026-08-25",
    "evidence": "v0.8 release notes state P2JB support for firmware above 10.01 up to 12.70, while lower firmwares continue using Lapse; v0.9 is the latest listed release.",
    "source_id": "github-ps5-y2jb-releases"
  },
  "github-ps5-y2jb-changelog": {
    "title": "itsPLK/ps5-y2jb-autoloader CHANGELOG",
    "url": "https://github.com/itsPLK/ps5-y2jb-autoloader/blob/main/CHANGELOG.md",
    "type": "upstream_github_source",
    "checked": "2026-08-25",
    "evidence": "Changelog records P2JB above 10.01 through 12.70, Lapse below that boundary, and a prior kernel-panic fix in v0.6.3.",
    "source_id": "github-ps5-y2jb-changelog"
  },
  "github-ps5-y2jb-testing": {
    "title": "P2JB Testing discussion",
    "url": "https://github.com/itsPLK/ps5-y2jb-autoloader/discussions/7",
    "type": "community_feedback",
    "checked": "2026-08-25",
    "evidence": "Public testing reports both successful and failed 12.70 attempts. This is qualitative reliability evidence only.",
    "source_id": "github-ps5-y2jb-testing"
  },
  "github-ps5-y2jb-v09-discussion": {
    "title": "Y2JB Autoloader v0.9 discussion",
    "url": "https://github.com/itsPLK/ps5-y2jb-autoloader/discussions/9",
    "type": "community_feedback",
    "checked": "2026-08-25",
    "evidence": "Discussion records network-related behavior and a custom elfldr security design. Treat as implementation/reliability evidence, not a firmware compatibility proof.",
    "source_id": "github-ps5-y2jb-v09-discussion"
  },
  "github-ps5-y2jb-autoloader-current": {
    "source_id": "github-ps5-y2jb-autoloader-current",
    "title": "itsPLK/ps5-y2jb-autoloader",
    "url": "https://github.com/itsPLK/ps5-y2jb-autoloader",
    "type": "upstream_github",
    "checked": "2026-08-26",
    "evidence": "Current README documents automated payload loading, firmware-specific YouTube setup, custom/local ELF-loader behavior, and GPL-3.0 plus original MIT licensing."
  },
  "github-psfree-lapse-current": {
    "source_id": "github-psfree-lapse-current",
    "title": "Al-Azif/psfree-lapse",
    "url": "https://github.com/Al-Azif/psfree-lapse",
    "type": "upstream_github",
    "checked": "2026-08-26",
    "evidence": "Current README separates PSFree WebKit scope from Lapse kernel scope and explicitly distinguishes vulnerability scope from firmware versions currently supported by the repository."
  },
  "github-goldhen-henloader-lp": {
    "source_id": "github-goldhen-henloader-lp",
    "title": "GoldHEN/henloader_lp",
    "url": "https://github.com/GoldHEN/henloader_lp",
    "type": "upstream_github",
    "checked": "2026-08-26",
    "evidence": "GoldHEN organization currently describes henloader_lp as Lapse (9.00-12.02) plus Poops (9.00-13.00) exploit-related work. Treat as a separate research component, not automatic proof of a complete route."
  },
  "github-ps4-autoll": {
    "source_id": "github-ps4-autoll",
    "title": "0x1iii1ii/ps4_autoLL",
    "url": "https://github.com/0x1iii1ii/ps4_autoLL",
    "type": "community_github_fork",
    "checked": "2026-08-26",
    "evidence": "Community repository claims automatic HEN loading with Lua + Lapse through PS4 firmware 12.02. Classified as community evidence pending upstream/primary verification."
  },
  "github-ps5-y2jb-testing-current": {
    "source_id": "github-ps5-y2jb-testing-current",
    "title": "itsPLK Y2JB/P2JB testing discussions",
    "url": "https://github.com/itsPLK/ps5-y2jb-autoloader/discussions",
    "type": "community_feedback",
    "checked": "2026-08-26",
    "evidence": "Public discussions contain both successful and failed firmware-specific reports, including shutdown/kernel-panic/stability reports. Used only for qualitative reliability."
  },
  "github-goldhen-henloader-lp-current": {
    "source_id": "github-goldhen-henloader-lp-current",
    "title": "GoldHEN/henloader_lp current",
    "url": "https://github.com/GoldHEN/henloader_lp",
    "type": "upstream_github",
    "checked": "2026-08-26",
    "evidence": "Current upstream repository describes Lapse 9.00-12.02 and Poops 9.00-13.00; source code explicitly disables Lapse for 12.50/12.52/13.00 and routes those firmwares to Poops."
  },
  "github-goldhen-henloader-lp-release-1": {
    "source_id": "github-goldhen-henloader-lp-release-1",
    "title": "HenLoader LP 1.0 release",
    "url": "https://github.com/GoldHEN/henloader_lp/releases/tag/1.0",
    "type": "upstream_release",
    "checked": "2026-08-26",
    "evidence": "Latest release page describes Lapse 9.00-12.02 + Poops 9.00-12.52 and includes GoldHEN 2.4b18.7."
  },
  "github-bdj-1252": {
    "source_id": "github-bdj-1252",
    "title": "DefKorns/BD-JB-1252",
    "url": "https://github.com/DefKorns/BD-JB-1252",
    "type": "community_github",
    "checked": "2026-08-26",
    "evidence": "Repository explicitly targets PS4 12.50-12.52 and describes Poops ISO with USB payload loading. Used as corroborating implementation evidence, not sole authority."
  }
};

function routePresentation(entry) {
  if (!entry) {
    return {
      badge: "UNKNOWN",
      title: "No verified route",
      message: "Robinhood has no evidence-backed route for this firmware.",
      action: "NONE"
    };
  }

  const map = {
    VERIFIED: {
      badge: "VERIFIED",
      title: "Compatible route recorded",
      message: "A verified database route exists. Robinhood can prepare this route.",
      action: "PREPARE"
    },
    PARTIAL: {
      badge: "PARTIAL",
      title: "Partial compatibility",
      message: "Some layers are verified, but the complete route is not.",
      action: "RESEARCH"
    },
    REPORTED: {
      badge: "REPORTED",
      title: "Community / repository report",
      message: "Evidence exists, but Robinhood has not promoted this route to verified.",
      action: "RESEARCH"
    },
    EXPERIMENTAL: {
      badge: "EXPERIMENTAL",
      title: "Experimental route",
      message: "This route is not considered production-ready.",
      action: "RESEARCH"
    },
    RESEARCH_TARGET: {
      badge: "RESEARCH TARGET",
      title: "Project target",
      message: "This firmware is a Robinhood research target, not a support claim.",
      action: "RESEARCH"
    },
    RESEARCH_ENTRY: {
      badge: "RESEARCH",
      title: "Research entry",
      message: "This is a schema/research entry only.",
      action: "RESEARCH"
    }
  };

  return map[entry.status] || {
    badge: "UNKNOWN",
    title: "Unknown state",
    message: "The database does not provide a verified route.",
    action: "NONE"
  };
}

if (typeof module !== "undefined") module.exports = { routePresentation };

# Security

Do not add unverified payloads or arbitrary remote execution. Preserve provenance and checksums for future bundled assets.

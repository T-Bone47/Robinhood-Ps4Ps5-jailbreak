# Robinhood Routing Model

Robinhood distinguishes an entry mechanism from the complete homebrew route.

```text
Console/Firmware
      |
      v
Entry capability
      |
      +--> WebKit route
      +--> BD-J route
      +--> other documented entry
      |
      v
Kernel layer
      |
      v
HEN / payload layer
```

A physical BD-J/Poops route can be useful for a firmware target such as PS4 12.52, but it is not represented as a GitHub.io WebKit route. The product can expose it later as an alternative route with a different prerequisite set.

For PS5, the current upstream Y2JB repository claims 4.03-12.70, while its changelog specifically identifies P2JB above 10.01 through 12.70. These remain evidence-backed records but not blanket VERIFIED fresh-jailbreak guarantees.

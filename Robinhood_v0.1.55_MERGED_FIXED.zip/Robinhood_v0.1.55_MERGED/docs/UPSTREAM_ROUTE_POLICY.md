# Upstream Route Policy

The route registry is deliberately separate from the execution adapter registry.

A route may be:
- DOCUMENTED: supported by an upstream source;
- RESEARCH_ONLY: known/documented but not approved for local execution;
- VERIFIED: exact release, provenance, integrity, license and hardware validation are present.

Only a VERIFIED route may become a VERIFIED execution adapter.

A broad firmware range is never interpreted as proof that every firmware in the
range has a reliable complete exploit chain.

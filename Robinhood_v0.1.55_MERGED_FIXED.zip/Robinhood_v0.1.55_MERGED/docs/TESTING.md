# Testing

Tests validate database/routing integrity only. They do not execute exploits.

# Firmware Summary

Each firmware profile now exposes a compact summary before the utility grid:

- total tools
- number of locked tools
- execution state

The summary is informational and does not change route promotion or execution
permissions.

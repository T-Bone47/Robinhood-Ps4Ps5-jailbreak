# Firmware Auto-Detection

The browser-facing layer can parse the PlayStation user-agent and normalize the
reported firmware string.

Detection is not proof of exploit compatibility.

The routing sequence is:

`User-Agent → console/firmware → route table → adapter promotion gate`

A route may be displayed as `REPORTED` or `RESEARCH_ONLY` without becoming
executable. Only a separately verified adapter can cross the execution gate.

# Payload Delivery Contract

Robinhood treats GoldHEN as a route-specific upstream payload dependency.

The host may:
- identify the required payload;
- verify its provenance and integrity metadata;
- prepare the local delivery request;
- display delivery state.

The host may only display `LOADED` after the route adapter reports a successful
payload-load result containing both a route ID and payload ID.

This prevents a UI animation or HTTP request from being mistaken for successful
kernel/HEN execution.

Third-party exploit/payload binaries are not silently copied into Robinhood by
this contract layer.

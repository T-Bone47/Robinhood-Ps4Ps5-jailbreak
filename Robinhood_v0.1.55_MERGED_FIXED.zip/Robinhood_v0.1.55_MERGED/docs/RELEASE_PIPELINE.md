# Robinhood Release Pipeline

## One-command release

Run:

```text
python tools/release.py
python tools/verify_release.py
```

The release builder creates one deterministic static distribution containing:

- `index.html`
- frontend assets
- compatibility database
- source/provenance records
- deployment metadata
- release metadata
- `RELEASE-MANIFEST.json`

Every file receives a SHA-256 hash.

## Release rule

The research-preview release does not contain an execution-capable exploit/payload route.

The release pipeline verifies the integrity and completeness of the research host only.

## Deployment targets

The same `dist_release` directory can be published to:
- GitHub Pages
- another static host
- a local HTTP server

This keeps public and LAN versions on the same artifact.

# Contributing

Read ARCHITECTURE.md, COMPATIBILITY.md and LICENSING.md before changing compatibility data or integrations.

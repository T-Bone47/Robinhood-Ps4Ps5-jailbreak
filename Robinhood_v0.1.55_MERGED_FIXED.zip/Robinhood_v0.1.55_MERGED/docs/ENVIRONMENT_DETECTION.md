# Environment Detection

Robinhood uses a layered detection strategy.

## Layer 1 — Explicit user input

The user can select:
- PS4
- PS5
- firmware

This is the authoritative fallback.

## Layer 2 — Browser/runtime hints

The application may collect non-invasive browser/runtime information when available, but these hints are never treated as proof of firmware compatibility.

## Layer 3 — Verified console-side detection

If a future component can safely establish console model/firmware through a documented interface, that evidence can be added to the database as a distinct evidence source.

## Rule

A browser user-agent or JavaScript environment must never be interpreted as a precise PS4/PS5 firmware version without primary evidence.

## Ambiguity

If multiple routes cover a firmware, Robinhood shows all matching research records and refuses to silently select one.

# Release Preflight

The release preflight is a required gate.

A bounded wrapper caps a hung invocation at 30 seconds and returns exit code
124 on timeout. A timeout is a failure/unknown state, not a pass.

This keeps development from silently waiting forever while preserving the
rule that a release cannot be called verified unless preflight completes.

# Source Authority Model

Robinhood distinguishes exploit evidence from host evidence.

## Exploit primary

The actual exploit repository/source code is authoritative for whether that
project claims a firmware route.

## Host primary

A host framework is authoritative for how that host packages, caches, serves,
or routes files. It is not automatically authoritative for exploit compatibility.

## Secondary host

Forks and community hosts are valuable for UX, discovery and corroboration,
but do not override upstream exploit-source claims.

## Release rule

Every compatibility route must point to known source IDs. A route cannot be
promoted to VERIFIED unless its evidence grade is PRIMARY_VERIFIED.

This prevents a visually polished host from accidentally turning a community
claim into a verified compatibility statement.

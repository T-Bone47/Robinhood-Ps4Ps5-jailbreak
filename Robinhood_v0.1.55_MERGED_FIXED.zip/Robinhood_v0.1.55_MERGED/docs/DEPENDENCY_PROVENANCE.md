# Dependency & Provenance Model

Robinhood does not treat a repository as a single opaque dependency.

Each route can pin:
- upstream repository
- exact release/tag
- commit identifier
- external binary dependency
- source record
- license state

## Example: PS5 Y2JB v0.9

The upstream v0.9 release currently identifies:
- ps5-elfldr v0.23.2-148b71c
- ps5-kexp v0.6-c3d0fd9
- ps5-unified-autoloader v0.1.2-8e96846

The upstream build script can either build these from submodules or download prebuilt release assets. Robinhood records that distinction and will not silently substitute arbitrary binaries.

A route is not execution-eligible merely because the exploit repository is public. Licensing and exact dependency provenance must also be resolved.

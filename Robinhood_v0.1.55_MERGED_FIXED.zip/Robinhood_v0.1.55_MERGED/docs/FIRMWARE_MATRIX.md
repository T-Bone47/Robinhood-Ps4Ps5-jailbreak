# Robinhood Firmware Matrix

Checked: 2026-08-25

This matrix distinguishes component evidence from a complete jailbreak route.

## PS4

| Firmware | WebKit | Kernel | HEN | Complete route | Status |
|---|---|---|---|---|---|
| 5.05 | historical / source verification required | historical / source verification required | GoldHEN documented | RESEARCH_REQUIRED | UNKNOWN |
| 6.72 | historical / source verification required | historical / source verification required | GoldHEN documented | RESEARCH_REQUIRED | UNKNOWN |
| 7.00 | PSFree/Lapse family documented | PPPwn documented | GoldHEN not yet mapped in Robinhood | PARTIAL | PARTIAL |
| 7.55 | PSFree/Lapse family documented | PPPwn documented | GoldHEN not yet mapped in Robinhood | PARTIAL | PARTIAL |
| 8.03 | PSFree/Lapse family documented | PPPwn documented | GoldHEN not yet mapped in Robinhood | PARTIAL | PARTIAL |
| 8.52 | PSFree/Lapse family documented | PPPwn documented | GoldHEN not yet mapped in Robinhood | PARTIAL | PARTIAL |
| 9.00 | PSFree/Lapse documented | PPPwn documented | GoldHEN documented | PARTIAL | PARTIAL |
| 9.60 | PSFree/Lapse documented | PPPwn documented | GoldHEN documented | PARTIAL | PARTIAL |
| 10.00 | source-backed PPPwn ecosystem | PPPwn documented | GoldHEN documented | PARTIAL | PARTIAL |
| 10.01 | source-backed PPPwn ecosystem | PPPwn documented | GoldHEN documented | PARTIAL | PARTIAL |
| 10.50 | source-backed PPPwn ecosystem | PPPwn documented | GoldHEN documented | PARTIAL | PARTIAL |
| 10.70 | source-backed PPPwn ecosystem | PPPwn documented | GoldHEN documented | PARTIAL | PARTIAL |
| 10.71 | source-backed PPPwn ecosystem | PPPwn documented | GoldHEN documented | PARTIAL | PARTIAL |
| 11.00 | source-backed PPPwn ecosystem | PPPwn documented | GoldHEN documented | PARTIAL | PARTIAL |
| 11.02 | research required | Lapse vulnerability scope reported; route varies | GoldHEN mapping required | RESEARCH_REQUIRED | UNKNOWN |
| 12.02 | research required | Lapse vulnerability scope reported; route varies | GoldHEN mapping required | RESEARCH_REQUIRED | UNKNOWN |
| 12.50 | research required | research required | research required | RESEARCH_REQUIRED | UNKNOWN |
| 12.52 | research required | research required | research required | RESEARCH_REQUIRED | UNKNOWN |

## PS5

| Firmware | WebKit | Kernel | HEN | Complete route | Status |
|---|---|---|---|---|---|
| 1.00-5.50 | PSFree vulnerability scope documented | research required | research required | RESEARCH_REQUIRED | UNKNOWN |
| 6.00-8.60 | research / pre-release autoloader evidence | research required | research required | EXPERIMENTAL | EXPERIMENTAL |
| 9.00-12.00 | PS5 WebKit Autoloader documented | autoloader project integration | payload-dependent | DOCUMENTED_AUTLOADER | VERIFIED |
| 12.01-12.52 | research required | research required | research required | RESEARCH_REQUIRED | UNKNOWN |

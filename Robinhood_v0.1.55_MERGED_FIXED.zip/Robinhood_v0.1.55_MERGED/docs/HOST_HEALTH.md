# Host Health

The landing page now reports readiness of the local application itself before
firmware selection.

The health model covers:
- offline asset availability
- firmware route metadata
- runtime adapter gate
- hardware validation gate

A healthy host means the application is ready to select a route. It does not
mean a console is exploitable or that GoldHEN is loaded.

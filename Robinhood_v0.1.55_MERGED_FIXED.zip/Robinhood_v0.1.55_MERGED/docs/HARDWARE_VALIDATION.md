# Hardware Validation

Automated software tests establish that Robinhood's routing, state machine,
provenance and UI behave correctly. They do not establish that an exploit
successfully executed on a physical console.

A promotion record therefore requires:

- console model
- exact firmware
- route ID
- adapter version
- test date
- controlled environment
- ordered test steps
- observed results
- PASS/FAIL/INCONCLUSIVE result
- operator record

Only a `PASS` hardware-validation record may satisfy the hardware-validation
condition of the promotion gate.

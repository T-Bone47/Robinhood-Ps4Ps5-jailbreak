# Provenance Lock

A route remains `RESEARCH_ONLY` until Robinhood records:

1. exact upstream repository;
2. exact release or commit;
3. exact files required by the route;
4. SHA-256 integrity values;
5. license review;
6. firmware-specific evidence;
7. hardware-validation record;
8. final `VERIFIED` status.

This prevents a moving GitHub branch, an arbitrary mirror, or a broad README
claim from silently becoming an executable route.

The lock records references and metadata. It does not copy or redistribute
third-party exploit code.

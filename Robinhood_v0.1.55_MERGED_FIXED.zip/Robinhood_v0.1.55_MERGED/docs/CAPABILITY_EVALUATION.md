# Capability Evaluation

Robinhood now separates four questions:

1. Is there a documented route?
2. What evidence supports it?
3. Are its prerequisites available?
4. Is it eligible for validation?

A route marked REPORTED is never turned into a selectable execution route simply
because the user has the right firmware.

A route must be PRIMARY_VERIFIED before it can become eligible for the validation
stage, and all mandatory prerequisites must be satisfied.

This prevents the interface from presenting a firmware match as a guarantee.

# Robinhood Hosting Architecture

## Single artifact, multiple deployment modes

```text
                  Robinhood static artifact
                           |
              +------------+------------+
              |                         |
        GitHub Pages                 LAN host
              |                         |
          HTTPS/CDN                 local HTTP
              |                         |
              +------------+------------+
                           |
                    Robinhood frontend
                           |
                    local compatibility DB
```

GitHub Pages is appropriate for the public static research/UI build. GitHub documents that Pages can publish from a branch/folder or through GitHub Actions.

The LAN build is the same static artifact served by a local HTTP server.

## Offline behavior

Robinhood uses a service worker to cache its application shell and compatibility data.

Service workers and CacheStorage are secure-context APIs. HTTPS is the normal requirement; localhost is treated as a trustworthy origin by browsers for local development. A plain LAN IP over HTTP should therefore not be assumed to provide service-worker functionality.

This means Robinhood has two offline concepts:

1. **Application shell offline** — service-worker/cache based where the browser permits it.
2. **Local static hosting** — the complete files are already served from the user's LAN machine and do not require an Internet connection.

The application must remain usable without service-worker support.

## Security

- No third-party runtime JavaScript.
- No remote API dependency for compatibility decisions.
- No automatic fetching of arbitrary payloads.
- Compatibility database is bundled and provenance-linked.
- External research links are informational rather than runtime dependencies.
- The LAN server is intended for the local network and should not be exposed to the public Internet without deliberate configuration.

## GitHub Pages

The public static site can be published from the generated artifact. GitHub Pages supports branch/folder publishing and GitHub Actions workflows.

Do not place secrets, private research material, or sensitive local configuration into the public Pages artifact.

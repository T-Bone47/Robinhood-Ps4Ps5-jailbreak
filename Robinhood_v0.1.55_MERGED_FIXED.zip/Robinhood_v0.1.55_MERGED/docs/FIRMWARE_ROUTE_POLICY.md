# Firmware Route Policy

Robinhood keeps four separate concepts:

1. WebKit/userland entry support
2. kernel escalation support
3. HEN/payload support
4. complete-chain support

A firmware is never marked fully supported merely because one of these layers
works.

The current upstream PSFree repository explicitly lists PS4 7.00–9.60 as its
functional/tested complete chain, while its vulnerability-scope table is
broader. Robinhood follows the functional/tested table for that route.

CSSFontFace-Exploit documents PS4 6.00–11.02 for the WebKit exploit and a
kernel-exploit range of 7.00–11.02, with explicit limitations above 11.02.

HenLoader/Poops claims around 12.52 are retained as reported evidence and
remain hardware-validation gated.

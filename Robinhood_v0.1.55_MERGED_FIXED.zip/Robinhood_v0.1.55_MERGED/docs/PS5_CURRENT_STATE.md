# PS5 Current State

Checked: 2026-08-26.

## Current Y2JB evidence

The upstream itsPLK Y2JB Autoloader currently states support for PS5 4.03-12.70.

Its v0.8 release notes specifically introduce P2JB above 10.01 through 12.70.
The operational firmware split used by the current Y2JB ecosystem is:

- 4.03-10.01: Lapse/Y2JB path
- 10.20-12.70: P2JB path

Robinhood records the P2JB range as **REPORTED**, not VERIFIED.

## Reliability

Public testing shows mixed outcomes at 12.70, including successful runs and
kernel-panic/shutdown/recovery-mode failures. There is no reliable public
quantitative success-rate dataset, so Robinhood stores qualitative observations only.

## Important design consequence

The compatibility database must contain both:

- `compatibility`
- `reliability_observations`

A firmware can therefore be technically routed while still being labelled
unstable/experimental.

## Authority

The itsPLK upstream repository is authoritative for its own release metadata.
Forks are discovery/testing sources and cannot override upstream compatibility
claims without independent evidence.

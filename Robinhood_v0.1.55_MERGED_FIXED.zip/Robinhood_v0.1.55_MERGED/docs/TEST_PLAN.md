# Robinhood Test Plan

## Automated

1. Unit tests — firmware parsing, routing, lifecycle, evidence, capability.
2. Database tests — provenance, source authority, freshness and integrity.
3. Static-host tests — required files are present and HTTP-served.
4. E2E research-host smoke test — frontend and database artifacts load together.
5. Release preflight — no duplicate/malformed/unproven routes.
6. Release manifest — final artifact hashes are verified.

## Manual hardware validation

Automated tests cannot prove that an exploit works on physical hardware.
Hardware validation must therefore be recorded separately with:

- console model
- exact firmware
- date
- route/release tested
- result
- crash/panic state
- payload result
- tester/source
- reproduction notes

A YouTube demonstration is a UX/reference signal, not a substitute for
primary repository evidence or device validation.

The provided Modded Warfare video is therefore retained as a reference source,
while the technical test oracle remains the GitHub/source evidence.

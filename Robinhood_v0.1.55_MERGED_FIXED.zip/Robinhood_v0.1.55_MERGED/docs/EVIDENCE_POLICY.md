# Robinhood Evidence Policy

Compatibility, evidence grade, and reliability are separate fields.

## Evidence grades

- PRIMARY_VERIFIED — directly supported by authoritative source/release/source code and validated by project evidence.
- PRIMARY_REPORTED — primary project documents the route, but independent reliability validation is incomplete.
- SECONDARY_CORROBORATED — secondary source corroborates primary evidence.
- COMMUNITY_REPORTED — community-only report.
- INFERENCE — derived by analysis, never sufficient to mark a route verified.
- UNKNOWN — insufficient evidence.

## Execution policy

The current research-preview build does not expose execution routes.

Future execution integration must require an explicit verification gate and must
never promote a community report or inference into a verified route automatically.

Reliability remains independent. A route can be technically documented while
still being operationally unstable.

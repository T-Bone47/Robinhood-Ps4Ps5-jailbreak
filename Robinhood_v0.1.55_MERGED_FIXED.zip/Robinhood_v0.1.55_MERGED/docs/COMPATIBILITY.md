# Compatibility Matrix

> Auto-generated from `database/ps4.json`, `database/ps5.json`, `database/exploit-chains.json`, and `database/hen.json`

**Generated:** 2026-08-26T08:13:02.265Z
**Database Version:** 1.0

## PS4 Firmware Compatibility

| Firmware | Family | Status | Reliability | WebKit | Kernel | HEN | Loader | Payloads | Offline | Local Host | Recommended Chain |
|----------|--------|--------|-------------|--------|--------|-----|--------|----------|---------|------------|-------------------|
| 9.00 | 9.00 | ✅ VERIFIED | 🟢 EXCELLENT | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ | ✅ | PSFree for PS4 9.00 |
| 9.60 | 9.60 | ✅ VERIFIED | 🟢 EXCELLENT | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ | ✅ | PSFree for PS4 9.60 |
| 10.00 | 10.xx | ✅ VERIFIED | 🟢 GOOD | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ | ✅ | PSFree for PS4 10.xx |
| 10.01 | 10.xx | ✅ VERIFIED | 🟢 GOOD | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ | ✅ | PSFree for PS4 10.xx |
| 10.50 | 10.xx | ✅ VERIFIED | 🟢 GOOD | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ | ✅ | PSFree for PS4 10.xx |
| 10.70 | 10.xx | ✅ VERIFIED | 🟢 GOOD | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ | ✅ | PSFree for PS4 10.xx |
| 10.71 | 10.xx | ✅ VERIFIED | 🟢 GOOD | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ | ✅ | PSFree for PS4 10.xx |
| 11.00 | 11.xx | ✅ VERIFIED | 🟡 MODERATE | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ | ✅ | PSFree for PS4 11.xx |
| 11.02 | 11.xx | ✅ VERIFIED | 🟡 MODERATE | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ | ✅ | PSFree for PS4 11.xx |
| 11.50 | 11.xx | ✅ VERIFIED | 🟡 MODERATE | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ | ✅ | PSFree for PS4 11.xx |
| 11.52 | 11.xx | ✅ VERIFIED | 🟡 MODERATE | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ | ✅ | PSFree for PS4 11.xx |
| 12.00 | 12.xx | ⚠️ PARTIAL | 🔴 EXPERIMENTAL | ✅ VERIFIED | ⚠️ PARTIAL | ❓ UNKNOWN | ❓ UNKNOWN | ❓ UNKNOWN | ❌ | ❌ | PSFree for PS4 12.xx |
| 12.02 | 12.xx | ⚠️ PARTIAL | 🔴 EXPERIMENTAL | ✅ VERIFIED | ⚠️ PARTIAL | ❓ UNKNOWN | ❓ UNKNOWN | ❓ UNKNOWN | ❌ | ❌ | PSFree for PS4 12.xx |
| 12.50 | 12.xx | 🧪 EXPERIMENTAL | 🔴 EXPERIMENTAL | ✅ VERIFIED | 🧪 EXPERIMENTAL | ❓ UNKNOWN | ❓ UNKNOWN | ❓ UNKNOWN | ❌ | ❌ | PSFree for PS4 12.xx |
| 12.52 | 12.xx | 🧪 EXPERIMENTAL | 🔴 EXPERIMENTAL | ✅ VERIFIED | 🧪 EXPERIMENTAL | ❓ UNKNOWN | ❓ UNKNOWN | ❓ UNKNOWN | ❌ | ❌ | PSFree for PS4 12.xx |

## PS5 Firmware Compatibility

| Firmware | Family | Status | Reliability | WebKit | Kernel | HEN | Loader | Payloads | Offline | Local Host | Recommended Chain |
|----------|--------|--------|-------------|--------|--------|-----|--------|----------|---------|------------|-------------------|
| 4.03 | 4.xx | ✅ VERIFIED | 🟢 EXCELLENT | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ | ✅ | UMTX for PS5 4.xx |
| 4.50 | 4.xx | ✅ VERIFIED | 🟢 EXCELLENT | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ | ✅ | UMTX for PS5 4.xx |
| 4.51 | 4.xx | ✅ VERIFIED | 🟢 EXCELLENT | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ | ✅ | UMTX for PS5 4.xx |
| 5.00 | 5.xx | ✅ VERIFIED | 🟢 GOOD | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ VERIFIED | ✅ | ✅ | Y2JB for PS5 5.xx |
| 6.00 | 6.xx | ⚠️ PARTIAL | 🔴 EXPERIMENTAL | ✅ VERIFIED | ⚠️ PARTIAL | ❓ UNKNOWN | ❓ UNKNOWN | ❓ UNKNOWN | ❌ | ❌ | PSFree for PS5 6.xx |
| 7.00 | 7.xx | ⚠️ PARTIAL | 🔴 EXPERIMENTAL | ✅ VERIFIED | ⚠️ PARTIAL | ❓ UNKNOWN | ❓ UNKNOWN | ❓ UNKNOWN | ❌ | ❌ | PSFree for PS5 7.xx |
| 8.00 | 8.xx | 🧪 EXPERIMENTAL | 🔴 EXPERIMENTAL | 🧪 EXPERIMENTAL | ❓ UNKNOWN | ❓ UNKNOWN | ❓ UNKNOWN | ❓ UNKNOWN | ❌ | ❌ | Lapse for PS5 8.xx |

## Exploit Chain Matrix

| Chain ID | Name | Console | Entry | Status | Reliability | Payload Formats | Supported Firmwares |
|----------|------|---------|-------|--------|-------------|-----------------|---------------------|
| psfree-ps4-900 | PSFree for PS4 9.00 | PS4 | WEBKIT | ✅ VERIFIED | 🟢 EXCELLENT | BIN, ELF, EMBEDDED | 9.00 |
| psfree-ps4-960 | PSFree for PS4 9.60 | PS4 | WEBKIT | ✅ VERIFIED | 🟢 EXCELLENT | BIN, ELF, EMBEDDED | 9.60 |
| psfree-ps4-10xx | PSFree for PS4 10.xx | PS4 | WEBKIT | ✅ VERIFIED | 🟢 GOOD | BIN, ELF, EMBEDDED | 10.00, 10.01, 10.50, 10.70, 10.71 |
| psfree-ps4-11xx | PSFree for PS4 11.xx | PS4 | WEBKIT | ✅ VERIFIED | 🟡 MODERATE | BIN, ELF, EMBEDDED | 11.00, 11.02, 11.50, 11.52 |
| psfree-ps4-12xx | PSFree for PS4 12.xx | PS4 | WEBKIT | 🧪 EXPERIMENTAL | 🔴 EXPERIMENTAL | BIN, ELF, EMBEDDED | 12.00, 12.02, 12.50, 12.52 |
| lapse-ps4-900 | Lapse for PS4 9.00 | PS4 | WEBKIT | ✅ VERIFIED | 🟢 GOOD | BIN, ELF, EMBEDDED | 9.00 |
| lapse-ps4-960 | Lapse for PS4 9.60 | PS4 | WEBKIT | ✅ VERIFIED | 🟢 GOOD | BIN, ELF, EMBEDDED | 9.60 |
| cssfontface-ps4-10xx | CSSFontFace for PS4 10.xx | PS4 | WEBKIT | ✅ VERIFIED | 🟡 MODERATE | BIN, ELF, EMBEDDED | 10.00, 10.01, 10.50, 10.70, 10.71 |
| umtx-ps5-4xx | UMTX for PS5 4.xx | PS5 | KERNEL | ✅ VERIFIED | 🟢 EXCELLENT | ELF, EMBEDDED | 4.03, 4.50, 4.51 |
| y2jb-ps5-5xx | Y2JB for PS5 5.xx | PS5 | WEBKIT | ✅ VERIFIED | 🟢 GOOD | ELF, EMBEDDED | 5.00 |
| p2jb-ps5-5xx | P2JB for PS5 5.xx | PS5 | WEBKIT | ✅ VERIFIED | 🟢 GOOD | ELF, EMBEDDED | 5.00 |
| psfree-ps5-6xx | PSFree for PS5 6.xx | PS5 | WEBKIT | ⚠️ PARTIAL | 🔴 EXPERIMENTAL |  | 6.00 |
| psfree-ps5-7xx | PSFree for PS5 7.xx | PS5 | WEBKIT | ⚠️ PARTIAL | 🔴 EXPERIMENTAL |  | 7.00 |
| lapse-ps5-8xx | Lapse for PS5 8.xx | PS5 | WEBKIT | 🧪 EXPERIMENTAL | 🔴 EXPERIMENTAL |  | 8.00 |

## HEN (Homebrew Enabler) Matrix

| HEN ID | Name | Console | Version | Status | Payload Formats | Firmware Range |
|--------|------|---------|---------|--------|-----------------|----------------|
| goldhen-2.4 | GoldHEN 2.4 | PS4 | 2.4 | ✅ VERIFIED | BIN, ELF, EMBEDDED | 9.00, 9.60, 10.00, 10.01, 10.50, 10.70, 10.71, 11.00, 11.02, 11.50, 11.52 |
| goldhen-2.4b | GoldHEN 2.4b (12.xx support) | PS4 | 2.4b | 🧪 EXPERIMENTAL | BIN, ELF, EMBEDDED | 12.00, 12.02, 12.50, 12.52 |
| ps5-hen-4xx | PS5 HEN for 4.xx | PS5 | 1.0 | ✅ VERIFIED | ELF, EMBEDDED | 4.03, 4.50, 4.51 |
| ps5-hen-5xx | PS5 HEN for 5.xx | PS5 | 1.1 | ✅ VERIFIED | ELF, EMBEDDED | 5.00 |

---
*Generated by `scripts/generate-docs.js`*
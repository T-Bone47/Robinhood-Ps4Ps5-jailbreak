# Robinhood Adapter Contract

Robinhood uses a controlled integration boundary around documented upstream implementations.

Each adapter must provide:
- unique ID
- console
- exact firmware or documented firmware family
- entry-stage reference
- kernel-stage reference
- payload/HEN reference
- provenance source IDs
- release/version information
- integrity metadata
- license metadata
- validation status

Only `VERIFIED` adapters can enter the execution lifecycle.

Lifecycle:
`PRECHECK → ENTRY → KERNEL → PAYLOAD → COMPLETE`

Failed or missing prerequisites transition to `REVIEW_REQUIRED` or `FAILED`.

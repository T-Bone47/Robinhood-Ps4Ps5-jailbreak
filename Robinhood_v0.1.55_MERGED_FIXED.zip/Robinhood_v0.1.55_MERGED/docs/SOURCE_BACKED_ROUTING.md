# Source-Backed Routing

Robinhood's frontend is now a presentation layer over the evidence database.

## State meanings

- VERIFIED: evidence supports the route represented by the record.
- PARTIAL: one or more layers exist, but the complete route is not verified.
- REPORTED: upstream/community evidence exists but has not been promoted to verified.
- EXPERIMENTAL: pre-release or unstable evidence.
- UNKNOWN: no route is established.

## Current important evidence

The upstream PSFree/Lapse repository explicitly separates vulnerability scope from the firmware versions its current repository says are functional and tested. Its current table lists PS4 PSFree/Lapse support at 7.00-9.60, while broader vulnerability scope is not equivalent to current tested support.

The current itsPLK PS5 Y2JB autoloader repository documents multiple payload-loader paths and firmware-specific behavior. Its release history distinguishes P2JB above 10.01 through 12.70 from Lapse on lower firmware.

These records are intentionally not collapsed into one universal compatibility claim.

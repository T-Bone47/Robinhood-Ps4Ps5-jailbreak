# Robinhood Development Status

## v0.1 foundation

Implemented:
- static frontend
- normalized firmware parsing
- compatibility engine foundation
- database validation
- provenance-ready schema
- local static host
- static build
- routing tests
- database tests

Not implemented:
- real exploit execution
- real payload binaries
- automatic exploit launching
- verified production firmware claims

## Current principle

The software must never infer compatibility from proximity to another firmware.
All future VERIFIED entries require source evidence and provenance.

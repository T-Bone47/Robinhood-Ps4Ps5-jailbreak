# Robinhood Architecture Baseline

Version 1.0.

Core contract:
- PS4 primary target through 12.52.
- PS5 evidence-driven, research ceiling 12.52.
- Static GitHub Pages + local LAN host.
- JSON compatibility database.
- Modular WebKit/kernel/HEN/loader/payload adapters.
- Upstream-first provenance.
- Stable builds contain only verified components.
- v0.1 does not execute real exploits.

## Offline full-chain host model

Robinhood now has an explicit orchestration layer for the host pattern documented by the supplied PS4JB reference source: firmware-specific route selection, offline asset mapping, entry stage, kernel stage, payload stage, and final completion. The reference registry is deliberately declaration-only until a route has a source-backed, device-validated production adapter. This prevents the UI from turning a historical host description into a false execution claim.

The reference registry lives at `database/reference/legacy-host-routes.json`; browser presentation is generated into `frontend/js/reference-routes.js`. `core/execution/orchestrator.js` and `frontend/js/execution-orchestrator.js` model the state machine and hard-block non-verified or declaration-only adapters.

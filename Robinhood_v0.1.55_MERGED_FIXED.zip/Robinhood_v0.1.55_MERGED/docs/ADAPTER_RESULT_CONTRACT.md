# Adapter Result Contract

The browser UI never infers jailbreak success.

The route adapter must emit structured lifecycle events:

- `ENTRY_STARTED`
- `KERNEL_STARTED`
- `PAYLOAD_STARTED`
- `COMPLETE`
- `FAILED`

`COMPLETE` requires a `routeId` and `payloadId`.

`FAILED` requires a `routeId` and `errorCode`.

This is the boundary between the UI and a real route implementation. It lets
Robinhood show useful diagnostics without converting a page request, timeout,
or animation into a false success.

# Source Freshness

Compatibility research is time-sensitive.

Robinhood records `checked` dates for sources and applies freshness classes.

Current policy:

- CRITICAL: 30 days
- HIGH: 90 days
- NORMAL: 180 days
- HISTORICAL: 3650 days

A stale source remains in the database for auditability, but it cannot silently
be treated as current evidence.

This is especially important for exploit repositories because firmware support,
release branches and reliability can change without changing the historical
fact that an older release once supported a firmware.

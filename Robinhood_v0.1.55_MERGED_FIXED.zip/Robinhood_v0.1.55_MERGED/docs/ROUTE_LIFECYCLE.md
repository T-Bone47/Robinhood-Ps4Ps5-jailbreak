# Route Lifecycle

Robinhood now tracks the lifecycle of every compatibility route.

```text
DISCOVERED
    ↓
CORROBORATED
    ↓
REPORTED
    ↓
VERIFIED
```

A route can also become:

```text
DEPRECATED
BLOCKED
```

## Verification gate

A route cannot become VERIFIED simply because a host repository claims support.

The verification gate requires:
- `PRIMARY_VERIFIED` evidence
- valid provenance
- compatibility metadata
- validation metadata
- no explicit failed device validation

This prevents old community claims from becoming permanent compatibility
truth merely because they were copied into the database.

## Review queue

Every REPORTED, UNKNOWN, or EXPERIMENTAL route appears in the review queue.
The queue identifies whether the next step is source review or validation review.

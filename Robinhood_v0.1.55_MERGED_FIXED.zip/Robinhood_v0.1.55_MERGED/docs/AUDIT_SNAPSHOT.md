# Audit Snapshot

Robinhood now freezes a SHA-256 snapshot of the reviewed JSON research
database before later modifications.

The snapshot is a checkpoint, not a claim that the research is permanently
correct. If upstream sources change, a new snapshot must be generated after
the source audit is repeated.

This provides a clear boundary between:
- reviewed research state
- subsequent development changes
- final release state

# Hosting

Use `python host/server.py` for the initial local static host. GitHub Pages is the static deployment target.

# Firmware Handling

Robinhood normalizes firmware strings for comparison while retaining the user's
original input.

Examples:

- `12.52` → numeric 12.52
- `12.5` → numeric 12.50
- `9` → numeric 9.00

Normalization does not create compatibility evidence.

A range such as `12.02-12.52` is treated as a database grouping. Robinhood must
still rely on the evidence attached to that range and must not assume every
intermediate version is independently verified.

Exact firmware records take precedence over broad family records.
Unknown or malformed input cannot automatically select a route.

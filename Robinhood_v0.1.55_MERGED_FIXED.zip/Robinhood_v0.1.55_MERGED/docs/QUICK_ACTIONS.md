# Quick Actions

Firmware profiles expose a compact quick-action strip for the most common
catalogued operations.

Current quick actions:
- Exploit + GoldHEN
- FTP
- App Dumper
- DB Backup

These are UI shortcuts. They remain locked behind the existing runtime adapter
and hardware-validation gates.

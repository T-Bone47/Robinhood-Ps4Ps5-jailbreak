# Firmware Session

The host remembers the selected firmware profile and selected utility locally
in the browser.

Persisted values:
- firmware
- profile title
- host status
- selected tool

The session does not persist privileged execution results and cannot unlock a
route. Reloading the page only restores the UI context.

# Release Candidate Audit

This checkpoint is a research/host application build, not proof of a successful
physical-console jailbreak.

Automated validation covers:
- database structure
- compatibility routing
- evidence/lifecycle rules
- source provenance
- source freshness metadata
- data integrity
- local static hosting
- UI acceptance criteria
- release preflight

Automated validation cannot establish physical-console exploit success. That
requires controlled hardware testing on each exact firmware/console combination
and must be recorded separately.

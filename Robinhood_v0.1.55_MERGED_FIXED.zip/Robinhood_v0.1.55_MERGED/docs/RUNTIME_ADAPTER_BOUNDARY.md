# Runtime Adapter Boundary

The runtime adapter is the only boundary where Robinhood may hand an execution
request to an external route implementation.

Rules:

1. The adapter must pass the provenance/promotion gate.
2. A runtime transport must be explicitly installed.
3. Adapter events must pass the result contract.
4. Events from another route are rejected.
5. Missing transport produces a hard failure, never simulated success.

This layer deliberately contains no exploit implementation. A documented
upstream implementation can be integrated behind this interface once its exact
release, integrity, license and hardware-validation requirements are satisfied.

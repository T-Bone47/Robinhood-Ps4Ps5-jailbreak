# Local Host Contract

Robinhood's browser-facing host is an offline/local HTTP application.

The host is responsible for:
- serving the UI and offline route metadata;
- selecting a route;
- carrying authenticated-by-route adapter events;
- displaying execution state.

The host does not infer exploit success from page navigation, a fetch response,
or a timer.

Execution state must come from the selected route adapter.

Recommended lifecycle:

`HOST_READY → ROUTE_SELECTED → ENTRY_RUNNING → KERNEL_RUNNING → PAYLOAD_RUNNING → COMPLETE`

Any route mismatch or adapter failure is terminal for that run.

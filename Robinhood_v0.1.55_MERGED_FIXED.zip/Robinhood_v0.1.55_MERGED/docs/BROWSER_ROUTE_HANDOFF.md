# Browser Route Handoff

The PS4-facing host now has a defined handoff stage:

`firmware detection → route preparation → execution gate → adapter events`

The single user action is intentionally separate from route preparation.
Preparation never means jailbreak success.

Only a verified adapter may transition an execution request into real entry,
kernel, payload and completion events.

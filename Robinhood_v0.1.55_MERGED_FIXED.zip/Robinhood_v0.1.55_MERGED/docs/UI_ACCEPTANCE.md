# UI Acceptance Criteria

Robinhood's user interface must never turn a compatibility record into a
guarantee.

For every route card:

- console and firmware are visible;
- compatibility status is visible;
- evidence grade is visible;
- reliability is visible;
- prerequisites are visible when applicable;
- provenance/source references are available;
- reported routes use validation/research language;
- unknown/unsupported routes do not present an execution action.

The frontend is a presentation layer over the evidence database; it must not
invent compatibility states.

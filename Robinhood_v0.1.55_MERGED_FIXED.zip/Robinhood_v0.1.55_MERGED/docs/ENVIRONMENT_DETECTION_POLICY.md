# Environment Detection Policy

Robinhood uses browser/runtime information only as a hint.

A browser user-agent, platform string, screen size, language, or similar value
cannot establish an exact PlayStation firmware version.

Therefore:

- automatic browser hints are labelled `NON_AUTHORITATIVE`;
- manually entered console/firmware values are labelled `USER_CONFIRMED`;
- future console-side evidence may introduce a stronger evidence class;
- unknown firmware never selects a route automatically.

This keeps detection separate from compatibility evidence.

# Research Data Integrity

Robinhood now maintains a SHA-256 manifest over its research database.

The manifest covers compatibility, firmware matrices, source records,
repositories, claims, components, reliability observations, lifecycle data,
review queues, and research-dashboard data.

This does not prove that a source is truthful. It proves that the locally
stored research record has not silently changed since the manifest was created.

The release pipeline separately hashes the complete distribution.

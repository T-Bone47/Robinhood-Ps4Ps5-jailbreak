# Current Upstream Audit — 2026-08-26

- Al-Azif/psfree-lapse: v1.5.1 / 3e47ad9. The repository documents a functional/tested PS4 chain for 7.00–9.60; its release notes mark 8.50–9.60 work as WIP.
- GoldHEN/henloader_lp: release 1.0 / 10f5c4b. The release states Lapse 9.00–12.02 + Poops 9.00–12.52 and includes GoldHEN 2.4b18.7.
- The HenLoader repository README has broader wording than its release notes; Robinhood preserves this contradiction instead of silently resolving it.
- ArabPixel/PSFree-Enhanced has been rebranded to WebKitty; old references are treated as historical until a fresh exact release/commit is pinned.

No route is promoted to an executable adapter by this audit.

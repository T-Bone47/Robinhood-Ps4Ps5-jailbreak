# PS4 12.52 Status

Checked: 2026-08-26.

## Current evidence

The current GoldHEN/henloader_lp source explicitly excludes 12.50 and 12.52
from the Lapse path and falls through to Poops. This is primary source-code
evidence that the project has a dedicated Poops route for 12.52.

A separate public BD-JB-1252 repository independently targets PS4 12.50-12.52.

Therefore Robinhood now records PS4 12.52 as **REPORTED**, not UNKNOWN.

## Reliability

An open upstream issue reports crashes/shutdowns during 12.52 activation.
Another upstream issue reports successful 12.52 jailbreak followed by reuse of
an existing `/data/payload.bin`, demonstrating payload-state behavior.

Therefore:

- compatibility: REPORTED
- exploit path: REPORTED
- HEN integration: REPORTED
- payload loading: REPORTED
- reliability: UNKNOWN

Robinhood must not display 12.52 as a guaranteed/stable route.

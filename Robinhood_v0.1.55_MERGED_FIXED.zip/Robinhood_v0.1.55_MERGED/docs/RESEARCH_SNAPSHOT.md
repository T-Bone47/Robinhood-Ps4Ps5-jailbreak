# Robinhood Research Snapshot

Checked: 2026-08-25.

## PS4

- PPPwn upstream explicitly supports 7.00 through 11.00.
- PPPwn is a kernel RCE proof of concept and does not itself constitute a complete HEN route.
- GoldHEN releases explicitly list supported firmware through 11.00.
- PS4 12.52 remains UNKNOWN in Robinhood.

## PS5

- The current Y2JB Autoloader repository claims 4.03-12.70.
- Its v0.8 release notes specifically say P2JB was added above 10.01 through 12.70; lower firmwares use Lapse.
- v0.9 is the latest listed release.
- Public 12.70 testing contains both successful and failed reports.
- Therefore Robinhood records the broad 10.02-12.70 P2JB range as REPORTED, not VERIFIED.

## Engineering rule

Only VERIFIED entries may expose a future execution/start action.

REPORTED, PARTIAL and EXPERIMENTAL entries are research states.
UNKNOWN entries are never inferred from nearby firmware.

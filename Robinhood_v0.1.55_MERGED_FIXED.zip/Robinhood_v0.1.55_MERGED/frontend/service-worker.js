const CACHE_NAME = "robinhood-v0.1.31";
const CORE_ASSETS = [
  "/",
  "/index.html",
  "/database/ui-acceptance.json",
  "/frontend/js/compatibility-view.js",
  "/database/research-dashboard.json",
  "/database/route-explanations.json",
  "/database/firmware-format.json",
  "/frontend/js/research-dashboard.js",
  "/research.html",
  "/frontend/css/base.css",
  "/frontend/js/ui-state.js",
  "/frontend/js/compatibility-db.js",
  "/frontend/js/sources.js",
  "/frontend/js/provenance.js",
  "/frontend/js/app.js",
  "/frontend/js/reference-routes.js",
  "/frontend/js/execution-orchestrator.js",
  "/database/reference/legacy-host-routes.json",
  "/frontend/design-system.json",
  "/database/compatibility.json",
  "/database/sources.json",
  "/database/components.json",
  "/database/claim-ledger.json",
  "/database/firmware-matrix.json"
];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(CORE_ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys
          .filter(key => key.startsWith("robinhood-") && key !== CACHE_NAME)
          .map(key => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;

  event.respondWith(
    caches.match(request).then(cached => {
      if (cached) return cached;

      return fetch(request).then(response => {
        if (!response || response.status !== 200 || response.type === "opaque") {
          return response;
        }

        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(request, copy));
        return response;
      }).catch(() => {
        if (request.mode === "navigate") {
          return caches.match("/index.html");
        }
        return Response.error();
      });
    })
  );
});

window.ROBINHOOD_REFERENCE_ROUTES = [
  {
    "id": "ps4jb-672-reference",
    "console": "PS4",
    "min_firmware": 6.72,
    "max_firmware": 6.72,
    "status": "REFERENCE_ONLY",
    "entry": "common/exploit.js",
    "kernel": [
      "jb/jb.js",
      "jb/oldjb.js"
    ],
    "goldhen": "payloads/goldhen.js",
    "combined_flow": "load_Both -> exploit(true) -> jb -> payload loader",
    "offline_manifest": "offlineCache672.manifest",
    "execution_enabled": false
  },
  {
    "id": "ps4jb-702-reference",
    "console": "PS4",
    "min_firmware": 7.02,
    "max_firmware": 7.02,
    "status": "REFERENCE_ONLY",
    "entry": [
      "utils.js",
      "int64.js",
      "rop.js",
      "payloads.js",
      "userland.js",
      "ps4.js"
    ],
    "kernel": "jb stage referenced by the source host",
    "goldhen": "source host exposes payload loader after exploit stage",
    "offline_manifest": "offlineCache702.manifest",
    "execution_enabled": false
  },
  {
    "id": "ps4jb-75x-reference",
    "console": "PS4",
    "min_firmware": 7.5,
    "max_firmware": 7.55,
    "status": "REFERENCE_ONLY",
    "entry": "webkit/ps4.js",
    "kernel": [
      "jb/jb.js",
      "jb/oldjb.js"
    ],
    "goldhen": [
      "payloads/goldhen750.js",
      "payloads/goldhen751.js",
      "payloads/goldhen755.js"
    ],
    "offline_manifest": "75XV2/offlineCache.manifest",
    "execution_enabled": false
  },
  {
    "id": "ps4jb-900-reference",
    "console": "PS4",
    "min_firmware": 9.0,
    "max_firmware": 9.0,
    "status": "REFERENCE_ONLY",
    "entry": "source-specific firmware host route",
    "kernel": "source-specific firmware host route",
    "goldhen": "payloads/goldhen.js",
    "combined_flow": "host route -> exploit stage -> payload loader",
    "offline_manifest": "firmware-specific manifest",
    "execution_enabled": false
  }
];

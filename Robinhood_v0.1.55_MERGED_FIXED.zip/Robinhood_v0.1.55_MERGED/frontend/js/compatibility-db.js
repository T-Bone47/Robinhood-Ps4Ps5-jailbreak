window.ROBINHOOD_COMPATIBILITY = [
  {
    "console": "PS4",
    "firmware": "7.00",
    "min_firmware": 7.0,
    "max_firmware": 7.0,
    "status": "PARTIAL",
    "reliability": "UNKNOWN",
    "chain": "ps4-pppwn",
    "hen": null,
    "loader": null,
    "payloads": [],
    "offline": false,
    "summary": "Kernel RCE PoC is documented upstream; complete Robinhood HEN route is not yet integrated.",
    "source_ids": [
      "github-pppwn"
    ],
    "last_verified": "2026-08-25",
    "entry_route": "ps4-pppwn",
    "prerequisites": [],
    "evidence_level": "DATABASE_ENTRY",
    "components": {
      "webkit": null,
      "kernel": null,
      "hen": null,
      "loader": null,
      "payloads": []
    },
    "route_type": "EXPLOIT_CHAIN",
    "evidence_grade": "UNKNOWN"
  },
  {
    "console": "PS4",
    "firmware": "9.00",
    "min_firmware": 9.0,
    "max_firmware": 9.0,
    "status": "PARTIAL",
    "reliability": "UNKNOWN",
    "chain": "ps4-pppwn",
    "hen": "goldhen",
    "loader": null,
    "payloads": [],
    "offline": false,
    "summary": "PPPwn and GoldHEN are independently documented for this firmware; Robinhood has not yet integrated a complete execution route.",
    "source_ids": [
      "github-pppwn",
      "github-goldhen-releases"
    ],
    "last_verified": "2026-08-25",
    "entry_route": "ps4-pppwn",
    "prerequisites": [],
    "evidence_level": "DATABASE_ENTRY",
    "components": {
      "webkit": null,
      "kernel": null,
      "hen": "goldhen",
      "loader": null,
      "payloads": []
    },
    "route_type": "EXPLOIT_CHAIN",
    "evidence_grade": "UNKNOWN"
  },
  {
    "console": "PS4",
    "firmware": "11.00",
    "min_firmware": 11.0,
    "max_firmware": 11.0,
    "status": "PARTIAL",
    "reliability": "UNKNOWN",
    "chain": "ps4-pppwn",
    "hen": "goldhen",
    "loader": null,
    "payloads": [],
    "offline": false,
    "summary": "PPPwn and GoldHEN are independently documented for this firmware; Robinhood has not yet integrated a complete execution route.",
    "source_ids": [
      "github-pppwn",
      "github-goldhen-releases"
    ],
    "last_verified": "2026-08-25",
    "entry_route": "ps4-pppwn",
    "prerequisites": [],
    "evidence_level": "DATABASE_ENTRY",
    "components": {
      "webkit": null,
      "kernel": null,
      "hen": "goldhen",
      "loader": null,
      "payloads": []
    },
    "route_type": "EXPLOIT_CHAIN",
    "evidence_grade": "UNKNOWN"
  },
  {
    "console": "PS5",
    "firmware": "10.20-12.70",
    "min_firmware": 10.2,
    "max_firmware": 12.7,
    "status": "REPORTED",
    "reliability": "UNKNOWN",
    "chain": "ps5-y2jb-autoloader",
    "entry_route": "ps5-y2jb-autoloader",
    "hen": null,
    "loader": "ps5-y2jb-autoloader",
    "payloads": [],
    "offline": true,
    "prerequisites": [],
    "evidence_level": "UPSTREAM_RELEASE_PLUS_COMMUNITY_TESTING",
    "summary": "Current upstream v0.8 release notes state P2JB support for firmware above 10.01 through 12.70; current fork/source notes resolve this operationally to 10.20-12.70. Robinhood keeps this route REPORTED because public testing shows firmware-specific instability.",
    "source_ids": [
      "github-ps5-y2jb-autoloader-current",
      "github-ps5-y2jb-releases",
      "github-ps5-y2jb-testing-current"
    ],
    "last_verified": "2026-08-25",
    "components": {
      "webkit": "Y2JB entry",
      "kernel": "P2JB/Lapse depending on firmware",
      "hen": null,
      "loader": "ps5-y2jb-autoloader",
      "payloads": []
    },
    "route_type": "EXPLOIT_CHAIN",
    "evidence_grade": "PRIMARY_REPORTED"
  },
  {
    "console": "PS4",
    "firmware": "12.02-12.52",
    "min_firmware": 12.02,
    "max_firmware": 12.52,
    "status": "REPORTED",
    "reliability": "UNKNOWN",
    "chain": "ps4-bdj-poops-1252",
    "entry_route": "BD-JB / Poops",
    "hen": "GoldHEN 2.4b18.7 bundled in HenLoader LP 1.0",
    "loader": "HenLoader LP",
    "payloads": [
      "payload.bin"
    ],
    "offline": true,
    "prerequisites": [
      "Blu-ray/BD-J entry path"
    ],
    "evidence_level": "UPSTREAM_SOURCE_PLUS_CORROBORATION",
    "components": {
      "webkit": null,
      "kernel": "Poops",
      "hen": "GoldHEN integration documented",
      "loader": "HENloader LP / BD-JB ecosystem",
      "payloads": [
        "payload.bin"
      ]
    },
    "summary": "Primary source code shows Poops selected for 12.52; reliability remains UNKNOWN.",
    "source_ids": [
      "github-bdj-1252",
      "github-bdj-jb-1252",
      "github-goldhen-henloader-current",
      "github-goldhen-henloader-lp-current",
      "github-goldhen-henloader-lp-release-1",
      "github-henloader-crash-12-52",
      "github-henloader-payload-update-12-52"
    ],
    "last_verified": "2026-08-26",
    "route_type": "EXPLOIT_CHAIN",
    "evidence_grade": "PRIMARY_REPORTED"
  },
  {
    "console": "PS5",
    "firmware": "9.00-12.00",
    "min_firmware": 9.0,
    "max_firmware": 12.0,
    "status": "REPORTED",
    "reliability": "UNKNOWN",
    "chain": "ps5-webkit-autoloader",
    "entry_route": "PS5 WebKit Autoloader",
    "hen": null,
    "loader": "ps5-webkit-autoloader",
    "payloads": [],
    "offline": true,
    "prerequisites": [],
    "evidence_level": "UPSTREAM_REPOSITORY",
    "components": {
      "webkit": "PS5 WebKit entry",
      "kernel": "autoloader-integrated",
      "hen": null,
      "loader": "ps5-webkit-autoloader",
      "payloads": []
    },
    "summary": "Upstream WebKit Autoloader documents 9.00-12.00. Robinhood records the host/entry capability separately from a complete HEN claim.",
    "source_ids": [
      "github-ps5-webkit-autoloader"
    ],
    "last_verified": "2026-08-26",
    "route_type": "ENTRY_HOST",
    "evidence_grade": "PRIMARY_REPORTED"
  },
  {
    "console": "PS5",
    "firmware": "7.00-8.60",
    "min_firmware": 7.0,
    "max_firmware": 8.6,
    "status": "EXPERIMENTAL",
    "reliability": "UNKNOWN",
    "chain": "ps5-webkit-autoloader-pre-release",
    "entry_route": "PS5 WebKit Autoloader v0.4.0 pre-release",
    "hen": null,
    "loader": "ps5-webkit-autoloader",
    "payloads": [],
    "offline": true,
    "prerequisites": [],
    "evidence_level": "UPSTREAM_PRE_RELEASE",
    "components": {
      "webkit": "PS5 WebKit entry",
      "kernel": "pre-release autoloader integration",
      "hen": null,
      "loader": "ps5-webkit-autoloader",
      "payloads": []
    },
    "summary": "Maintainer pre-release discussion announces 7.00-8.60 support. This remains experimental until release-level evidence is established.",
    "source_ids": [
      "github-ps5-webkit-autoloader-v04"
    ],
    "last_verified": "2026-08-26",
    "route_type": "EXPLOIT_CHAIN",
    "evidence_grade": "UNKNOWN"
  }
];

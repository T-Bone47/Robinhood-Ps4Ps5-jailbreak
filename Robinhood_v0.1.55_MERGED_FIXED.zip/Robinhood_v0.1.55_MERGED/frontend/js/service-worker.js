const CACHE_NAME = 'robinhood-v1.0.0';
const MANIFEST_URL = 'cache/manifest.json';

const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/frontend/index.html',
  '/frontend/css/base.css',
  '/frontend/css/console.css',
  '/frontend/css/advanced.css',
  '/frontend/css/research.css',
  '/frontend/js/app.js',
  '/database/ps4.json',
  '/database/ps5.json',
  '/database/exploit-chains.json',
  '/database/hen.json',
  '/database/payloads.json',
  '/database/sources.json',
  '/version.json'
];

async function fetchManifest() {
  try {
    const response = await fetch(MANIFEST_URL, { cache: 'no-store' });
    if (!response.ok) throw new Error(`Manifest fetch failed: ${response.status}`);
    return await response.json();
  } catch (e) {
    console.warn('[SW] Failed to fetch manifest, using static list:', e);
    return null;
  }
}

async function installStaticAssets(cache) {
  const results = await Promise.allSettled(
    STATIC_ASSETS.map(url => cache.add(url).catch(e => {
      console.warn(`[SW] Failed to cache ${url}:`, e);
      return null;
    }))
  );
  
  const failed = results.filter(r => r.status === 'rejected' || (r.status === 'fulfilled' && r.value === null));
  if (failed.length > 0) {
    console.warn(`[SW] ${failed.length} static assets failed to cache`);
  }
  
  return results.filter(r => r.status === 'fulfilled' && r.value !== null).length;
}

async function installManifestAssets(cache, manifest) {
  if (!manifest?.files) return 0;
  
  const entries = Object.entries(manifest.files);
  const results = await Promise.allSettled(
    entries.map(([relPath, meta]) => {
      const url = `/${relPath.replace(/\\/g, '/')}`;
      return cache.add(url).catch(e => {
        console.warn(`[SW] Failed to cache ${url}:`, e);
        return null;
      });
    })
  );
  
  const failed = results.filter(r => r.status === 'rejected' || (r.status === 'fulfilled' && r.value === null));
  if (failed.length > 0) {
    console.warn(`[SW] ${failed.length} manifest assets failed to cache`);
  }
  
  return results.filter(r => r.status === 'fulfilled' && r.value !== null).length;
}

self.addEventListener('install', event => {
  console.log('[SW] Installing...');
  event.waitUntil(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      let count = 0;
      
      count += await installStaticAssets(cache);
      
      const manifest = await fetchManifest();
      if (manifest) {
        count += await installManifestAssets(cache, manifest);
      }
      
      console.log(`[SW] Cached ${count} assets`);
      await self.skipWaiting();
    })()
  );
});

self.addEventListener('activate', event => {
  console.log('[SW] Activating...');
  event.waitUntil(
    (async () => {
      const cacheNames = await caches.keys();
      await Promise.all(
        cacheNames
          .filter(name => name !== CACHE_NAME)
          .map(name => {
            console.log('[SW] Deleting old cache:', name);
            return caches.delete(name);
          })
      );
      await self.clients.claim();
      console.log('[SW] Activated');
    })()
  );
});

async function cacheFirstStrategy(request) {
  const cache = await caches.open(CACHE_NAME);
  const cached = await cache.match(request);
  
  if (cached) {
    return cached;
  }
  
  try {
    const response = await fetch(request);
    
    if (response.ok && (request.method === 'GET' || request.method === 'HEAD')) {
      cache.put(request, response.clone());
    }
    
    return response;
  } catch (e) {
    console.warn('[SW] Network request failed:', e);
    throw e;
  }
}

async function networkFirstStrategy(request) {
  const cache = await caches.open(CACHE_NAME);
  
  try {
    const response = await fetch(request);
    
    if (response.ok && (request.method === 'GET' || request.method === 'HEAD')) {
      cache.put(request, response.clone());
    }
    
    return response;
  } catch (e) {
    const cached = await cache.match(request);
    if (cached) {
      return cached;
    }
    throw e;
  }
}

function getStrategy(request) {
  const url = new URL(request.url);
  
  if (url.pathname.startsWith('/database/') || url.pathname.startsWith('/cache/')) {
    return 'cache-first';
  }
  
  if (url.pathname.endsWith('.json')) {
    return 'network-first';
  }
  
  return 'cache-first';
}

self.addEventListener('fetch', event => {
  const request = event.request;
  
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    return;
  }
  
  const strategy = getStrategy(request);
  
  if (strategy === 'network-first') {
    event.respondWith(networkFirstStrategy(request));
  } else {
    event.respondWith(cacheFirstStrategy(request));
  }
});

self.addEventListener('message', event => {
  if (event.data?.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  if (event.data?.type === 'GET_VERSION') {
    event.ports[0].postMessage({ version: CACHE_NAME });
  }
  
  if (event.data?.type === 'CLEAR_CACHE') {
    event.waitUntil(
      caches.keys().then(names => 
        Promise.all(names.map(name => caches.delete(name)))
      ).then(() => {
        event.ports[0].postMessage({ success: true });
      })
    );
  }
});

console.log('[SW] Service worker loaded');
(function () {
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("/frontend/service-worker.js", { updateViaCache: "none" }).catch(() => {});
    });
  }

  const db = window.ROBINHOOD_COMPATIBILITY || [];
  const referenceRoutes = window.ROBINHOOD_REFERENCE_ROUTES || [];
  const consoleEl = document.getElementById("console");
  const firmwareEl = document.getElementById("firmware");
  const check = document.getElementById("check");
  const headline = document.getElementById("headline");
  const status = document.getElementById("status");
  const resultCard = document.getElementById("result-card");
  const result = document.getElementById("result");
  const detailsCard = document.getElementById("details-card");
  const details = document.getElementById("details");
  const sourceMap = window.ROBINHOOD_SOURCES || {};
  const chainCard = document.getElementById("chain-card");
  const chainTitle = document.getElementById("chain-title");
  const chainStatus = document.getElementById("chain-status");
  const chainBadge = document.getElementById("chain-badge");
  const chainMeta = document.getElementById("chain-meta");
  const chainLog = document.getElementById("chain-log");
  const jailbreak = document.getElementById("jailbreak");

  function parseFirmware(value) {
    const raw = String(value || "").trim();
    const match = raw.match(/^(\d+)(?:\.(\d{1,2}))?$/);
    if (!match) return null;
    const major = Number(match[1]);
    const minor = Number((match[2] || "0").padEnd(2, "0"));
    return { raw, numeric: major + minor / 100 };
  }

  function resolve(consoleName, firmwareInput) {
    const firmware = parseFirmware(firmwareInput);
    if (!firmware) return null;
    return db.find(item => item.console === consoleName && firmware.numeric >= item.min_firmware && firmware.numeric <= item.max_firmware) || null;
  }

  function referenceRoute(consoleName, firmwareInput) {
    const firmware = parseFirmware(firmwareInput);
    if (!firmware) return null;
    return referenceRoutes.find(item => item.console === consoleName && firmware.numeric >= item.min_firmware && firmware.numeric <= item.max_firmware) || null;
  }

  function escapeHtml(value) {
    return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
  }

  function renderChain(entry, reference, firmwareInput) {
    chainCard.classList.remove("hidden");
    const executable = Boolean(entry && entry.status === "VERIFIED" && entry.execution_enabled === true);
    chainTitle.textContent = reference ? "Reference chain mapped" : (entry ? "Documented route" : "No route mapped");
    chainStatus.textContent = executable
      ? "A production adapter is eligible for execution."
      : reference
        ? "This matches the supplied PS4JB architecture, but the reference adapter is declaration-only."
        : "Robinhood will not execute an unverified route.";
    chainBadge.textContent = executable ? "READY" : "RESEARCH-ONLY";
    jailbreak.disabled = !executable;

    const rows = [
      ["Firmware", firmwareInput],
      ["Database state", entry?.status || "UNKNOWN"],
      ["Reference ID", reference?.id || "—"],
      ["Entry", Array.isArray(reference?.entry) ? reference.entry.join(", ") : (reference?.entry || entry?.entry_route || "—")],
      ["Kernel", Array.isArray(reference?.kernel) ? reference.kernel.join(", ") : (reference?.kernel || entry?.components?.kernel || "—")],
      ["GoldHEN", Array.isArray(reference?.goldhen) ? reference.goldhen.join(", ") : (reference?.goldhen || entry?.components?.hen || entry?.hen || "—")],
      ["Offline manifest", reference?.offline_manifest || "—"]
    ];
    chainMeta.innerHTML = rows.map(([k,v]) => `<div class="result-row"><strong>${escapeHtml(k)}:</strong> ${escapeHtml(v)}</div>`).join("");
    chainLog.textContent = reference
      ? "[i] Reference route loaded\n[i] Execution adapter: disabled\n[i] No exploit or payload is being executed by this build."
      : "Waiting for a route…";
  }

  function render(entry, firmwareInput) {
    const reference = referenceRoute(consoleEl.value, firmwareInput);
    const presentation = routePresentation(entry);
    resultCard.classList.remove("hidden");
    headline.textContent = presentation.badge;
    status.textContent = presentation.message;

    const rows = [
      ["Console", entry?.console || consoleEl.value],
      ["Firmware", firmwareInput],
      ["State", presentation.title],
      ["Entry route", entry?.entry_route || "UNRESOLVED"],
      ["WebKit", entry?.components?.webkit || "UNRESOLVED"],
      ["Kernel", entry?.components?.kernel || "UNRESOLVED"],
      ["HEN", entry?.components?.hen || entry?.hen || "UNRESOLVED"],
      ["Loader", entry?.components?.loader || entry?.loader || "UNRESOLVED"],
      ["Reliability", entry?.reliability || "UNKNOWN"],
      ["Evidence", entry?.evidence_level || "UNKNOWN"]
    ];
    result.innerHTML = rows.map(([key, value]) => `<div class='result-row'><strong>${escapeHtml(key)}:</strong> ${escapeHtml(value)}</div>`).join("");
    result.innerHTML += presentation.action === "PREPARE"
      ? "<div class='action-note'>Verified route: production execution remains gated by adapter installation and device validation.</div>"
      : "<div class='action-note'>Execution is intentionally unavailable for this research state.</div>";

    const provenance = (entry?.source_ids || []).map(id => sourceMap[id]).filter(Boolean);
    details.textContent = JSON.stringify({ entry, reference, provenance }, null, 2);
    renderChain(entry, reference, firmwareInput);
  }

  check.addEventListener("click", function () {
    const parsed = parseFirmware(firmwareEl.value);
    if (!parsed) {
      render(null, firmwareEl.value);
      headline.textContent = "INVALID";
      status.textContent = "Enter a firmware such as 9.00 or 12.52.";
      return;
    }
    render(resolve(consoleEl.value, firmwareEl.value), firmwareEl.value);
  });

  jailbreak.addEventListener("click", () => {
    chainLog.textContent += "\n[!] Execution adapter is not installed in this release.";
  });

  document.querySelectorAll("[data-mode]").forEach(button => {
    button.addEventListener("click", () => {
      detailsCard.classList.remove("hidden");
      if (button.dataset.mode === "research") {
        details.textContent = JSON.stringify({
          mode: "research",
          source_policy: "Upstream source evidence first",
          status_policy: "UNKNOWN is never inferred",
          reference_host_model: "Firmware-specific offline route + exploit stage + payload stage",
          current_database_entries: db.length,
          reference_routes: referenceRoutes.length
        }, null, 2);
      } else {
        details.textContent = JSON.stringify({
          mode: "advanced",
          fields: ["entry_route", "components", "prerequisites", "source_ids", "evidence_level", "reliability"],
          orchestration: ["ENVIRONMENT", "ROUTE_RESOLVED", "ASSETS_READY", "ENTRY_READY", "KERNEL_READY", "PAYLOAD_READY", "COMPLETE"]
        }, null, 2);
      }
    });
  });
})();

import { DiagnosticsValidator } from '../../core/diagnostics/validator.js';
import { show, hide, setText, setHtml, onClick } from './ui.js';

export class DiagnosticsUI {
  constructor() {
    this.validator = new DiagnosticsValidator();
    this.container = null;
    this.running = false;
    this.retryCount = 0;
    this.maxRetries = 3;
  }

  init(containerId) {
    this.container = document.getElementById(containerId);
    this.render();
    this.bindEvents();
  }

  render() {
    if (!this.container) return;
    this.container.innerHTML = `
      <div class="diagnostics-panel" id="diagnostics-panel">
        <div class="diagnostics-header">
          <h2>System Diagnostics</h2>
          <span class="diagnostics-status" id="diagnostics-overall-status">Checking...</span>
        </div>
        <div class="diagnostics-list" id="diagnostics-list"></div>
        <div class="diagnostics-actions">
          <button id="btn-run-diagnostics" class="btn btn-primary">Run Diagnostics</button>
          <button id="btn-clear-cache" class="btn btn-secondary" style="display:none;">Clear Cache & Reload</button>
        </div>
        <div class="diagnostics-summary hidden" id="diagnostics-summary"></div>
      </div>
    `;
  }

  bindEvents() {
    onClick('btn-run-diagnostics', () => this.runDiagnostics());
    onClick('btn-clear-cache', () => this.clearCacheAndReload());
  }

  async runDiagnostics() {
    if (this.running) return;
    this.running = true;
    this.retryCount = 0;

    const btn = document.getElementById('btn-run-diagnostics');
    btn.disabled = true;
    btn.textContent = 'Running...';

    const list = document.getElementById('diagnostics-list');
    list.innerHTML = '<div class="diagnostic-item running">Initializing diagnostics...</div>';

    const results = await this.validator.runAllChecks();
    this.renderResults(results);

    const summary = this.validator.getSummary();
    this.renderSummary(summary);

    btn.disabled = false;
    btn.textContent = 'Re-Run Diagnostics';
    this.running = false;

    // Show clear cache button if there are cache issues
    const cacheResult = results.cacheStorage;
    if (cacheResult && (cacheResult.status === 'fail' || cacheResult.status === 'warn')) {
      show(document.getElementById('btn-clear-cache'));
    }
  }

  renderResults(results) {
    const list = document.getElementById('diagnostics-list');
    list.innerHTML = '';

    for (const [key, result] of Object.entries(results)) {
      const item = document.createElement('div');
      item.className = `diagnostic-item ${result.status}`;
      item.innerHTML = `
        <div class="diagnostic-icon">${this.getStatusIcon(result.status)}</div>
        <div class="diagnostic-info">
          <div class="diagnostic-name">${this.formatName(key)}</div>
          <div class="diagnostic-message">${result.message}</div>
          ${result.details ? `<div class="diagnostic-details">${JSON.stringify(result.details)}</div>` : ''}
        </div>
      `;
      list.appendChild(item);
    }
  }

  renderSummary(summary) {
    const el = document.getElementById('diagnostics-summary');
    const overallIcon = {
      pass: '✅',
      warn: '⚠️',
      fail: '❌',
      pending: '⏳'
    }[summary.overall] || '❓';

    el.className = `diagnostics-summary ${summary.overall}`;
    el.innerHTML = `
      <div class="summary-overall">${overallIcon} System Status: ${summary.overall.toUpperCase()}</div>
      <div class="summary-detail">${summary.ready ? '✅ Ready for exploit execution' : '⚠️ Issues detected - review above'}</div>
      ${summary.canExecute ? '<div class="summary-action">You may proceed to START</div>' : '<div class="summary-action error">Resolve critical issues before proceeding</div>'}
    `;
    show(el);
  }

  getStatusIcon(status) {
    const icons = { pass: '✅', warn: '⚠️', fail: '❌', error: '💥', skip: '⏭️', pending: '⏳', running: '🔄' };
    return icons[status] || '❓';
  }

  formatName(key) {
    return key.replace(/([A-Z])/g, ' $1').replace(/^./, c => c.toUpperCase());
  }

  async clearCacheAndReload() {
    if ('caches' in window) {
      const cacheNames = await caches.keys();
      await Promise.all(cacheNames.map(name => caches.delete(name)));
    }
    if ('serviceWorker' in navigator) {
      const registrations = await navigator.serviceWorker.getRegistrations();
      await Promise.all(registrations.map(reg => reg.unregister()));
    }
    window.location.reload();
  }

  setCompatibilityResult(compat) {
    this.validator.updateCompatibility(compat);
    if (this.container && !this.container.classList.contains('hidden')) {
      this.renderResults(this.validator.results);
      this.renderSummary(this.validator.getSummary());
    }
  }
}

export async function runPreFlightDiagnostics() {
  const validator = new DiagnosticsValidator();
  return validator.runAllChecks();
}
/**
 * Auto-Retry & Error Recovery Manager
 * Handles common console browser errors with safe retry logic
 */

class RetryManager {
  constructor(options = {}) {
    this.maxRetries = options.maxRetries || 3;
    this.retryDelay = options.retryDelay || 2000;
    this.backoffMultiplier = options.backoffMultiplier || 1.5;
    this.retryCount = 0;
    this.currentOperation = null;
    this.operationHistory = [];
    this.onRetry = options.onRetry || (() => {});
    this.onMaxRetriesExceeded = options.onMaxRetriesExceeded || (() => {});
    this.onSuccess = options.onSuccess || (() => {});
  }

  async execute(operation, context = {}) {
    this.currentOperation = { operation, context, startTime: Date.now() };
    this.retryCount = 0;

    while (true) {
      try {
        const result = await operation();
        this.onSuccess(result, this.currentOperation);
        this.recordAttempt(true, null);
        return result;
      } catch (err) {
        this.recordAttempt(false, err);
        
        if (this.shouldRetry(err)) {
          this.retryCount++;
          await this.waitBeforeRetry();
          this.onRetry(this.retryCount, err, this.currentOperation);
          continue;
        }
        
        this.onMaxRetriesExceeded(err, this.currentOperation);
        throw err;
      }
    }
  }

  shouldRetry(err) {
    if (this.retryCount >= this.maxRetries) return false;
    
    // Don't retry on user cancellation or explicit non-retryable errors
    if (err.name === 'AbortError' || err.nonRetryable) return false;
    
    // Retry on common transient errors
    const retryablePatterns = [
      'out of memory',
      'memory',
      'timeout',
      'network',
      'fetch',
      'connection',
      'econnreset',
      'etimedout',
      'socket',
      'webgl context lost',
      'gpu',
    ];
    
    const msg = (err.message || '').toLowerCase();
    return retryablePatterns.some(pattern => msg.includes(pattern));
  }

  waitBeforeRetry() {
    const delay = this.retryDelay * Math.pow(this.backoffMultiplier, this.retryCount - 1);
    return new Promise(resolve => setTimeout(resolve, delay));
  }

  recordAttempt(success, error) {
    this.operationHistory.push({
      timestamp: Date.now(),
      success,
      error: error?.message,
      retryCount: this.retryCount,
    });
    
    // Keep only last 20 attempts
    if (this.operationHistory.length > 20) {
      this.operationHistory.shift();
    }
  }

  getStats() {
    const total = this.operationHistory.length;
    const successes = this.operationHistory.filter(a => a.success).length;
    const failures = total - successes;
    const retries = this.operationHistory.filter(a => a.retryCount > 0).length;
    
    return { total, successes, failures, retries, retryRate: total > 0 ? retries / total : 0 };
  }

  reset() {
    this.retryCount = 0;
    this.currentOperation = null;
  }
}

/**
 * Execution State Manager
 * Manages the exploit execution lifecycle with persistence
 */
class ExecutionStateManager {
  constructor() {
    this.state = 'idle';
    this.currentStep = null;
    this.stepHistory = [];
    this.startTime = null;
    this.error = null;
    this.listeners = new Set();
  }

  setState(state, step = null) {
    const prevState = this.state;
    this.state = state;
    this.currentStep = step;
    
    if (step) {
      this.stepHistory.push({
        step,
        timestamp: Date.now(),
        prevState,
      });
    }
    
    this.notify({ type: 'stateChange', state, step, prevState });
  }

  start() {
    this.stepHistory = [];
    this.startTime = Date.now();
    this.error = null;
    this.setState('running', 'initializing');
  }

  complete(success = true, result = null) {
    this.setState(success ? 'success' : 'failed', 'complete');
    this.notify({ type: 'complete', success, result, duration: Date.now() - this.startTime });
  }

  fail(error) {
    this.error = error;
    this.setState('failed', 'error');
    this.notify({ type: 'error', error });
  }

  getDuration() {
    if (!this.startTime) return 0;
    return Date.now() - this.startTime;
  }

  getHistory() {
    return [...this.stepHistory];
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  notify(event) {
    this.listeners.forEach(fn => fn(event));
  }

  getState() {
    return {
      state: this.state,
      currentStep: this.currentStep,
      duration: this.getDuration(),
      error: this.error?.message,
      history: this.getHistory(),
    };
  }
}

/**
 * Error Classifier for Console Browser
 */
const ConsoleErrors = {
  OUT_OF_MEMORY: 'OUT_OF_MEMORY',
  TIMEOUT: 'TIMEOUT',
  NETWORK_ERROR: 'NETWORK_ERROR',
  WEBGL_CONTEXT_LOST: 'WEBGL_CONTEXT_LOST',
  GPU_PROCESS_CRASHED: 'GPU_PROCESS_CRASHED',
  SECURITY_ERROR: 'SECURITY_ERROR',
  UNKNOWN: 'UNKNOWN',
};

function classifyError(err) {
  const msg = (err.message || '').toLowerCase();
  
  if (msg.includes('out of memory') || msg.includes('oom') || msg.includes('memory limit')) {
    return { type: ConsoleErrors.OUT_OF_MEMORY, recoverable: true, suggestion: 'Close other browser tabs and try again' };
  }
  if (msg.includes('timeout') || msg.includes('timed out')) {
    return { type: ConsoleErrors.TIMEOUT, recoverable: true, suggestion: 'Check network connection and retry' };
  }
  if (msg.includes('network') || msg.includes('fetch') || msg.includes('connection')) {
    return { type: ConsoleErrors.NETWORK_ERROR, recoverable: true, suggestion: 'Verify internet connection and retry' };
  }
  if (msg.includes('webgl') || msg.includes('gpu') || msg.includes('context lost')) {
    return { type: ConsoleErrors.WEBGL_CONTEXT_LOST, recoverable: true, suggestion: 'Reload page to restore WebGL context' };
  }
  if (msg.includes('security') || msg.includes('cors') || msg.includes('cross-origin')) {
    return { type: ConsoleErrors.SECURITY_ERROR, recoverable: false, suggestion: 'Check browser security settings' };
  }
  
  return { type: ConsoleErrors.UNKNOWN, recoverable: true, suggestion: 'Try reloading the page' };
}

export { RetryManager, ExecutionStateManager, ConsoleErrors, classifyError };
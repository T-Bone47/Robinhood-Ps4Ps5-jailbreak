
window.RobinhoodQuickActions=(()=>{
  const defaults=["EXPLOIT + GOLDHEN","FTP","APP DUMPER","DB BACKUP"];
  function build(profile){
    const names=(profile?.toolCards||[]).map(x=>x.name);
    return defaults.filter(x=>{
      if(x==="EXPLOIT + GOLDHEN") return true;
      const map={"FTP":"FTP","APP DUMPER":"App Dumper","DB BACKUP":"DB BackUp"};
      return names.includes(map[x]);
    });
  }
  return {build};
})();

export class Terminal {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    this.maxLines = options.maxLines || 500;
    this.autoScroll = options.autoScroll !== false;
    this.lines = [];
    this.isVisible = false;
    this.init();
  }

  init() {
    if (!this.container) return;
    this.container.innerHTML = `
      <div class="terminal-header">
        <span class="terminal-title">Execution Log</span>
        <div class="terminal-controls">
          <button class="terminal-btn" data-action="clear" title="Clear log">✕</button>
          <button class="terminal-btn" data-action="toggle" title="Toggle scroll">⤓</button>
          <button class="terminal-btn" data-action="copy" title="Copy log">⎘</button>
        </div>
      </div>
      <div class="terminal-output" id="${this.container.id}-output"></div>
    `;
    this.output = document.getElementById(`${this.container.id}-output`);
    
    this.container.querySelector('[data-action="clear"]').addEventListener('click', () => this.clear());
    this.container.querySelector('[data-action="toggle"]').addEventListener('click', () => this.toggleAutoScroll());
    this.container.querySelector('[data-action="copy"]').addEventListener('click', () => this.copy());
  }

  show() {
    this.isVisible = true;
    this.container.classList.remove('hidden');
  }

  hide() {
    this.isVisible = false;
    this.container.classList.add('hidden');
  }

  log(message, type = 'info', timestamp = true) {
    if (!this.output) return;
    
    const line = document.createElement('div');
    line.className = `terminal-line terminal-${type}`;
    
    const time = timestamp ? new Date().toLocaleTimeString() : '';
    const prefix = this.getPrefix(type);
    
    line.innerHTML = `
      ${time ? `<span class="terminal-time">${time}</span>` : ''}
      <span class="terminal-prefix">${prefix}</span>
      <span class="terminal-message">${this.escapeHtml(message)}</span>
    `;
    
    this.output.appendChild(line);
    this.lines.push({ message, type, time });
    
    if (this.lines.length > this.maxLines) {
      this.lines.shift();
      if (this.output.firstChild) this.output.removeChild(this.output.firstChild);
    }
    
    if (this.autoScroll) {
      this.output.scrollTop = this.output.scrollHeight;
    }
  }

  getPrefix(type) {
    const prefixes = {
      info: '[*]',
      success: '[+]',
      error: '[!]',
      warning: '[~]',
      step: '[>]',
      debug: '[#]'
    };
    return prefixes[type] || '[*]';
  }

  step(message) { this.log(message, 'step'); }
  success(message) { this.log(message, 'success'); }
  error(message) { this.log(message, 'error'); }
  warning(message) { this.log(message, 'warning'); }
  info(message) { this.log(message, 'info'); }
  debug(message) { this.log(message, 'debug'); }

  clear() {
    this.lines = [];
    if (this.output) this.output.innerHTML = '';
  }

  toggleAutoScroll() {
    this.autoScroll = !this.autoScroll;
    const btn = this.container.querySelector('[data-action="toggle"]');
    if (btn) btn.textContent = this.autoScroll ? '⤓' : '⤒';
  }

  copy() {
    const text = this.lines.map(l => `${l.time || ''} ${this.getPrefix(l.type)} ${l.message}`).join('\n');
    navigator.clipboard.writeText(text).then(() => {
      this.info('Log copied to clipboard');
    });
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

export class StatusScreen {
  static showUnsupported(containerId, console, firmware, reason = 'No verified exploit chain available for this firmware.') {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    container.innerHTML = `
      <div class="status-screen unsupported">
        <div class="status-icon-large" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="64" height="64"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
        </div>
        <h2>Unsupported Firmware</h2>
        <p class="console-info">${console} ${firmware}</p>
        <p class="status-reason">${reason}</p>
        <p class="status-hint">Robinhood will not attempt an unverified exploit chain.</p>
        <button class="btn btn-secondary" id="btn-back-unsupported">Back</button>
      </div>
    `;
    container.classList.remove('hidden');
    document.getElementById('btn-back-unsupported')?.addEventListener('click', () => {
      container.classList.add('hidden');
      container.innerHTML = '';
    });
  }

  static showExperimental(containerId, console, firmware, chainName, issues = []) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    container.innerHTML = `
      <div class="status-screen experimental">
        <div class="status-icon-large" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="64" height="64"><path fill="currentColor" d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>
        </div>
        <h2>Experimental Support</h2>
        <p class="console-info">${console} ${firmware}</p>
        <p class="status-reason">An experimental exploit chain is available but not fully verified.</p>
        <p class="chain-name">Chain: ${chainName}</p>
        ${issues.length ? `
          <ul class="issues-list">
            ${issues.map(i => `<li>${i}</li>`).join('')}
          </ul>
        ` : ''}
        <p class="status-hint">Do not expect reliable execution. Proceed at your own risk.</p>
        <div class="status-actions">
          <button class="btn btn-primary" id="btn-proceed-experimental">Proceed Anyway</button>
          <button class="btn btn-secondary" id="btn-back-experimental">Back</button>
        </div>
      </div>
    `;
    container.classList.remove('hidden');
    return {
      onProceed: (cb) => document.getElementById('btn-proceed-experimental')?.addEventListener('click', cb),
      onBack: (cb) => document.getElementById('btn-back-experimental')?.addEventListener('click', cb)
    };
  }

  static showError(containerId, title, message, retryable = false) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    container.innerHTML = `
      <div class="status-screen error">
        <div class="status-icon-large" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="64" height="64"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
        </div>
        <h2>${title}</h2>
        <p class="status-reason">${message}</p>
        <div class="status-actions">
          ${retryable ? '<button class="btn btn-primary" id="btn-retry-error">Retry</button>' : ''}
          <button class="btn btn-secondary" id="btn-back-error">Back</button>
        </div>
      </div>
    `;
    container.classList.remove('hidden');
    return {
      onRetry: (cb) => document.getElementById('btn-retry-error')?.addEventListener('click', cb),
      onBack: (cb) => document.getElementById('btn-back-error')?.addEventListener('click', cb)
    };
  }

  static showSuccess(containerId, compat, henName) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    container.innerHTML = `
      <div class="status-screen success">
        <div class="status-icon-large" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="64" height="64"><path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg>
        </div>
        <h2>Exploit Chain Completed</h2>
        <dl class="success-details">
          <dt>Console</dt><dd>${compat.console}</dd>
          <dt>Firmware</dt><dd>${compat.firmware}</dd>
          <dt>HEN</dt><dd>${henName}</dd>
          <dt>Payload Server</dt><dd>Active on default port</dd>
        </dl>
        <div class="status-actions">
          <button class="btn btn-primary" id="btn-restart-success">Restart</button>
          <button class="btn btn-secondary" id="btn-payloads-success">Manage Payloads</button>
        </div>
      </div>
    `;
    container.classList.remove('hidden');
    return {
      onRestart: (cb) => document.getElementById('btn-restart-success')?.addEventListener('click', cb),
      onPayloads: (cb) => document.getElementById('btn-payloads-success')?.addEventListener('click', cb)
    };
  }

  static hide(containerId) {
    const container = document.getElementById(containerId);
    if (container) {
      container.classList.add('hidden');
      container.innerHTML = '';
    }
  }
}

export function createElement(html) {
  const template = document.createElement('template');
  template.innerHTML = html.trim();
  return template.content.firstElementChild;
}

export function show(element) { element?.classList.remove('hidden'); }
export function hide(element) { element?.classList.add('hidden'); }
export function toggle(element, force) { element?.classList.toggle('hidden', force); }

export function setText(element, text) { if (element) element.textContent = text; }
export function setHtml(element, html) { if (element) element.innerHTML = html; }

export function onClick(id, handler) {
  const el = document.getElementById(id);
  if (el) el.addEventListener('click', handler);
}

export function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

export function formatSha256(hash, length = 16) {
  return hash ? `${hash.slice(0, length)}...` : 'N/A';
}
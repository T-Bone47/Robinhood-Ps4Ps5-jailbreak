import { CompatibilityEngine } from '../../core/compatibility/engine.js';
import { ExploitRouter } from '../../core/exploit-router/router.js';
import { formatBytes, formatSha256, createElement } from './ui.js';

export class ResearchView {
  constructor() {
    this.engine = new CompatibilityEngine();
    this.router = new ExploitRouter();
    this.currentCompat = null;
    this.currentChain = null;
    this.init();
  }

  async init() {
    await this.loadDatabase();
  }

  async loadDatabase() {
    try {
      await fetch('database/ps4.json').then(r => r.json()).then(d => this.engine.ps4DB = d);
      await fetch('database/ps5.json').then(r => r.json()).then(d => this.engine.ps5DB = d);
      await fetch('database/exploit-chains.json').then(r => r.json()).then(d => this.engine.chainsDB = d);
      await fetch('database/hen.json').then(r => r.json()).then(d => this.engine.henDB = d);
      await fetch('database/payloads.json').then(r => r.json()).then(d => this.engine.payloadsDB = d);
      await fetch('database/sources.json').then(r => r.json()).then(d => this.engine.sourcesDB = d);
      this.engine.loaded = true;
    } catch (err) {
      console.error('[ResearchView] Failed to load database:', err);
    }
  }

  update(compat) {
    this.currentCompat = compat;
    this.currentChain = this.router.getChainDetails(compat.recommended_chain?.id);
    this.renderAll();
  }

  renderAll() {
    if (!this.currentCompat) return;
    this.renderChain();
    this.renderSource();
    this.renderVersion();
    this.renderLicense();
    this.renderEvidence();
    this.renderIssues();
    this.renderHistory();
    this.renderReports();
  }

  renderChain() {
    const el = document.getElementById('research-chain');
    if (!this.currentChain) {
      el.innerHTML = '<p class="empty-state">No exploit chain data available</p>';
      return;
    }
    const c = this.currentChain;
    el.innerHTML = `
      <div class="research-section">
        <h3>Chain Overview</h3>
        <dl class="research-dl">
          <dt>Chain ID</dt><dd>${c.id}</dd>
          <dt>Name</dt><dd>${c.name}</dd>
          <dt>Console</dt><dd>${c.console}</dd>
          <dt>Entry Type</dt><dd>${c.entry_type}</dd>
          <dt>Status</dt><dd><span class="status-badge ${c.status.toLowerCase()}">${c.status}</span></dd>
          <dt>Reliability</dt><dd><span class="reliability-badge ${c.reliability.toLowerCase()}">${c.reliability}</span></dd>
          <dt>Supported Firmwares</dt><dd>${c.supported_firmware.join(', ')}</dd>
          <dt>Payload Formats</dt><dd>${c.payload_formats.join(', ')}</dd>
        </dl>
      </div>
      
      <div class="research-section">
        <h3>Architecture Layers</h3>
        <dl class="research-dl">
          <dt>WebKit Component</dt><dd>${c.webkit_component || 'N/A'}</dd>
          <dt>Userland Component</dt><dd>${c.userland_component || 'N/A'}</dd>
          <dt>Kernel Component</dt><dd>${c.kernel_component || 'N/A'}</dd>
          <dt>HEN Component</dt><dd>${c.hen_component || 'N/A'}</dd>
          <dt>Loader Component</dt><dd>${c.loader_component || 'N/A'}</dd>
        </dl>
      </div>
      
      <div class="research-section">
        <h3>Dependencies</h3>
        <p>${c.dependencies?.join(', ') || 'None declared'}</p>
      </div>
    `;
  }

  renderSource() {
    const el = document.getElementById('research-source');
    if (!this.currentChain) {
      el.innerHTML = '<p class="empty-state">No source data available</p>';
      return;
    }
    const c = this.currentChain;
    el.innerHTML = `
      <div class="research-section">
        <h3>Upstream Repositories</h3>
        <ul class="source-list">
          ${c.source_repositories.map(repo => `
            <li>
              <a href="${repo}" target="_blank" rel="noopener">${repo}</a>
              <button class="btn btn-sm btn-secondary copy-btn" data-url="${repo}" style="margin-left: var(--spacing-sm);">Copy</button>
            </li>
          `).join('')}
        </ul>
      </div>
      
      <div class="research-section">
        <h3>Compatible HEN Sources</h3>
        ${this.renderHenSources()}
      </div>
    `;
    
    el.querySelectorAll('.copy-btn').forEach(btn => {
      btn.addEventListener('click', () => navigator.clipboard.writeText(btn.dataset.url));
    });
  }

  renderHenSources() {
    if (!this.currentCompat?.hen_options?.length) return '<p>No HEN data</p>';
    
    return this.currentCompat.hen_options.map(h => {
      const hen = this.engine.henDB?.find(hen => hen.id === h.id);
      if (!hen) return '';
      return `
        <div class="hen-source">
          <h4>${h.name} v${h.version}</h4>
          <dl class="research-dl">
            <dt>Source</dt><dd><a href="${hen.source}" target="_blank" rel="noopener">${hen.source}</a></dd>
            <dt>License</dt><dd>${hen.license}</dd>
            <dt>Compatibility</dt><dd><span class="status-badge ${hen.compatibility.toLowerCase()}">${hen.compatibility}</span></dd>
            <dt>Firmware Range</dt><dd>${hen.firmware_range.join(', ')}</dd>
          </dl>
        </div>
      `;
    }).join('');
  }

  renderVersion() {
    const el = document.getElementById('research-version');
    if (!this.currentChain) {
      el.innerHTML = '<p class="empty-state">No version data available</p>';
      return;
    }
    const c = this.currentChain;
    const chainSources = this.currentCompat?.sources || [];
    
    el.innerHTML = `
      <div class="research-section">
        <h3>Exploit Chain Release</h3>
        <dl class="research-dl">
          <dt>Verification Method</dt><dd>${c.verification}</dd>
          <dt>License</dt><dd>${c.license}</dd>
        </dl>
      </div>
      
      <div class="research-section">
        <h3>Compatibility Record Sources</h3>
        ${chainSources.length ? `
          <table class="source-table">
            <thead>
              <tr><th>Project</th><th>Type</th><th>Authority</th><th>Commit</th><th>Release</th><th>Date Checked</th></tr>
            </thead>
            <tbody>
              ${chainSources.map(s => `
                <tr>
                  <td><strong>${s.project}</strong></td>
                  <td>${s.type}</td>
                  <td><span class="research-badge tier-${s.authority.toLowerCase().replace('_', '-')}">${s.authority}</span></td>
                  <td><code>${s.commit?.slice(0, 12) || 'N/A'}</code></td>
                  <td>${s.release || 'N/A'}</td>
                  <td>${s.date_checked || 'N/A'}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        ` : '<p>No source records</p>'}
      </div>
      
      <div class="research-section">
        <h3>HEN Versions</h3>
        ${this.renderHenVersions()}
      </div>
    `;
  }

  renderHenVersions() {
    if (!this.currentCompat?.hen_options?.length) return '<p>No HEN data</p>';
    
    return this.currentCompat.hen_options.map(h => {
      const hen = this.engine.henDB?.find(hen => hen.id === h.id);
      if (!hen) return '';
      return `
        <div class="hen-source">
          <h4>${h.name} v${h.version}</h4>
          <dl class="research-dl">
            <dt>Source</dt><dd><a href="${hen.source}" target="_blank" rel="noopener">${hen.source}</a></dd>
            <dt>Release</dt><dd>${hen.source?.split('/').pop() || 'N/A'}</dd>
            <dt>Compatibility</dt><dd><span class="status-badge ${hen.compatibility.toLowerCase()}">${hen.compatibility}</span></dd>
          </dl>
        </div>
      `;
    }).join('');
  }

  renderLicense() {
    const el = document.getElementById('research-license');
    if (!this.currentChain) {
      el.innerHTML = '<p class="empty-state">No license data available</p>';
      return;
    }
    const c = this.currentChain;
    
    el.innerHTML = `
      <div class="research-section">
        <h3>Exploit Chain License</h3>
        <div class="license-block">
          <strong>${c.license}</strong>
          <p>Upstream repository: ${c.source_repositories[0] || 'N/A'}</p>
        </div>
      </div>
      
      <div class="research-section">
        <h3>HEN Licenses</h3>
        ${this.renderHenLicenses()}
      </div>
      
      <div class="research-section">
        <h3>Attribution Requirements</h3>
        <ul>
          <li>All third-party components retain their original licenses</li>
          <li>Source code modifications are documented in adapter layers</li>
          <li>SHA-256 checksums verify payload integrity</li>
          <li>See <a href="/database/sources.json" target="_blank" rel="noopener">sources.json</a> for complete provenance</li>
        </ul>
      </div>
      
      <div class="research-section">
        <h3>Redistribution Permissions</h3>
        <table class="license-table">
          <thead><tr><th>Component</th><th>License</th><th>Redistribution</th><th>Modification</th><th>Attribution Required</th></tr></thead>
          <tbody>
            <tr><td>${c.name}</td><td>${c.license}</td><td>Yes</td><td>Yes</td><td>Yes</td></tr>
            ${this.currentCompat?.hen_options?.map(h => {
              const hen = this.engine.henDB?.find(hen => hen.id === h.id);
              if (!hen) return '';
              return `<tr><td>${h.name}</td><td>${hen.license}</td><td>Yes</td><td>Yes</td><td>Yes</td></tr>`;
            }).join('') || ''}
          </tbody>
        </table>
      </div>
    `;
  }

  renderEvidence() {
    const el = document.getElementById('research-evidence');
    if (!this.currentChain) {
      el.innerHTML = '<p class="empty-state">No evidence data available</p>';
      return;
    }
    const c = this.currentChain;
    const sources = this.currentCompat?.sources || [];
    
    el.innerHTML = `
      <div class="research-section">
        <h3>Primary Evidence</h3>
        <p>${c.verification}</p>
      </div>
      
      <div class="research-section">
        <h3>Source Authority Breakdown</h3>
        <table class="source-table">
          <thead><tr><th>Authority</th><th>Count</th><th>Description</th></tr></thead>
          <tbody>
            <tr><td><span class="research-badge tier-1">TIER_1</span></td><td>${sources.filter(s => s.authority === 'TIER_1').length}</td><td>Original developer repository, GitHub source/release/commit, original technical disclosure</td></tr>
            <tr><td><span class="research-badge tier-2">TIER_2</span></td><td>${sources.filter(s => s.authority === 'TIER_2').length}</td><td>Established technical research site</td></tr>
            <tr><td><span class="research-badge tier-3">TIER_3</span></td><td>${sources.filter(s => s.authority === 'TIER_3').length}</td><td>Community reports (identify leads only)</td></tr>
          </tbody>
        </table>
      </div>
      
      <div class="research-section">
        <h3>Source Details</h3>
        ${sources.map(s => `
          <div class="source-detail">
            <h4>${s.project} (${s.type})</h4>
            <dl class="research-dl">
              <dt>Authority</dt><dd><span class="research-badge tier-${s.authority.toLowerCase().replace('_', '-')}">${s.authority}</span></dd>
              <dt>Repository</dt><dd><a href="${s.url}" target="_blank" rel="noopener">${s.repository}</a></dd>
              <dt>Owner</dt><dd>${s.owner}</dd>
              <dt>License</dt><dd>${s.license}</dd>
              <dt>Commit</dt><dd><code>${s.commit || 'N/A'}</code></dd>
              <dt>Release</dt><dd>${s.release || 'N/A'}</dd>
              <dt>Date Checked</dt><dd>${s.date_checked || 'N/A'}</dd>
              <dt>Notes</dt><dd>${s.notes || 'None'}</dd>
            </dl>
          </div>
        `).join('')}
      </div>
    `;
  }

  renderIssues() {
    const el = document.getElementById('research-issues');
    const chain = this.currentChain;
    const compat = this.currentCompat;
    
    const allIssues = [
      ...(chain?.known_issues || []),
      ...(compat?.known_issues || []),
      ...(compat?.warnings || [])
    ].filter(Boolean);
    
    if (!allIssues.length) {
      el.innerHTML = '<p class="empty-state">No known issues documented</p>';
      return;
    }
    
    el.innerHTML = `
      <div class="research-section">
        <h3>Known Issues & Limitations</h3>
        <ul class="issues-list">
          ${allIssues.map(issue => `<li>${issue}</li>`).join('')}
        </ul>
      </div>
      
      <div class="research-section">
        <h3>Contradiction Handling</h3>
        <p>When sources disagree, Robinhood compares primary sources, source code, releases, and testing evidence. Unresolved conflicts retain UNKNOWN/CONFLICTING status.</p>
      </div>
    `;
  }

  renderHistory() {
    const el = document.getElementById('research-history');
    const compat = this.currentCompat;
    
    el.innerHTML = `
      <div class="research-section">
        <h3>Compatibility Record</h3>
        <dl class="research-dl">
          <dt>Console</dt><dd>${compat?.console}</dd>
          <dt>Firmware</dt><dd>${compat?.firmware} (${compat?.firmware_family})</dd>
          <dt>Status</dt><dd><span class="status-badge ${compat?.status?.toLowerCase()}">${compat?.status}</span></dd>
          <dt>Reliability</dt><dd><span class="reliability-badge ${compat?.reliability?.toLowerCase()}">${compat?.reliability}</span></dd>
          <dt>Last Verified</dt><dd>${compat?.sources?.[0]?.date_checked || 'Unknown'}</dd>
          <dt>Source Count</dt><dd>${compat?.sources?.length || 0}</dd>
        </dl>
      </div>
      
      <div class="research-section">
        <h3>Verification Timeline</h3>
        <table class="source-table">
          <thead><tr><th>Date</th><th>Action</th><th>Component</th><th>Authority</th></tr></thead>
          <tbody>
            ${compat?.sources?.map(s => `
              <tr>
                <td>${s.date_checked || 'N/A'}</td>
                <td>Verified</td>
                <td>${s.project}</td>
                <td><span class="research-badge tier-${s.authority.toLowerCase().replace('_', '-')}">${s.authority}</span></td>
              </tr>
            `).join('') || '<tr><td colspan="4">No verification history</td></tr>'}
          </tbody>
        </table>
      </div>
    `;
  }

  renderReports() {
    const el = document.getElementById('research-reports');
    const compat = this.currentCompat;
    const sources = compat?.sources || [];
    
    const tier1 = sources.filter(s => s.authority === 'TIER_1');
    const tier2 = sources.filter(s => s.authority === 'TIER_2');
    const tier3 = sources.filter(s => s.authority === 'TIER_3');
    
    el.innerHTML = `
      <div class="research-section">
        <h3>Tier 1 — Primary Sources</h3>
        ${tier1.length ? tier1.map(s => this.renderSourceCard(s)).join('') : '<p>None</p>'}
      </div>
      
      <div class="research-section">
        <h3>Tier 2 — Established Research</h3>
        ${tier2.length ? tier2.map(s => this.renderSourceCard(s)).join('') : '<p>None</p>'}
      </div>
      
      <div class="research-section">
        <h3>Tier 3 — Community Reports</h3>
        ${tier3.length ? tier3.map(s => this.renderSourceCard(s)).join('') : '<p>None</p>'}
      </div>
      
      <div class="research-section">
        <h3>Claim Ledger Summary</h3>
        <p>Each integrated project maintains a claim ledger tracking: claim, console, firmware, component, source IDs, evidence type, confidence, contradiction, resolution, and final status.</p>
        <p>See <a href="/database/sources.json" target="_blank" rel="noopener">sources.json</a> for structured source records.</p>
      </div>
    `;
  }

  renderSourceCard(s) {
    return `
      <div class="source-card">
        <div class="source-header">
          <strong>${s.project}</strong>
          <span class="research-badge tier-${s.authority.toLowerCase().replace('_', '-')}">${s.authority}</span>
        </div>
        <dl class="research-dl">
          <dt>Type</dt><dd>${s.type}</dd>
          <dt>Repository</dt><dd><a href="${s.url}" target="_blank" rel="noopener">${s.repository}</a></dd>
          <dt>Owner</dt><dd>${s.owner}</dd>
          <dt>License</dt><dd>${s.license}</dd>
          <dt>Commit</dt><dd><code>${s.commit?.slice(0, 12) || 'N/A'}</code></dd>
          <dt>Release</dt><dd>${s.release || 'N/A'}</dd>
          <dt>Date Checked</dt><dd>${s.date_checked || 'N/A'}</dd>
          <dt>Notes</dt><dd>${s.notes || 'None'}</dd>
        </dl>
      </div>
    `;
  }
}
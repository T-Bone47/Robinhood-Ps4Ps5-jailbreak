window.RobinhoodJailbreakFlow = (() => {
  const state = {phase:"IDLE",console:null,firmware:null,route:null,log:[]};
  const snapshot=()=>JSON.parse(JSON.stringify(state));
  function reset(){state.phase="IDLE";state.console=null;state.firmware=null;state.route=null;state.log=[];return snapshot();}
  function begin(consoleName,firmware,route){
    state.console=consoleName||null; state.firmware=firmware||null; state.route=route||null;
    if(!state.console||!state.firmware){state.phase="NEEDS_INPUT";state.log.push("[!] Console and firmware must be confirmed.");return snapshot();}
    if(!route){state.phase="NO_ROUTE";state.log.push("[!] No documented route is available.");return snapshot();}
    if(route.status!=="VERIFIED"){state.phase="REVIEW_REQUIRED";state.log.push("[!] Route is documented but not verified for execution.");return snapshot();}
    state.phase="READY";state.log.push("[+] Compatible verified route selected.");state.log.push("[+] Execution requires the route-specific adapter.");return snapshot();
  }
  function append(message){state.log.push(String(message));return snapshot();}
  return {reset,begin,append,snapshot};
})();

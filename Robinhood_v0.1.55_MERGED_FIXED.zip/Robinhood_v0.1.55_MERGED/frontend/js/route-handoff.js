
window.RobinhoodRouteHandoff = (() => {
  let state={status:"IDLE",route:null,console:null,firmware:null,log:[]};
  const listeners=new Set();
  const snapshot=()=>JSON.parse(JSON.stringify(state));
  const emit=()=>listeners.forEach(fn=>fn(snapshot()));

  function on(fn){if(typeof fn==="function")listeners.add(fn);return()=>listeners.delete(fn);}
  function prepare(consoleName,firmware,selection){
    state={console:consoleName,firmware,route:selection?.route||null,
      status:selection?.route?"READY":"UNSUPPORTED",log:[]};
    if(state.route) state.log.push(`[+] Route prepared: ${state.route.id}`);
    else state.log.push("[!] No compatible route prepared.");
    emit(); return snapshot();
  }
  function trigger(){
    if(state.status!=="READY"){
      state.status="BLOCKED";
      state.log.push("[!] Jailbreak action blocked: route is not ready.");
      emit(); return snapshot();
    }
    state.status="EXECUTION_WAITING";
    state.log.push("[+] Jailbreak request handed to the verified adapter gate.");
    emit(); return snapshot();
  }
  function adapterEvent(event){
    if(!event || event.routeId!==state.route?.id){
      state.status="FAILED"; state.log.push("[!] Adapter event rejected.");
      emit(); return snapshot();
    }
    const map={ENTRY_STARTED:"ENTRY_RUNNING",KERNEL_STARTED:"KERNEL_RUNNING",
      PAYLOAD_STARTED:"PAYLOAD_RUNNING",COMPLETE:"COMPLETE",FAILED:"FAILED"};
    state.status=map[event.type]||state.status;
    state.log.push(event.message||`[+] ${event.type}`);
    emit(); return snapshot();
  }
  return {on,prepare,trigger,adapterEvent,snapshot};
})();


window.RobinhoodNavigation=(()=>{
  const listeners=new Set();
  let current={screen:"HOME",firmware:null,tool:null};
  const snapshot=()=>JSON.parse(JSON.stringify(current));
  const emit=()=>listeners.forEach(fn=>fn(snapshot()));
  function on(fn){if(typeof fn==="function")listeners.add(fn);return()=>listeners.delete(fn);}
  function home(){current={screen:"HOME",firmware:null,tool:null};emit();return snapshot();}
  function firmware(fw){current={screen:"FIRMWARE",firmware:fw,tool:null};emit();return snapshot();}
  function tool(fw,name){current={screen:"TOOL",firmware:fw,tool:name};emit();return snapshot();}
  return {on,home,firmware,tool,snapshot};
})();

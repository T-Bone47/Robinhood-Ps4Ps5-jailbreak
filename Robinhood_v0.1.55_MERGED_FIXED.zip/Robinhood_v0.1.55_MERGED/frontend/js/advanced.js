import { CompatibilityEngine } from '../../core/compatibility/engine.js';
import { ExploitRouter } from '../../core/exploit-router/router.js';
import { PayloadManager } from '../../core/payload/manager.js';
import { formatBytes, formatSha256, show, hide, onClick, createElement } from './ui.js';

export class AdvancedView {
  constructor() {
    this.engine = new CompatibilityEngine();
    this.router = new ExploitRouter();
    this.payloadManager = new PayloadManager();
    this.currentCompat = null;
    this.currentChain = null;
    this.init();
  }

  async init() {
    await this.loadDatabase();
    this.bindEvents();
  }

  async loadDatabase() {
    try {
      await fetch('database/ps4.json').then(r => r.json()).then(d => this.engine.ps4DB = d);
      await fetch('database/ps5.json').then(r => r.json()).then(d => this.engine.ps5DB = d);
      await fetch('database/exploit-chains.json').then(r => r.json()).then(d => this.engine.chainsDB = d);
      await fetch('database/hen.json').then(r => r.json()).then(d => this.engine.henDB = d);
      await fetch('database/payloads.json').then(r => r.json()).then(d => this.engine.payloadsDB = d);
      await fetch('database/sources.json').then(r => r.json()).then(d => this.engine.sourcesDB = d);
      this.engine.loaded = true;
    } catch (err) {
      console.error('[AdvancedView] Failed to load database:', err);
    }
  }

  bindEvents() {
    onClick('btn-adv-refresh-chains', () => this.refreshChainSelection());
    onClick('btn-adv-refresh-hen', () => this.refreshHenSelection());
    onClick('btn-adv-refresh-payloads', () => this.refreshPayloadSelection());
  }

  update(compat) {
    this.currentCompat = compat;
    this.currentChain = this.router.getChainDetails(compat.recommended_chain?.id);
    this.renderAll();
  }

  renderAll() {
    if (!this.currentCompat) return;
    this.renderDetection();
    this.renderChain();
    this.renderHen();
    this.renderPayloads();
    this.renderCache();
    this.renderCompatibility();
  }

  renderDetection() {
    const el = document.getElementById('adv-detection');
    const c = this.currentCompat;
    el.innerHTML = `
      <dt>Console</dt><dd>${c.console}</dd>
      <dt>Firmware</dt><dd>${c.firmware} (${c.firmware_family})</dd>
      <dt>User Agent Match</dt><dd>${c.firmware ? 'Yes' : 'No'}</dd>
      <dt>Overall Status</dt><dd><span class="status-badge ${c.status.toLowerCase()}">${c.status}</span></dd>
      <dt>Reliability Tier</dt><dd><span class="reliability-badge ${c.reliability.toLowerCase()}">${c.reliability}</span></dd>
    `;
  }

  renderChain() {
    const el = document.getElementById('adv-chain');
    if (!this.currentChain) {
      el.innerHTML = '<dt>Chain</dt><dd>None available</dd>';
      return;
    }
    const c = this.currentChain;
    el.innerHTML = `
      <dt>Chain Name</dt><dd>${c.name}</dd>
      <dt>Chain ID</dt><dd>${c.id}</dd>
      <dt>Status</dt><dd><span class="status-badge ${c.status.toLowerCase()}">${c.status}</span></dd>
      <dt>Reliability</dt><dd><span class="reliability-badge ${c.reliability.toLowerCase()}">${c.reliability}</span></dd>
      <dt>Entry Type</dt><dd>${c.entry_type}</dd>
      <dt>WebKit Component</dt><dd>${c.webkit_component || 'N/A'}</dd>
      <dt>Userland Component</dt><dd>${c.userland_component || 'N/A'}</dd>
      <dt>Kernel Component</dt><dd>${c.kernel_component || 'N/A'}</dd>
      <dt>HEN Component</dt><dd>${c.hen_component || 'N/A'}</dd>
      <dt>Loader Component</dt><dd>${c.loader_component || 'N/A'}</dd>
      <dt>Payload Formats</dt><dd>${c.payload_formats.join(', ')}</dd>
      <dt>Supported Firmwares</dt><dd>${c.supported_firmware.join(', ')}</dd>
      <dt>License</dt><dd>${c.license}</dd>
      <button id="btn-adv-refresh-chains" class="btn btn-secondary btn-sm" style="margin-top: var(--spacing-sm);">Refresh Chain List</button>
    `;
    this.renderChainAlternatives();
  }

  renderChainAlternatives() {
    const alternatives = this.currentCompat.alternatives || [];
    if (!alternatives.length) return;
    
    const container = document.getElementById('adv-chain');
    const altHtml = alternatives.map(a => `
      <div class="alternative-chain">
        <strong>${a.name}</strong> (${a.id})
        <span class="status-badge ${a.status.toLowerCase()}">${a.status}</span>
        <span class="reliability-badge ${a.reliability.toLowerCase()}">${a.reliability}</span>
        <button class="btn btn-sm btn-secondary select-chain" data-chain-id="${a.id}" style="margin-left: var(--spacing-sm);">Select</button>
      </div>
    `).join('');
    
    container.innerHTML += `
      <dt>Alternatives</dt>
      <dd>${altHtml}</dd>
    `;
    
    container.querySelectorAll('.select-chain').forEach(btn => {
      btn.addEventListener('click', () => this.selectChain(btn.dataset.chainId));
    });
  }

  selectChain(chainId) {
    const chain = this.engine.chainsDB?.find(c => c.id === chainId);
    if (chain && this.currentCompat) {
      this.currentCompat.recommended_chain = chain;
      this.currentChain = chain;
      this.renderChain();
      this.renderHen();
      this.renderPayloads();
    }
  }

  refreshChainSelection() {
    this.renderChainAlternatives();
  }

  renderHen() {
    const el = document.getElementById('adv-hen');
    if (!this.currentCompat?.hen_options?.length) {
      el.innerHTML = '<dt>HEN</dt><dd>None available</dd>';
      return;
    }
    
    const hens = this.currentCompat.hen_options;
    const currentHenId = this.currentCompat.selectedHen || hens[0]?.id;
    
    el.innerHTML = hens.map(h => `
      <div class="hen-option ${h.id === currentHenId ? 'selected' : ''}" data-hen-id="${h.id}">
        <strong>${h.name} v${h.version}</strong>
        <span class="status-badge ${h.compatibility.toLowerCase()}">${h.compatibility}</span>
        <br>
        <small>Payload formats: ${h.payload_format.join(', ')}</small>
        <small>Required kernel state: ${h.required_kernel_state || 'N/A'}</small>
        <button class="btn btn-sm btn-secondary select-hen" data-hen-id="${h.id}" style="margin-left: var(--spacing-sm);" ${h.id === currentHenId ? 'disabled' : ''}>Select</button>
      </div>
    `).join('');
    
    el.querySelectorAll('.select-hen').forEach(btn => {
      btn.addEventListener('click', () => this.selectHen(btn.dataset.henId));
    });
  }

  selectHen(henId) {
    this.currentCompat.selectedHen = henId;
    this.renderHen();
    this.renderPayloads();
  }

  refreshHenSelection() {
    this.renderHen();
  }

  renderPayloads() {
    const el = document.getElementById('adv-payloads');
    if (!this.currentCompat?.payloads?.length) {
      el.innerHTML = '<p class="empty-state">No payloads available for this firmware</p>';
      return;
    }
    
    const henId = this.currentCompat.selectedHen || this.currentCompat.hen_options[0]?.id;
    const filteredPayloads = this.currentCompat.payloads.filter(p => 
      !henId || p.loader === henId.replace('-', '-').split('-')[0] + '-loader'
    );
    
    if (!filteredPayloads.length) {
      el.innerHTML = '<p class="empty-state">No payloads compatible with selected HEN</p>';
      return;
    }
    
    el.innerHTML = filteredPayloads.map(p => `
      <div class="payload-item ${p.payload_id.includes('goldhen') ? 'verified' : ''}" data-payload-id="${p.payload_id}">
        <div class="payload-header">
          <strong>${p.name}</strong>
          <span class="status-badge ${p.status.toLowerCase()}">${p.status}</span>
        </div>
        <div class="payload-meta">
          <span>Format: ${p.format}</span>
          <span>Size: ${formatBytes(p.size)}</span>
          <span>SHA256: ${formatSha256(p.sha256)}</span>
          <span>Loader: ${p.loader}</span>
          <span>Version: ${p.version}</span>
          <span>License: ${p.license}</span>
        </div>
        <button class="btn btn-sm btn-secondary select-payload" data-payload-id="${p.payload_id}" style="margin-top: var(--spacing-xs);">Select for Execution</button>
      </div>
    `).join('');
    
    el.querySelectorAll('.select-payload').forEach(btn => {
      btn.addEventListener('click', () => this.selectPayload(btn.dataset.payloadId));
    });
  }

  selectPayload(payloadId) {
    this.currentCompat.selectedPayload = payloadId;
    this.renderPayloads();
  }

  refreshPayloadSelection() {
    this.renderPayloads();
  }

  renderCache() {
    const el = document.getElementById('adv-cache');
    const c = this.currentCompat;
    el.innerHTML = `
      <dt>Offline Capable</dt><dd>${c.offline_capable ? '<span class="status-badge verified">Yes</span>' : '<span class="status-badge unsupported">No</span>'}</dd>
      <dt>Local Host</dt><dd>${c.local_host_capable ? '<span class="status-badge verified">Yes</span>' : '<span class="status-badge unsupported">No</span>'}</dd>
      <dt>Service Worker</dt><dd><span class="status-badge verified">Registered</span></dd>
      <dt>Cache Manifest</dt><dd><a href="/cache/manifest.json" target="_blank" rel="noopener">manifest.json</a></dd>
    `;
  }

  renderCompatibility() {
    const el = document.getElementById('adv-compat');
    const c = this.currentCompat;
    el.innerHTML = `
      <dt>Overall Status</dt><dd><span class="status-badge ${c.status.toLowerCase()}">${c.status}</span></dd>
      <dt>Reliability</dt><dd><span class="reliability-badge ${c.reliability.toLowerCase()}">${c.reliability}</span></dd>
      <dt>WebKit Layer</dt><dd><span class="status-badge ${c.webkit?.toLowerCase() || 'unknown'}">${c.webkit || 'N/A'}</span></dd>
      <dt>Kernel Layer</dt><dd><span class="status-badge ${c.kernel?.toLowerCase() || 'unknown'}">${c.kernel || 'N/A'}</span></dd>
      <dt>HEN Layer</dt><dd><span class="status-badge ${c.hen?.toLowerCase() || 'unknown'}">${c.hen || 'N/A'}</span></dd>
      <dt>Loader Layer</dt><dd><span class="status-badge ${c.loader?.toLowerCase() || 'unknown'}">${c.loader || 'N/A'}</span></dd>
      <dt>Payload Layer</dt><dd><span class="status-badge ${c.payloads?.length ? 'verified' : 'unsupported'}">${c.payloads?.length ? 'Available' : 'None'}</span></dd>
      ${c.warnings?.map(w => `<dt>Warning</dt><dd>${w}</dd>`).join('') || ''}
      ${c.known_issues?.map(i => `<dt>Known Issue</dt><dd>${i}</dd>`).join('') || ''}
    `;
  }
}

window.RobinhoodFirmwareSession=(()=>{
  const KEY="robinhood.firmware.session.v1";
  const defaults={firmware:null,profile:null,status:"READY",selectedTool:null};
  function read(){
    try{return {...defaults,...JSON.parse(localStorage.getItem(KEY)||"{}")};}
    catch(_){return {...defaults};}
  }
  function write(patch){
    const next={...read(),...patch};
    localStorage.setItem(KEY,JSON.stringify(next));
    return next;
  }
  function clear(){localStorage.removeItem(KEY);return {...defaults};}
  return {read,write,clear};
})();

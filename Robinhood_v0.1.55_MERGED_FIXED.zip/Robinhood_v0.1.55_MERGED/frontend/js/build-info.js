
window.RobinhoodBuildInfo=(()=>{
  const info={app:"Robinhood",version:"0.1.51",channel:"release-candidate"};
  function get(){return {...info};}
  return {get};
})();

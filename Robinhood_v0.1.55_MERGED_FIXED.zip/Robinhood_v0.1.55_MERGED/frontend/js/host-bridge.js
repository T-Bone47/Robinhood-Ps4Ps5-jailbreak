
window.RobinhoodHostBridge = (() => {
  const listeners = new Set();
  let state = {status:"OFFLINE_READY",routeId:null,log:[]};

  function snapshot(){ return JSON.parse(JSON.stringify(state)); }
  function emit(){ const s=snapshot(); listeners.forEach(fn=>fn(s)); }
  function on(fn){ if(typeof fn==="function") listeners.add(fn); return ()=>listeners.delete(fn); }

  function connect(routeId){
    state={status:"HOST_READY",routeId:routeId||null,log:["[+] Local Robinhood host ready."]};
    emit();
    return snapshot();
  }

  function selectRoute(routeId){
    if(!routeId){state.status="FAILED";state.log.push("[!] Route ID required.");}
    else {state.status="ROUTE_SELECTED";state.routeId=routeId;state.log.push(`[+] Route selected: ${routeId}`);}
    emit(); return snapshot();
  }

  function adapterEvent(event){
    if(!event || event.routeId!==state.routeId){
      state.status="FAILED";state.log.push("[!] Adapter event rejected: route mismatch.");
      emit(); return snapshot();
    }
    const map={ENTRY_STARTED:"ENTRY_RUNNING",KERNEL_STARTED:"KERNEL_RUNNING",PAYLOAD_STARTED:"PAYLOAD_RUNNING",COMPLETE:"COMPLETE",FAILED:"FAILED"};
    state.status=map[event.type]||state.status;
    state.log.push(event.message||`[+] ${event.type}`);
    emit(); return snapshot();
  }

  return {on,connect,selectRoute,adapterEvent,snapshot};
})();

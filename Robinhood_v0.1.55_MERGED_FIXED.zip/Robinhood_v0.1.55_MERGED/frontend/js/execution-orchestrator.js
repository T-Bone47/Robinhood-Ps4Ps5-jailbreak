window.RobinhoodExecutionOrchestrator = (() => {
  const state = {
    phase: "IDLE",
    route: null,
    adapter: null,
    log: [],
    error: null
  };

  const snapshot = () => JSON.parse(JSON.stringify(state));
  const add = (phase, message) => {
    state.phase = phase;
    if (message) state.log.push(message);
    return snapshot();
  };

  function prepare(route, adapter) {
    state.route = route || null;
    state.adapter = adapter || null;
    state.error = null;
    state.log = [];
    if (!state.route) return add("BLOCKED", "[!] No route selected.");
    if (state.route.status !== "VERIFIED") return add("BLOCKED", "[!] Route is research-only until promoted to VERIFIED.");
    if (!state.adapter || state.adapter.execution_enabled !== true) {
      return add("BLOCKED", "[!] No production execution adapter is installed.");
    }
    return add("ENVIRONMENT", "[+] Verified execution adapter accepted.");
  }

  function reset() {
    state.phase = "IDLE";
    state.route = null;
    state.adapter = null;
    state.log = [];
    state.error = null;
    return snapshot();
  }

  return { prepare, reset, snapshot };
})();


window.RobinhoodFirmwareRouteUI=(()=>{
  function render(root,detected,selection){
    if(!root)return;
    const fw=detected?.firmware||"Unknown";
    const route=selection?.route;
    root.innerHTML=`
      <div class="rh-route-card">
        <div class="eyebrow">Firmware routing</div>
        <h2>${detected?.console||"Console"} · ${fw}</h2>
        <div class="rh-route-status">${selection?.status||"UNKNOWN"}</div>
        <p>${route ? `Route: ${route.id}` : (selection?.reason||"No route selected.")}</p>
        <small>Execution requires a verified route adapter.</small>
      </div>`;
  }
  return {render};
})();

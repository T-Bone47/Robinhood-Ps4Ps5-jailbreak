
window.RobinhoodHostStatus=(()=>{
  const allowed=["READY","ROUTE_SELECTED","EXECUTION_WAITING",
                 "ENTRY_RUNNING","KERNEL_RUNNING","PAYLOAD_RUNNING",
                 "COMPLETE","FAILED","LOCKED"];
  let state={status:"READY",message:"Host ready.",history:[]};
  const listeners=new Set();
  function snapshot(){return JSON.parse(JSON.stringify(state));}
  function emit(){listeners.forEach(fn=>fn(snapshot()));}
  function set(status,message){
    if(!allowed.includes(status)) return snapshot();
    state.status=status;
    state.message=message||status;
    state.history.push({status,message:state.message});
    emit();
    return snapshot();
  }
  function on(fn){if(typeof fn==="function")listeners.add(fn);return()=>listeners.delete(fn);}
  return {set,on,snapshot};
})();

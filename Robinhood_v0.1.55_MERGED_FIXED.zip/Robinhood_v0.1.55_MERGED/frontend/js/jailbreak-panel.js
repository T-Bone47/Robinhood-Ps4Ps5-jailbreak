window.RobinhoodJailbreakPanel = (() => {
  function mount(root,flow){
    if(!root)return;
    root.innerHTML=`<div class="rh-jb-panel">
      <div class="rh-jb-header"><div><div class="eyebrow">Exploit route</div><h2 id="rh-jb-title">Ready when a verified route is selected</h2></div><div id="rh-jb-badge" class="rh-jb-badge">IDLE</div></div>
      <div class="rh-jb-meta"><span id="rh-jb-console">Console: —</span><span id="rh-jb-fw">Firmware: —</span></div>
      <button id="rh-jb-trigger" class="rh-jb-trigger" type="button">JAILBREAK &amp; LOAD GOLDHEN</button>
      <div class="rh-jb-warning" id="rh-jb-warning">Execution is enabled only for an installed, verified route adapter.</div>
      <pre class="rh-jb-log" id="rh-jb-log">Waiting for route selection…</pre>
    </div>`;
    const badge=root.querySelector("#rh-jb-badge"),title=root.querySelector("#rh-jb-title");
    const consoleEl=root.querySelector("#rh-jb-console"),fwEl=root.querySelector("#rh-jb-fw");
    const log=root.querySelector("#rh-jb-log"),trigger=root.querySelector("#rh-jb-trigger");
    function render(s){
      badge.textContent=s.phase; consoleEl.textContent=`Console: ${s.console||"—"}`; fwEl.textContent=`Firmware: ${s.firmware||"—"}`;
      log.textContent=s.log.length?s.log.join("\n"):"Waiting for route selection…";
      trigger.disabled=s.phase!=="READY";
      title.textContent=s.phase==="REVIEW_REQUIRED"?"Route requires validation":s.phase==="NO_ROUTE"?"No documented route":s.phase==="READY"?"Verified route ready":"Ready when a verified route is selected";
    }
    trigger.addEventListener("click",()=>render(flow.append("[!] No execution adapter is installed in this release.")));
    render(flow.snapshot());
  }
  return {mount};
})();

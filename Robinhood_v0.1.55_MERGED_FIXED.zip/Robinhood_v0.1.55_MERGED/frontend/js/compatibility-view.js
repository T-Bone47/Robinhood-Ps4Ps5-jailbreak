window.RobinhoodCompatibilityView = (() => {
  function badge(route) {
    const status = route?.status || "UNKNOWN";
    const reliability = route?.reliability || "UNKNOWN";
    return {
      status,
      reliability,
      evidence: route?.evidence_grade || "UNKNOWN",
      className: status.toLowerCase().replace(/[^a-z0-9]+/g,"-")
    };
  }

  function explain(route) {
    if (!route) {
      return {
        title:"No compatible route found",
        body:"Robinhood could not establish a documented route for this firmware.",
        action:"RESEARCH"
      };
    }

    if (route.status === "REPORTED") {
      return {
        title:"Documented route — validation required",
        body:"This route is documented in the research database but is not presented as a guaranteed or stable result.",
        action:"REVIEW_EVIDENCE"
      };
    }

    if (route.status === "VERIFIED") {
      return {
        title:"Verified compatibility route",
        body:"Primary evidence and validation metadata are present.",
        action:"VALIDATION_REVIEW"
      };
    }

    return {
      title:"Research-only route",
      body:"The available evidence is insufficient to present this as verified compatibility.",
      action:"RESEARCH"
    };
  }

  return {badge, explain};
})();

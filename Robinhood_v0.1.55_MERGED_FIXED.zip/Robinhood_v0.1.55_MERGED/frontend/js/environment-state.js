window.RobinhoodEnvironmentState = (() => {
  const state = {
    console: null,
    firmware: null,
    source: "NONE",
    confidence: "UNKNOWN",
    message: "Console and firmware not confirmed."
  };

  function setManual(consoleName, firmware) {
    state.console = consoleName || null;
    state.firmware = firmware || null;
    state.source = "USER_INPUT";
    state.confidence = state.console && state.firmware ? "USER_CONFIRMED" : "UNKNOWN";
    state.message = state.confidence === "USER_CONFIRMED"
      ? "Using the console and firmware you entered."
      : "Enter both console and firmware.";
    return {...state};
  }

  function reset() {
    state.console = null;
    state.firmware = null;
    state.source = "NONE";
    state.confidence = "UNKNOWN";
    state.message = "Console and firmware not confirmed.";
    return {...state};
  }

  return {state, setManual, reset};
})();

# Robinhood Final State Policy

Robinhood is an evidence-driven self-hosted research/compatibility interface.

Public route states:

- VERIFIED — primary evidence and validation metadata support the route.
- REPORTED — primary/community documentation supports the claim, but it is not
  presented as a guarantee.
- RESEARCH_ONLY — evidence is incomplete or conflicting.
- BLOCKED — the route is intentionally prevented.
- DEPRECATED — historical route retained for auditability.

No UI string may turn a REPORTED or RESEARCH_ONLY route into a guarantee.

Physical-console validation is separate from automated software tests.

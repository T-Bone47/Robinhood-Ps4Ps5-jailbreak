window.ROBINHOOD_COMPATIBILITY = [
  {
    "console": "PS4",
    "firmware": "7.00",
    "min_firmware": 7.0,
    "max_firmware": 7.0,
    "status": "PARTIAL",
    "reliability": "UNKNOWN",
    "chain": "ps4-pppwn",
    "hen": null,
    "loader": null,
    "payloads": [],
    "offline": false,
    "summary": "Kernel RCE PoC is documented upstream; complete Robinhood HEN route is not yet integrated.",
    "source_ids": [
      "github-pppwn"
    ],
    "last_verified": "2026-08-25"
  },
  {
    "console": "PS4",
    "firmware": "9.00",
    "min_firmware": 9.0,
    "max_firmware": 9.0,
    "status": "PARTIAL",
    "reliability": "UNKNOWN",
    "chain": "ps4-pppwn",
    "hen": "goldhen",
    "loader": null,
    "payloads": [],
    "offline": false,
    "summary": "PPPwn and GoldHEN are independently documented for this firmware; Robinhood has not yet integrated a complete execution route.",
    "source_ids": [
      "github-pppwn",
      "github-goldhen-releases"
    ],
    "last_verified": "2026-08-25"
  },
  {
    "console": "PS4",
    "firmware": "11.00",
    "min_firmware": 11.0,
    "max_firmware": 11.0,
    "status": "PARTIAL",
    "reliability": "UNKNOWN",
    "chain": "ps4-pppwn",
    "hen": "goldhen",
    "loader": null,
    "payloads": [],
    "offline": false,
    "summary": "PPPwn and GoldHEN are independently documented for this firmware; Robinhood has not yet integrated a complete execution route.",
    "source_ids": [
      "github-pppwn",
      "github-goldhen-releases"
    ],
    "last_verified": "2026-08-25"
  },
  {
    "console": "PS4",
    "firmware": "12.52",
    "min_firmware": 12.52,
    "max_firmware": 12.52,
    "status": "UNKNOWN",
    "reliability": "UNKNOWN",
    "chain": null,
    "hen": null,
    "loader": null,
    "payloads": [],
    "offline": false,
    "summary": "Project target only. No verified Robinhood route recorded yet.",
    "source_ids": [],
    "last_verified": "2026-08-25"
  },
  {
    "console": "PS5",
    "firmware": "9.00",
    "min_firmware": 9.0,
    "max_firmware": 12.0,
    "status": "VERIFIED",
    "reliability": "EXPERIMENTAL",
    "chain": "ps5-webkit-autoloader",
    "hen": null,
    "loader": "ps5-webkit-autoloader",
    "payloads": [],
    "offline": true,
    "summary": "Upstream autoloader documentation explicitly states 9.00-12.00 support; reliability can vary by firmware.",
    "source_ids": [
      "github-ps5-webkit-autoloader"
    ],
    "last_verified": "2026-08-25"
  },
  {
    "console": "PS5",
    "firmware": "7.00",
    "min_firmware": 7.0,
    "max_firmware": 8.6,
    "status": "EXPERIMENTAL",
    "reliability": "UNKNOWN",
    "chain": "ps5-webkit-autoloader-7-8x",
    "hen": null,
    "loader": "ps5-webkit-autoloader",
    "payloads": [],
    "offline": true,
    "summary": "Pre-release support announced by the project maintainer; keep separate from stable 9.00-12.00 support.",
    "source_ids": [
      "github-ps5-autoloader-discussion"
    ],
    "last_verified": "2026-08-25"
  }
];

(function () {
  const db = window.ROBINHOOD_COMPATIBILITY || [];
  const consoleEl = document.getElementById("console");
  const firmwareEl = document.getElementById("firmware");
  const check = document.getElementById("check");
  const headline = document.getElementById("headline");
  const status = document.getElementById("status");
  const resultCard = document.getElementById("result-card");
  const result = document.getElementById("result");
  const detailsCard = document.getElementById("details-card");
  const details = document.getElementById("details");

  function parseFirmware(value) {
    const raw = String(value || "").trim();
    const match = raw.match(/^(\d+)(?:\.(\d{1,2}))?$/);
    if (!match) return null;
    const major = Number(match[1]);
    const minor = Number((match[2] || "0").padEnd(2, "0"));
    return { raw, numeric: major + minor / 100 };
  }

  function resolve(consoleName, firmwareInput) {
    const firmware = parseFirmware(firmwareInput);
    if (!firmware) return { status: "UNKNOWN", reason: "INVALID_FIRMWARE" };

    const matches = db.filter(item =>
      item.console === consoleName &&
      firmware.numeric >= item.min_firmware &&
      firmware.numeric <= item.max_firmware
    );

    return matches[0] || {
      status: "UNKNOWN",
      reason: "NO_DATABASE_ENTRY",
      console: consoleName,
      firmware: firmware.raw
    };
  }

  function show(item, firmwareInput) {
    resultCard.classList.remove("hidden");
    headline.textContent = item.status || "UNKNOWN";

    if (item.status === "VERIFIED") {
      status.textContent = "A verified route exists in the current Robinhood database.";
    } else {
      status.textContent = item.summary ||
        "No verified execution route is currently recorded.";
    }

    result.innerHTML = [
      ["Console", item.console || consoleEl.value],
      ["Firmware", firmwareInput],
      ["Chain", item.chain || "UNRESOLVED"],
      ["HEN", item.hen || "UNRESOLVED"],
      ["Loader", item.loader || "UNRESOLVED"],
      ["Reliability", item.reliability || "UNKNOWN"]
    ].map(([k, v]) =>
      "<div class='result-row'><strong>" + k + ":</strong> " +
      String(v) + "</div>"
    ).join("");

    details.textContent = JSON.stringify(item, null, 2);
  }

  check.addEventListener("click", function () {
    show(resolve(consoleEl.value, firmwareEl.value), firmwareEl.value);
  });

  document.querySelectorAll("[data-mode]").forEach(button => {
    button.addEventListener("click", () => {
      detailsCard.classList.remove("hidden");
      details.textContent = button.dataset.mode === "research"
        ? "Research mode will expose source provenance, commit/release, evidence, license, contradictions and verification date."
        : "Advanced mode will expose chain, HEN, loader, payload, cache and diagnostic metadata.";
    });
  });
})();

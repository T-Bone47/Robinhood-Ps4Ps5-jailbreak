#!/usr/bin/env node
/**
 * Robinhood Release Bundler
 * Validates dist/, generates SHA-256 cache manifest, verifies GitHub Pages readiness
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const glob = require('glob');
const { validateDatabase } = require('./validate');

const ROOT_DIR = path.join(__dirname, '..');
const DIST_DIR = path.join(ROOT_DIR, 'dist');
const REQUIRED_FILES = [
  'index.html',
  'version.json',
  'frontend/index.html',
  'frontend/js/app.js',
  'frontend/js/service-worker.js',
  'frontend/js/ui.js',
  'frontend/js/diagnostics.js',
  'frontend/js/navigation.js',
  'frontend/js/retry.js',
  'frontend/js/advanced.js',
  'frontend/js/research.js',
  'frontend/css/base.css',
  'frontend/css/console.css',
  'frontend/css/advanced.css',
  'frontend/css/research.css',
  'frontend/css/diagnostics.css',
  'database/ps4.json',
  'database/ps5.json',
  'database/exploit-chains.json',
  'database/hen.json',
  'database/payloads.json',
  'database/sources.json',
];

function sha256File(filePath) {
  const content = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(content).digest('hex');
}

function sha256Buffer(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

async function validateDist() {
  console.log('🔍 Validating dist/ directory...');
  
  if (!fs.existsSync(DIST_DIR)) {
    throw new Error('dist/ directory not found. Run npm run build first.');
  }

  const errors = [];
  const warnings = [];

  // Check required files exist
  for (const file of REQUIRED_FILES) {
    const fullPath = path.join(DIST_DIR, file);
    if (!fs.existsSync(fullPath)) {
      errors.push(`Missing required file: ${file}`);
    }
  }

  // Validate index.html structure
  const indexPath = path.join(DIST_DIR, 'index.html');
  if (fs.existsSync(indexPath)) {
    const indexContent = fs.readFileSync(indexPath, 'utf8');
    
    const requiredElements = [
      'id="app"',
      'id="view-normal"',
      'id="view-advanced"',
      'id="view-research"',
      'id="btn-start"',
      'id="diagnostics-panel"',
      'app.js',
    ];
    
    for (const el of requiredElements) {
      if (!indexContent.includes(el)) {
        warnings.push(`index.html may be missing: ${el}`);
      }
    }
  }

  // Validate service worker
  const swPath = path.join(DIST_DIR, 'frontend/js/service-worker.js');
  if (fs.existsSync(swPath)) {
    const swContent = fs.readFileSync(swPath, 'utf8');
    if (!swContent.includes('CACHE_NAME') || !swContent.includes('install') || !swContent.includes('fetch')) {
      warnings.push('Service worker may be incomplete');
    }
  }

  // Validate database files
  const dbFiles = ['ps4.json', 'ps5.json', 'exploit-chains.json', 'hen.json', 'payloads.json', 'sources.json'];
  for (const dbFile of dbFiles) {
    const dbPath = path.join(DIST_DIR, 'database', dbFile);
    if (fs.existsSync(dbPath)) {
      try {
        JSON.parse(fs.readFileSync(dbPath, 'utf8'));
      } catch (err) {
        errors.push(`Invalid JSON in ${dbFile}: ${err.message}`);
      }
    }
  }

  // Validate version.json
  const versionPath = path.join(DIST_DIR, 'version.json');
  if (fs.existsSync(versionPath)) {
    try {
      const version = JSON.parse(fs.readFileSync(versionPath, 'utf8'));
      if (!version.version || !version.build_date) {
        warnings.push('version.json missing version or build_date');
      }
    } catch (err) {
      errors.push(`Invalid version.json: ${err.message}`);
    }
  }

  if (errors.length > 0) {
    throw new Error(`Validation failed:\n${errors.map(e => `  - ${e}`).join('\n')}`);
  }

  if (warnings.length > 0) {
    console.log('⚠️  Warnings:');
    warnings.forEach(w => console.log(`  - ${w}`));
  }

  console.log('✅ dist/ validation passed');
  return true;
}

async function generateManifest() {
  console.log('📋 Generating cache manifest...');
  
  const cacheDir = path.join(DIST_DIR, 'cache');
  if (!fs.existsSync(cacheDir)) {
    fs.mkdirSync(cacheDir, { recursive: true });
  }

  const manifest = {
    files: {},
    version: '1.0.0',
    generated: new Date().toISOString(),
  };

  const allFiles = glob.sync('**/*', { cwd: DIST_DIR, nodir: true });
  
  for (const file of allFiles) {
    if (file.startsWith('cache/')) continue;
    
    const fullPath = path.join(DIST_DIR, file);
    const content = fs.readFileSync(fullPath);
    const hash = sha256Buffer(content);
    const stats = fs.statSync(fullPath);
    
    // Normalize path for web
    const webPath = file.replace(/\\/g, '/');
    
    manifest.files[webPath] = {
      size: stats.size,
      sha256: hash,
      version: manifest.version,
    };
  }

  const manifestPath = path.join(cacheDir, 'manifest.json');
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
  
  console.log(`✅ Manifest generated: ${Object.keys(manifest.files).length} files`);
  console.log(`📄 Manifest: ${manifestPath}`);
  
  return manifest;
}

async function verifyManifest() {
  console.log('🔐 Verifying manifest integrity...');
  
  const manifestPath = path.join(DIST_DIR, 'cache/manifest.json');
  if (!fs.existsSync(manifestPath)) {
    throw new Error('Manifest not found');
  }

  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  let verified = 0;
  let failed = 0;

  for (const [file, meta] of Object.entries(manifest.files)) {
    // Skip the manifest itself since it changes after generation
    if (file === 'cache/manifest.json') continue;
    
    const fullPath = path.join(DIST_DIR, file);
    if (!fs.existsSync(fullPath)) {
      console.error(`  ❌ Missing: ${file}`);
      failed++;
      continue;
    }

    const content = fs.readFileSync(fullPath);
    const hash = sha256Buffer(content);
    
    if (hash !== meta.sha256) {
      console.error(`  ❌ Checksum mismatch: ${file}`);
      failed++;
    } else {
      verified++;
    }
  }

  if (failed > 0) {
    throw new Error(`${failed} files failed verification`);
  }

  console.log(`✅ All ${verified} files verified`);
  return true;
}

async function checkGitHubPagesReadiness() {
  console.log('🌐 Checking GitHub Pages readiness...');
  
  const checks = {
    hasIndex: fs.existsSync(path.join(DIST_DIR, 'index.html')),
    has404: fs.existsSync(path.join(DIST_DIR, '404.html')), // Optional but recommended
    hasNoServerCode: true, // Static only
    hasValidManifest: fs.existsSync(path.join(DIST_DIR, 'cache/manifest.json')),
    hasVersion: fs.existsSync(path.join(DIST_DIR, 'version.json')),
    databasesPresent: fs.existsSync(path.join(DIST_DIR, 'database/ps4.json')) && 
                      fs.existsSync(path.join(DIST_DIR, 'database/ps5.json')),
    serviceWorkerReady: fs.existsSync(path.join(DIST_DIR, 'frontend/js/service-worker.js')),
    noNodeModules: !fs.existsSync(path.join(DIST_DIR, 'node_modules')),
    noSourceMaps: !glob.sync('**/*.map', { cwd: DIST_DIR }).length > 0, // Should not have .map files
  };

  const passed = Object.values(checks).filter(Boolean).length;
  const total = Object.keys(checks).length;

  console.log(`GitHub Pages readiness: ${passed}/${total} checks passed`);
  
  for (const [check, result] of Object.entries(checks)) {
    const status = result ? '✅' : '❌';
    console.log(`  ${status} ${check}`);
  }

  if (passed !== total) {
    console.warn('⚠️  Some readiness checks failed - review before deploying');
  } else {
    console.log('✅ Ready for GitHub Pages deployment');
  }

  return checks;
}

async function main() {
  console.log('📦 Robinhood Release Bundler');
  console.log('==============================\n');

  try {
    await validateDist();
    await generateManifest();
    await verifyManifest();
    await checkGitHubPagesReadiness();

    console.log('\n✅ Release bundle ready!');
    console.log(`📦 Output: ${DIST_DIR}`);
    console.log('\nTo deploy to GitHub Pages:');
    console.log('  1. Push dist/ contents to gh-pages branch');
    console.log('  2. Or configure GitHub Pages to serve from dist/ folder');
    console.log('  3. Ensure HTTPS is enabled (required for Service Worker)');
    
    return { success: true, distDir: DIST_DIR };
  } catch (err) {
    console.error('\n❌ Release bundling failed:', err.message);
    process.exit(1);
  }
}

main().catch(err => {
  console.error('Bundler error:', err);
  process.exit(1);
});
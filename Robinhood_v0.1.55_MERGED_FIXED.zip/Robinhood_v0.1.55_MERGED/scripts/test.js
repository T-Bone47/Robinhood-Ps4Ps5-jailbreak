const { CompatibilityEngine } = require('../core/compatibility/engine');
const ExploitRouter = require('../core/exploit-router/router');
const { generateCompatibilityMD, generateSourcesMD, generateLicensingMD } = require('./generate-docs');
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'database');

const PS4_TEST_FIRMWARES = [
  '9.00', '9.60', '10.00', '10.01', '10.50', '10.70', '10.71',
  '11.00', '11.02', '11.50', '11.52',
  '12.00', '12.02', '12.50', '12.52'
];

const PS5_TEST_FIRMWARES = [
  '4.03', '4.50', '4.51', '5.00', '6.00', '7.00', '8.00'
];

const UNSUPPORTED_FIRMWARES = [
  { console: 'PS4', firmware: '8.00' },
  { console: 'PS4', firmware: '8.50' },
  { console: 'PS5', firmware: '3.00' },
  { console: 'PS5', firmware: '9.00' }
];

function runTests() {
  const engine = new CompatibilityEngine(DB_PATH);
  const router = new ExploitRouter(engine);
  let passed = 0;
  let failed = 0;
  
  function assert(condition, message) {
    if (condition) {
      console.log(`  ✅ ${message}`);
      passed++;
    } else {
      console.error(`  ❌ ${message}`);
      failed++;
    }
  }
  
  console.log('\n🧪 Testing PS4 firmware compatibility...');
  for (const fw of PS4_TEST_FIRMWARES) {
    const compat = engine.checkCompatibility('PS4', fw);
    assert(compat.console === 'PS4', `PS4 ${fw}: console matches`);
    assert(compat.firmware === fw, `PS4 ${fw}: firmware matches`);
    assert(typeof compat.compatible === 'boolean', `PS4 ${fw}: compatible is boolean`);
    assert(['VERIFIED', 'PARTIAL', 'EXPERIMENTAL', 'REPORTED', 'UNSUPPORTED', 'UNKNOWN'].includes(compat.status), `PS4 ${fw}: valid status`);
    assert(['EXCELLENT', 'GOOD', 'MODERATE', 'POOR', 'EXPERIMENTAL', 'UNKNOWN'].includes(compat.reliability), `PS4 ${fw}: valid reliability`);
    
    if (compat.compatible) {
      assert(compat.recommended_chain !== null, `PS4 ${fw}: has recommended chain`);
      assert(compat.recommended_chain?.id, `PS4 ${fw}: chain has id`);
    }
  }
  
  console.log('\n🧪 Testing PS5 firmware compatibility...');
  for (const fw of PS5_TEST_FIRMWARES) {
    const compat = engine.checkCompatibility('PS5', fw);
    assert(compat.console === 'PS5', `PS5 ${fw}: console matches`);
    assert(compat.firmware === fw, `PS5 ${fw}: firmware matches`);
    assert(typeof compat.compatible === 'boolean', `PS5 ${fw}: compatible is boolean`);
    assert(['VERIFIED', 'PARTIAL', 'EXPERIMENTAL', 'REPORTED', 'UNSUPPORTED', 'UNKNOWN'].includes(compat.status), `PS5 ${fw}: valid status`);
  }
  
  console.log('\n🧪 Testing unsupported firmwares...');
  for (const { console, firmware } of UNSUPPORTED_FIRMWARES) {
    const compat = engine.checkCompatibility(console, firmware);
    assert(!compat.compatible, `${console} ${firmware}: correctly incompatible`);
    assert(compat.status === 'UNKNOWN' || compat.status === 'UNSUPPORTED', `${console} ${firmware}: correct status`);
  }
  
  console.log('\n🧪 Testing exploit router...');
  for (const fw of ['9.00', '10.00', '11.00', '12.52']) {
    const result = router.route('PS4', fw);
    if (fw !== '12.52') {
      assert(result.success, `PS4 ${fw}: router success`);
      assert(result.chain !== null, `PS4 ${fw}: has chain`);
      assert(result.chain.status === 'VERIFIED', `PS4 ${fw}: VERIFIED chain selected`);
    } else {
      assert(!result.success || result.chain.status === 'EXPERIMENTAL', `PS4 ${fw}: EXPERIMENTAL chain`);
    }
  }
  
  console.log('\n🧪 Testing router priority (VERIFIED > EXPERIMENTAL)...');
  const route10 = router.route('PS4', '10.00');
  assert(route10.chain.status === 'VERIFIED', 'PS4 10.00: VERIFIED preferred over EXPERIMENTAL');
  
  console.log('\n🧪 Testing console detection...');
  assert(engine.detectConsole('Mozilla/5.0 (PlayStation 4)') === 'PS4', 'PS4 UA detected');
  assert(engine.detectConsole('Mozilla/5.0 (PlayStation 5)') === 'PS5', 'PS5 UA detected');
  assert(engine.detectConsole('Mozilla/5.0 (Windows)') === 'UNKNOWN', 'Unknown UA returns UNKNOWN');
  
  console.log('\n🧪 Testing firmware detection...');
  assert(engine.detectFirmware('Mozilla/5.0 (PlayStation 4 9.00)') === '9.00', 'FW 9.00 detected');
  assert(engine.detectFirmware('Mozilla/5.0 (PlayStation 5 4.50)') === '4.50', 'FW 4.50 detected');
  assert(engine.detectFirmware('Mozilla/5.0 (No firmware)') === null, 'No FW returns null');
  
  console.log('\n🧪 Testing HEN options...');
  const hen900 = engine.getHENOptions('PS4', '9.00');
  assert(hen900.length > 0, 'PS4 9.00 has HEN options');
  assert(hen900.some(h => h.id === 'goldhen-2.4'), 'PS4 9.00 has GoldHEN');
  
  console.log('\n🧪 Testing payload retrieval...');
  const payloads900 = engine.getPayloads('PS4', '9.00');
  // Payloads are now UNVERIFIED (no verified SHA256) so getPayloads filters them out
  // This is expected behavior - only VERIFIED payloads are returned
  assert(payloads900.length === 0, 'PS4 9.00 has 0 VERIFIED payloads (UNVERIFIED payloads filtered)');
  
  // Test that UNVERIFIED payloads exist in the database
  const allPayloads = engine.payloadsDB.filter(p => p.console === 'PS4' && p.firmware_range.includes('9.00'));
  assert(allPayloads.length > 0, 'PS4 9.00 has UNVERIFIED payloads in database');
  assert(allPayloads.some(p => p.payload_id === 'goldhen-bin-2.4'), 'PS4 9.00 has GoldHEN BIN in database (UNVERIFIED)');
  
  console.log('\n🧪 Testing source retrieval...');
  const sources = engine.getSources(['src-psfree', 'src-goldhen']);
  assert(sources.length === 2, 'Sources retrieved');
  assert(sources[0].authority === 'TIER_1', 'Source authority TIER_1');
  
  console.log(`\n📊 Results: ${passed} passed, ${failed} failed`);
  
  if (failed > 0) {
    process.exit(1);
  }
  
  return { passed, failed };
}

function testDocGenerator() {
  console.log('\n🧪 Testing documentation generator...');
  let passed = 0;
  let failed = 0;
  
  function assert(condition, message) {
    if (condition) {
      console.log(`  ✅ ${message}`);
      passed++;
    } else {
      console.error(`  ❌ ${message}`);
      failed++;
    }
  }
  
  const ps4 = JSON.parse(fs.readFileSync(path.join(DB_PATH, 'ps4.json'), 'utf8'));
  const ps5 = JSON.parse(fs.readFileSync(path.join(DB_PATH, 'ps5.json'), 'utf8'));
  const chains = JSON.parse(fs.readFileSync(path.join(DB_PATH, 'exploit-chains.json'), 'utf8'));
  const hens = JSON.parse(fs.readFileSync(path.join(DB_PATH, 'hen.json'), 'utf8'));
  const payloads = JSON.parse(fs.readFileSync(path.join(DB_PATH, 'payloads.json'), 'utf8'));
  const sources = JSON.parse(fs.readFileSync(path.join(DB_PATH, 'sources.json'), 'utf8'));
  
  // Test COMPATIBILITY.md generation
  const compatMD = generateCompatibilityMD(ps4, ps5, chains, hens);
  assert(compatMD.includes('# Compatibility Matrix'), 'COMPATIBILITY.md has title');
  assert(compatMD.includes('## PS4 Firmware Compatibility'), 'COMPATIBILITY.md has PS4 section');
  assert(compatMD.includes('## PS5 Firmware Compatibility'), 'COMPATIBILITY.md has PS5 section');
  assert(compatMD.includes('| Firmware |'), 'COMPATIBILITY.md has table');
  assert(compatMD.includes('psfree-ps4-900') || compatMD.includes('psfree-ps5'), 'COMPATIBILITY.md references chains');
  
  // Test SOURCES.md generation
  const sourcesMD = generateSourcesMD([]);
  assert(sourcesMD.includes('# Source Provenance'), 'SOURCES.md has title');
  assert(sourcesMD.includes('Tier 1'), 'SOURCES.md has Tier 1');
  assert(sourcesMD.includes('Tier 2'), 'SOURCES.md has Tier 2');
  assert(sourcesMD.includes('Tier 3'), 'SOURCES.md has Tier 3');
  
  // Test LICENSING.md generation
  const licensingMD = generateLicensingMD([], [], [], []);
  assert(licensingMD.includes('# Licensing & Attribution'), 'LICENSING.md has title');
  assert(licensingMD.includes('## Exploit Chain Licenses'), 'LICENSING.md has chain licenses');
  assert(licensingMD.includes('## HEN Licenses'), 'LICENSING.md has HEN licenses');
  assert(licensingMD.includes('## Attribution Requirements'), 'LICENSING.md has attribution');
  
  console.log(`\n📊 Doc Generator: ${passed} passed, ${failed} failed`);
  return { passed, failed };
}

function testViewSwitching() {
  console.log('\n🧪 Testing view switching logic...');
  let passed = 0;
  let failed = 0;
  
  function assert(condition, message) {
    if (condition) {
      console.log(`  ✅ ${message}`);
      passed++;
    } else {
      console.error(`  ❌ ${message}`);
      failed++;
    }
  }
  
  // Test tab data attributes exist
  const tabs = ['normal', 'advanced', 'research'];
  tabs.forEach(mode => {
    assert(typeof mode === 'string' && tabs.includes(mode), `Mode "${mode}" is valid`);
  });
  
  // Test view IDs match tab data-mode
  const views = ['view-normal', 'view-advanced', 'view-research'];
  views.forEach((view, i) => {
    assert(view === `view-${tabs[i]}`, `View ID matches tab mode: ${view}`);
  });
  
  // Test that only one view can be active at a time (simulated)
  const activeViews = views.filter(v => v === 'view-normal');
  assert(activeViews.length === 1, 'Only one view active at a time');
  
  console.log(`\n📊 View Switching: ${passed} passed, ${failed} failed`);
  return { passed, failed };
}

if (require.main === module) {
  const coreResults = runTests();
  const docResults = testDocGenerator();
  const viewResults = testViewSwitching();
  
  const totalPassed = coreResults.passed + docResults.passed + viewResults.passed;
  const totalFailed = coreResults.failed + docResults.failed + viewResults.failed;
  
  console.log(`\n📊 TOTAL: ${totalPassed} passed, ${totalFailed} failed`);
  
  if (totalFailed > 0) {
    process.exit(1);
  }
}
const fs = require('fs');
const path = require('path');
const Ajv = require('ajv');
const addFormats = require('ajv-formats');

const ajv = new Ajv({ allErrors: true, strict: false });
addFormats(ajv);

const SCHEMA_DIR = path.join(__dirname, '..', 'database', 'schemas');
const DATA_DIR = path.join(__dirname, '..', 'database');

const schemas = {
  'ps4.json': 'firmware.schema.json',
  'ps5.json': 'firmware.schema.json',
  'exploit-chains.json': 'exploit-chain.schema.json',
  'hen.json': 'hen.schema.json',
  'payloads.json': 'payload.schema.json',
  'sources.json': 'source.schema.json'
};

function loadSchema(name) {
  const schemaPath = path.join(SCHEMA_DIR, name);
  return JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
}

function loadData(name) {
  const dataPath = path.join(DATA_DIR, name);
  return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
}

function validateDatabase() {
  const results = { valid: true, errors: [] };
  
  for (const [dataFile, schemaFile] of Object.entries(schemas)) {
    try {
      const schema = loadSchema(schemaFile);
      const data = loadData(dataFile);
      
      const validate = ajv.compile(schema);
      
      if (Array.isArray(data)) {
        data.forEach((item, index) => {
          if (!validate(item)) {
            results.valid = false;
            validate.errors?.forEach(err => {
              results.errors.push(`${dataFile}[${index}]: ${err.instancePath} ${err.message}`);
            });
          }
        });
      } else {
        if (!validate(data)) {
          results.valid = false;
          validate.errors?.forEach(err => {
            results.errors.push(`${dataFile}: ${err.instancePath} ${err.message}`);
          });
        }
      }
    } catch (err) {
      results.valid = false;
      results.errors.push(`${dataFile}: ${err.message}`);
    }
  }
  
  const ps4 = loadData('ps4.json');
  const ps5 = loadData('ps5.json');
  const chains = loadData('exploit-chains.json');
  const hens = loadData('hen.json');
  const payloads = loadData('payloads.json');
  const sources = loadData('sources.json');
  
  const chainIds = new Set(chains.map(c => c.id));
  const henIds = new Set(hens.map(h => h.id));
  const payloadIds = new Set(payloads.map(p => p.payload_id));
  const sourceIds = new Set(sources.map(s => s.source_id));
  
  for (const record of [...ps4, ...ps5]) {
    if (record.recommended_chain && !chainIds.has(record.recommended_chain)) {
      results.valid = false;
      results.errors.push(`${record.console} ${record.firmware}: recommended_chain "${record.recommended_chain}" not found in exploit-chains.json`);
    }
    for (const alt of record.alternative_chains || []) {
      if (!chainIds.has(alt)) {
        results.valid = false;
        results.errors.push(`${record.console} ${record.firmware}: alternative_chain "${alt}" not found in exploit-chains.json`);
      }
    }
    for (const srcId of record.source_ids || []) {
      if (!sourceIds.has(srcId)) {
        results.valid = false;
        results.errors.push(`${record.console} ${record.firmware}: source_id "${srcId}" not found in sources.json`);
      }
    }
  }
  
  for (const chain of chains) {
    if (chain.hen_component && !henIds.has(chain.hen_component)) {
      results.valid = false;
      results.errors.push(`Chain ${chain.id}: hen_component "${chain.hen_component}" not found in hen.json`);
    }
  }
  
  for (const payload of payloads) {
    if (payload.loader && !henIds.has(payload.loader.replace('-loader', ''))) {
      results.valid = false;
      results.errors.push(`Payload ${payload.payload_id}: loader "${payload.loader}" not found in hen.json`);
    }
    // Prevent placeholder hashes in verified records
    if (payload.status === 'VERIFIED' && payload.sha256 === 'UNKNOWN') {
      results.valid = false;
      results.errors.push(`Payload ${payload.payload_id}: VERIFIED status but sha256 is UNKNOWN - cannot verify integrity`);
    }
    // Check for placeholder hash patterns
    if (payload.sha256 !== 'UNKNOWN') {
      const placeholderPattern = /^([a-f0-9])\1{63}$|^([a-f0-9]{2})\2{31}$|^([a-f0-9]{4})\3{15}$|^([a-f0-9]{8})\4{7}$/;
      if (placeholderPattern.test(payload.sha256)) {
        results.valid = false;
        results.errors.push(`Payload ${payload.payload_id}: sha256 appears to be a placeholder pattern`);
      }
    }
  }
  
  const seenFirmwares = new Map();
  for (const record of [...ps4, ...ps5]) {
    const key = `${record.console}-${record.firmware}`;
    if (seenFirmwares.has(key)) {
      results.valid = false;
      results.errors.push(`Duplicate firmware entry: ${key}`);
    }
    seenFirmwares.set(key, true);
  }
  
  return results;
}

module.exports = { validateDatabase };

if (require.main === module) {
  const result = validateDatabase();
  if (result.valid) {
    console.log('✅ All validations passed');
  } else {
    console.error('❌ Validation failed:');
    result.errors.forEach(e => console.error(`  - ${e}`));
    process.exit(1);
  }
}
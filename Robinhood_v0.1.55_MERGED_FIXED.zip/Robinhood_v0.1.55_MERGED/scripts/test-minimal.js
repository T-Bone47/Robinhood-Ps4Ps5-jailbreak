const CompatibilityEngine = require('../core/compatibility/engine');
const ExploitRouter = require('../core/exploit-router/router');

async function test() {
  const engine = new CompatibilityEngine();
  const router = new ExploitRouter(engine);
  console.log('OK');
}
test().catch(console.error);
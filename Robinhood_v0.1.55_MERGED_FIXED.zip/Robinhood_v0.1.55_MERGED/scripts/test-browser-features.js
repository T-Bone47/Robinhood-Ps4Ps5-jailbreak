const DiagnosticsValidator = require('../core/diagnostics/validator');
const { RetryManager, ExecutionStateManager, classifyError, ConsoleErrors } = require('../frontend/js/retry.js');
const fs = require('fs');
const path = require('path');

async function runTests() {
  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  ✅ ${message}`);
      passed++;
    } else {
      console.error(`  ❌ ${message}`);
      failed++;
    }
  }

  console.log('\n🧪 Testing DiagnosticsValidator...');
  
  const validator = new DiagnosticsValidator();
  
  // Test service worker check (will fail in Node, but should handle gracefully)
  try {
    const swResult = await validator.checkServiceWorker();
    assert(typeof swResult.name === 'string', 'Service Worker check returns name');
    assert(['pass', 'fail', 'warn', 'error', 'skip'].includes(swResult.status), 'SW check has valid status');
  } catch (err) {
    assert(false, `Service Worker check threw: ${err.message}`);
  }

  // Test cache storage check
  try {
    const cacheResult = await validator.checkCacheStorage();
    assert(typeof cacheResult.name === 'string', 'Cache check returns name');
    assert(['pass', 'fail', 'warn', 'error', 'skip'].includes(cacheResult.status), 'Cache check has valid status');
  } catch (err) {
    // In Node.js, window is not defined, so cache check will fail - this is expected
    assert(err.message.includes('window') || err.message.includes('caches'), 'Cache check fails gracefully in Node');
  }

  // Test WebKit environment check
  try {
    const webkitResult = await validator.checkWebKitEnvironment();
    assert(typeof webkitResult.name === 'string', 'WebKit check returns name');
  } catch (err) {
    assert(false, `WebKit check threw: ${err.message}`);
  }

  // Test memory pressure check
  try {
    const memResult = await validator.checkMemoryPressure();
    assert(typeof memResult.name === 'string', 'Memory check returns name');
  } catch (err) {
    assert(false, `Memory check threw: ${err.message}`);
  }

  // Test firmware match check
  try {
    const fwResult = await validator.checkFirmwareMatch();
    assert(typeof fwResult.name === 'string', 'Firmware check returns name');
  } catch (err) {
    assert(false, `Firmware check threw: ${err.message}`);
  }

  // Test overall runAllChecks
  try {
    const results = await validator.runAllChecks();
    assert(typeof results === 'object', 'runAllChecks returns object');
    assert(Object.keys(results).length > 0, 'runAllChecks returns results');
    assert(results.serviceWorker, 'Has serviceWorker result');
    assert(results.memoryPressure, 'Has memoryPressure result');
    assert(results.webkitEnvironment, 'Has webkitEnvironment result');
  } catch (err) {
    assert(false, `runAllChecks threw: ${err.message}`);
  }

  // Test updateCompatibility
  validator.updateCompatibility({ compatible: true, status: 'VERIFIED', reason: 'Test' });
  const compatResult = validator.results.compatibility;
  assert(compatResult?.status === 'pass', 'updateCompatibility sets pass for compatible');
  assert(compatResult?.data?.compatible === true, 'updateCompatibility stores data');

  validator.updateCompatibility({ compatible: false, status: 'UNSUPPORTED', reason: 'Test' });
  const failResult = validator.results.compatibility;
  assert(failResult?.status === 'fail', 'updateCompatibility sets fail for incompatible');

  // Test getOverallStatus
  const overall = validator.getOverallStatus();
  assert(['pass', 'warn', 'fail', 'pending'].includes(overall), 'getOverallStatus returns valid status');

  // Test getSummary
  const summary = validator.getSummary();
  assert(typeof summary.overall === 'string', 'getSummary has overall');
  assert(typeof summary.ready === 'boolean', 'getSummary has ready');
  assert(typeof summary.canExecute === 'boolean', 'getSummary has canExecute');
  assert(typeof summary.checks === 'object', 'getSummary has checks');

  console.log(`\n📊 DiagnosticsValidator: ${passed} passed, ${failed} failed`);

  // Test RetryManager
  console.log('\n🧪 Testing RetryManager...');
  let retryPassed = 0, retryFailed = 0;
  
  function rAssert(condition, message) {
    if (condition) { console.log(`  ✅ ${message}`); retryPassed++; } 
    else { console.error(`  ❌ ${message}`); retryFailed++; }
  }

  const retryManager = new RetryManager({ maxRetries: 2, retryDelay: 10 });
  
  // Test successful execution
  const successResult = await retryManager.execute(async () => 'success');
  rAssert(successResult === 'success', 'RetryManager returns success value');
  rAssert(retryManager.retryCount === 0, 'No retries on success');
  
  // Test retry on transient error
  let attemptCount = 0;
  try {
    await retryManager.execute(async () => {
      attemptCount++;
      if (attemptCount < 2) throw new Error('timeout');
      return 'recovered';
    });
    rAssert(attemptCount === 2, 'RetryManager retries on timeout');
    rAssert(retryManager.retryCount === 1, 'Retry count is 1');
  } catch (err) {
    rAssert(false, `RetryManager should have recovered: ${err.message}`);
  }

  console.log(`\n📊 RetryManager: ${retryPassed} passed, ${retryFailed} failed`);

  // Test ExecutionStateManager
  console.log('\n🧪 Testing ExecutionStateManager...');
  let statePassed = 0, stateFailed = 0;
  
  function sAssert(condition, message) {
    if (condition) { console.log(`  ✅ ${message}`); statePassed++; } 
    else { console.error(`  ❌ ${message}`); stateFailed++; }
  }

  const stateManager = new ExecutionStateManager();
  sAssert(stateManager.state === 'idle', 'Initial state is idle');
  
  stateManager.start();
  sAssert(stateManager.state === 'running', 'State changes to running on start');
  sAssert(stateManager.currentStep === 'initializing', 'First step is initializing');
  sAssert(stateManager.getDuration() >= 0, 'Duration is non-negative');
  
  stateManager.setState('running', 'webkit');
  sAssert(stateManager.currentStep === 'webkit', 'Step updated to webkit');
  sAssert(stateManager.getHistory().length >= 1, 'History records steps');
  
  stateManager.complete(true, { data: 'test' });
  sAssert(stateManager.state === 'success', 'State is success on complete');
  sAssert(stateManager.getDuration() >= 0, 'Duration recorded');
  
  const stateManager2 = new ExecutionStateManager();
  stateManager2.start();
  stateManager2.fail(new Error('test error'));
  sAssert(stateManager2.state === 'failed', 'State is failed on fail');
  sAssert(stateManager2.error?.message === 'test error', 'Error stored');
  
  // Test subscriptions
  let notified = false;
  const unsubscribe = stateManager2.subscribe(() => { notified = true; });
  stateManager2.setState('test');
  sAssert(notified, 'Subscriber notified on state change');
  unsubscribe();
  notified = false;
  stateManager2.setState('test2');
  sAssert(!notified, 'Unsubscribed listener not called');
  
  console.log(`\n📊 ExecutionStateManager: ${statePassed} passed, ${stateFailed} failed`);

  // Test Error Classification
  console.log('\n🧪 Testing Error Classification...');
  let classPassed = 0, classFailed = 0;
  
  function cAssert(condition, message) {
    if (condition) { console.log(`  ✅ ${message}`); classPassed++; } 
    else { console.error(`  ❌ ${message}`); classFailed++; }
  }

  const oomError = new Error('Out of memory');
  const oomClass = classifyError(oomError);
  cAssert(oomClass.type === ConsoleErrors.OUT_OF_MEMORY, 'OOM classified correctly');
  cAssert(oomClass.recoverable === true, 'OOM is recoverable');
  cAssert(oomClass.suggestion.includes('Close other browser tabs'), 'OOM has suggestion');

  const timeoutError = new Error('Request timeout');
  const timeoutClass = classifyError(timeoutError);
  cAssert(timeoutClass.type === ConsoleErrors.TIMEOUT, 'Timeout classified correctly');
  cAssert(timeoutClass.recoverable === true, 'Timeout is recoverable');

  const networkError = new Error('Network request failed');
  const netClass = classifyError(networkError);
  cAssert(netClass.type === ConsoleErrors.NETWORK_ERROR, 'Network error classified correctly');

  const securityError = new Error('CORS policy blocked');
  const secClass = classifyError(securityError);
  cAssert(secClass.type === ConsoleErrors.SECURITY_ERROR, 'Security error classified');
  cAssert(secClass.recoverable === false, 'Security error not recoverable');

  const unknownError = new Error('Something weird happened');
  const unkClass = classifyError(unknownError);
  cAssert(unkClass.type === ConsoleErrors.UNKNOWN, 'Unknown error classified');
  cAssert(unkClass.recoverable === true, 'Unknown defaults to recoverable');

  console.log(`\n📊 Error Classification: ${classPassed} passed, ${classFailed} failed`);

  // Test package-release validation (mock)
  console.log('\n🧪 Testing Release Bundler Logic...');
  let bundlePassed = 0, bundleFailed = 0;
  
  function bAssert(condition, message) {
    if (condition) { console.log(`  ✅ ${message}`); bundlePassed++; } 
    else { console.error(`  ❌ ${message}`); bundleFailed++; }
  }

  // Test manifest generation logic
  const crypto = require('crypto');
  const testContent = Buffer.from('test content');
  const hash = crypto.createHash('sha256').update(testContent).digest('hex');
  bAssert(hash.length === 64, 'SHA-256 produces 64-char hex');
  bAssert(/^[a-f0-9]+$/.test(hash), 'SHA-256 is hex');

  // Test manifest structure
  const manifest = {
    files: {
      'index.html': { size: 100, sha256: 'abc', version: '1.0.0' },
    },
    version: '1.0.0',
    generated: new Date().toISOString(),
  };
  bAssert(typeof manifest.version === 'string', 'Manifest has version');
  bAssert(typeof manifest.generated === 'string', 'Manifest has generated timestamp');
  bAssert(typeof manifest.files === 'object', 'Manifest has files object');
  bAssert(manifest.files['index.html'].sha256 === 'abc', 'File entry has hash');

  console.log(`\n📊 Release Bundler: ${bundlePassed} passed, ${bundleFailed} failed`);

  const totalPassed = passed + retryPassed + statePassed + classPassed + bundlePassed;
  const totalFailed = failed + retryFailed + stateFailed + classFailed + bundleFailed;
  
  console.log(`\n📊 TOTAL NEW TESTS: ${totalPassed} passed, ${totalFailed} failed`);
  
  if (totalFailed > 0) {
    process.exit(1);
  }
  
  return { passed: totalPassed, failed: totalFailed };
}

runTests().catch(err => {
  console.error('Test error:', err);
  process.exit(1);
});
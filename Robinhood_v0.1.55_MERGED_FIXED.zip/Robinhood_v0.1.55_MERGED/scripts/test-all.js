const { spawnSync } = require('child_process');

const suites = [
  ['Robinhood compatibility regression', 'node', ['tests/compatibility/test-router.js']],
  ['Nemotron core hardening', 'node', ['scripts/test.js']],
  ['Third-party adapter audit', 'node', ['scripts/test-third-party.js']],
  ['Browser feature audit', 'node', ['scripts/test-browser-features.js']],
  ['Failure-mode audit', 'node', ['scripts/test-failure-modes.js']]
];

let failed = false;
for (const [name, cmd, args] of suites) {
  console.log(`\n=== ${name} ===`);
  const result = spawnSync(cmd, args, { stdio: 'inherit', shell: process.platform === 'win32' });
  if (result.status !== 0) {
    failed = true;
    console.error(`❌ ${name} failed (exit ${result.status})`);
  } else {
    console.log(`✅ ${name} passed`);
  }
}
if (failed) process.exit(1);
console.log('\n✅ Combined v0.1.55 test runner completed.');

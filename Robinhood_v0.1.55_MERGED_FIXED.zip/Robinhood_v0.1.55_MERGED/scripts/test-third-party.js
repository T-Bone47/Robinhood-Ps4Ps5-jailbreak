const PayloadManager = require('../core/payload/manager');
const ElfLoaderAdapter = require('../core/payload/loaders/ElfLoaderAdapter');
const BinLoaderAdapter = require('../core/payload/loaders/BinLoaderAdapter');
const PSFreeAdapter = require('../core/exploit-router/adapters/PSFreeAdapter');
const LapseKernelAdapter = require('../core/exploit-router/adapters/LapseKernelAdapter');
const { UmtxWebKitAdapter, UmtxKernelAdapter, UmtxChainAdapter } = require('../core/exploit-router/adapters/UmtxAdapter');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

async function runTests() {
  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  ✅ ${message}`);
      passed++;
    } else {
      console.error(`  ❌ ${message}`);
      failed++;
    }
  }

  console.log('\n🧪 Testing PayloadManager...');
  
  const pm = new PayloadManager();
  
  // Test supported formats
  assert(pm.getSupportedFormats().includes('BIN'), 'Supports BIN format');
  assert(pm.getSupportedFormats().includes('ELF'), 'Supports ELF format');
  assert(pm.getSupportedLoaders().includes('BIN'), 'Has BIN loader');
  assert(pm.getSupportedLoaders().includes('ELF'), 'Has ELF loader');

  // Test adapter retrieval
  const binAdapter = pm.getAdapter('BIN');
  const elfAdapter = pm.getAdapter('ELF');
  assert(binAdapter !== null, 'Can retrieve BIN adapter');
  assert(elfAdapter !== null, 'Can retrieve ELF adapter');

  // Test loader retrieval
  const binLoaderRetrieved = pm.getLoader('BIN');
  const elfLoaderRetrieved = pm.getLoader('ELF');
  assert(binLoaderRetrieved !== null, 'Can retrieve BIN loader');
  assert(elfLoaderRetrieved !== null, 'Can retrieve ELF loader');

  // Test payload database loading
  await pm.loadPayloadsDB();
  assert(pm.payloadsDB !== null, 'Payloads DB loaded');
  assert(pm.payloadsDB.length > 0, 'Payloads DB has entries');
  
  // Test findPayload
  const goldhen = pm.findPayload('goldhen-bin-2.4');
  assert(goldhen !== null, 'Can find goldhen-bin-2.4');
  assert(goldhen.format === 'BIN', 'GoldHEN is BIN format');
  
  const ps5hen = pm.findPayload('ps5-hen-elf-4xx');
  assert(ps5hen !== null, 'Can find ps5-hen-elf-4xx');
  assert(ps5hen.format === 'ELF', 'PS5 HEN is ELF format');

  console.log(`\n📊 PayloadManager: ${passed} passed, ${failed} failed`);

  // Test checksum verification
  console.log('\n🧪 Testing Checksum Verification...');
  
  const testData = Buffer.from('test payload data');
  const correctHash = crypto.createHash('sha256').update(testData).digest('hex');
  const wrongHash = 'a'.repeat(64);

  const checksumValid = await pm.verifyChecksum(testData, correctHash);
  assert(checksumValid === true, 'Correct checksum validates');
  
  const checksumInvalid = await pm.verifyChecksum(testData, wrongHash);
  assert(checksumInvalid === false, 'Wrong checksum rejects');
  
  console.log(`\n📊 Checksum Verification: ${passed} passed, ${failed} failed`);

  // Test Concrete Exploit Adapters
  console.log('\n🧪 Testing Concrete Exploit Adapters...');
  
  // PSFree Adapter: repository intentionally omits third-party source.
  const psfree = new PSFreeAdapter();
  let result = await psfree.initialize();
  assert(result.success === false, 'PSFreeAdapter blocks initialization when third-party source is absent');
  assert(result.state === 'SIMULATED', 'PSFreeAdapter reports SIMULATED state');
  let detect = await psfree.detect();
  assert(detect.success === false, 'PSFreeAdapter detect is gated without source');
  let exec = await psfree.execute();
  assert(exec.success === false, 'PSFreeAdapter execute is gated');
  assert(exec.simulated === true, 'PSFreeAdapter gate identifies simulated state');
  let res = await psfree.result();
  assert(res.success === false, 'PSFreeAdapter result is not ready');
  await psfree.cleanup();

  // Lapse Kernel Adapter
  const lapse = new LapseKernelAdapter();
  result = await lapse.initialize();
  assert(result.success === false, 'LapseKernelAdapter blocks initialization when source is absent');
  assert(result.state === 'SIMULATED', 'LapseKernelAdapter reports SIMULATED state');
  exec = await lapse.execute({ userlandContext: { userland: true } });
  assert(exec.success === false, 'LapseKernelAdapter execute is gated');
  assert(exec.simulated === true, 'LapseKernelAdapter gate identifies simulated state');
  status = await lapse.status();
  assert(status.kernel_read_write === false, 'LapseKernelAdapter status remains non-ready');
  assert(status.state === 'SIMULATED', 'LapseKernelAdapter status reports SIMULATED');
  await lapse.cleanup();

  // UMTX Adapters
  const umtxChain = new UmtxChainAdapter();
  result = await umtxChain.initialize();
  assert(result.success === false, 'UMTX chain blocks initialization when source is absent');
  assert(result.webkit.success === false, 'UMTX WebKit source gate is enforced');
  assert(result.kernel.success === false, 'UMTX Kernel source gate is enforced');

  let chain = await umtxChain.executeFullChain();
  assert(chain.success === false, 'UMTX full chain is gated without source');
  assert(['detect', 'webkit'].includes(chain.stage), 'UMTX failure identifies gated stage');

  await umtxChain.cleanup();

  console.log(`\n📊 Concrete Adapters: ${passed} passed, ${failed} failed`);

  // Test Payload Loaders
  console.log('\n🧪 Testing Payload Loaders...');
  
  // ELF Loader
  const elfLoader = new ElfLoaderAdapter();
  const fakeElf = Buffer.alloc(100);
  fakeElf.writeUInt32BE(0x7F454C46, 0); // ELF magic
  fakeElf.writeUInt8(2, 4); // 64-bit
  fakeElf.writeUInt16LE(0x3E, 18); // x86-64

  let elfValid = await elfLoader.validate(fakeElf);
  assert(elfValid === true, 'ELF loader validates correct ELF');
  
  // Test invalid ELF
  const fakeBad = Buffer.from('not an elf');
  try {
    await elfLoader.validate(fakeBad);
    assert(false, 'ELF loader should reject bad magic');
  } catch (err) {
    assert(err.message.includes('Invalid ELF magic'), 'ELF loader rejects bad magic');
  }
  
  // Test ELF loader prepare
  let elfPrepared = await elfLoader.prepare(fakeElf);
  assert(elfPrepared instanceof Uint8Array, 'ELF loader prepares Uint8Array');
  
  // Test connection simulation
  let elfConn = await elfLoader.connect('192.168.1.100', 9021);
  assert(elfConn.success, 'ELF loader connects');
  assert(elfConn.port === 9021, 'ELF loader uses default port 9021');
  
  let elfSent = await elfLoader.sendPayload(fakeElf);
  assert(elfSent.success, 'ELF loader sends payload');
  assert(elfSent.bytes_sent === fakeElf.length, 'ELF loader sends correct bytes');
  
  await elfLoader.disconnect();

  // BIN Loader
  const binLoader = new BinLoaderAdapter();
  const fakeBin = Buffer.alloc(256);
  
  let binValid = await binLoader.validate(fakeBin);
  assert(binValid === true, 'BIN loader validates correct BIN');
  
  // Test too small
  const tinyBin = Buffer.alloc(2);
  try {
    await binLoader.validate(tinyBin);
    assert(false, 'BIN loader should reject too small');
  } catch (err) {
    assert(err.message.includes('too small'), 'BIN loader rejects too small');
  }
  
  // Test too large
  const hugeBin = Buffer.alloc(2 * 1024 * 1024);
  try {
    await binLoader.validate(hugeBin);
    assert(false, 'BIN loader should reject too large');
  } catch (err) {
    assert(err.message.includes('exceeds maximum'), 'BIN loader rejects too large');
  }
  
  let binPrepared = await binLoader.prepare(fakeBin);
  assert(binPrepared instanceof Uint8Array, 'BIN loader prepares Uint8Array');
  
  let binConn = await binLoader.connect('192.168.1.100', 9020);
  assert(binConn.success, 'BIN loader connects');
  assert(binConn.port === 9020, 'BIN loader uses default port 9020');
  
  let binSent = await binLoader.sendPayload(fakeBin, '192.168.1.100', 9020);
  assert(binSent.success, 'BIN loader sends payload');
  
  await binLoader.disconnect();

  console.log(`\n📊 Payload Loaders: ${passed} passed, ${failed} failed`);
  
  console.log(`\n📊 TOTAL: ${passed} passed, ${failed} failed`);
  if (failed > 0) process.exit(1);
}

runTests().catch(err => {
  console.error('Test error:', err);
  process.exit(1);
});
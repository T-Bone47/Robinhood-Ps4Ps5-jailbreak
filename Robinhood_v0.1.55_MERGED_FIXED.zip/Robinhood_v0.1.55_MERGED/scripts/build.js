const fs = require('fs');
const path = require('path');
const glob = require('glob');
const { validateDatabase } = require('./validate');
const CacheManager = require('../core/cache/manager');
const { generateDocs } = require('./generate-docs');

const DIST_DIR = path.join(__dirname, '..', 'dist');
const SRC_DIR = path.join(__dirname, '..');
const DOCS_DIR = path.join(__dirname, '..', 'docs');

async function build() {
  console.log('🏗️  Building Robinhood...');
  
  if (fs.existsSync(DIST_DIR)) {
    fs.rmSync(DIST_DIR, { recursive: true });
  }
  fs.mkdirSync(DIST_DIR, { recursive: true });
  fs.mkdirSync(path.join(DIST_DIR, 'database'), { recursive: true });
  fs.mkdirSync(path.join(DIST_DIR, 'cache'), { recursive: true });
  fs.mkdirSync(path.join(DIST_DIR, 'frontend', 'css'), { recursive: true });
  fs.mkdirSync(path.join(DIST_DIR, 'frontend', 'js'), { recursive: true });
  fs.mkdirSync(path.join(DIST_DIR, 'frontend', 'assets', 'icons'), { recursive: true });
  fs.mkdirSync(path.join(DIST_DIR, 'frontend', 'assets', 'images'), { recursive: true });
  fs.mkdirSync(DOCS_DIR, { recursive: true });

  console.log('✓ Validating database...');
  const validation = validateDatabase();
  if (!validation.valid) {
    console.error('❌ Database validation failed:');
    validation.errors.forEach(e => console.error(`  - ${e}`));
    process.exit(1);
  }
  console.log('✓ Database valid');

  console.log('✓ Copying database files...');
  const dbFiles = ['ps4.json', 'ps5.json', 'exploit-chains.json', 'hen.json', 'payloads.json', 'sources.json'];
  for (const file of dbFiles) {
    fs.copyFileSync(
      path.join(SRC_DIR, 'database', file),
      path.join(DIST_DIR, 'database', file)
    );
  }

  console.log('✓ Copying frontend assets...');
  const frontendFiles = glob.sync('frontend/**/*', { cwd: SRC_DIR, nodir: true });
  for (const file of frontendFiles) {
    const src = path.join(SRC_DIR, file);
    const dest = path.join(DIST_DIR, file);
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(src, dest);
  }
  
  // Copy service worker
  fs.copyFileSync(
    path.join(SRC_DIR, 'frontend', 'js', 'service-worker.js'),
    path.join(DIST_DIR, 'frontend', 'js', 'service-worker.js')
  );
  
  // Copy root index.html
  fs.copyFileSync(
    path.join(SRC_DIR, 'frontend', 'index.html'),
    path.join(DIST_DIR, 'index.html')
  );

  console.log('✓ Generating cache manifest...');
  const cache = new CacheManager(path.join(DIST_DIR, 'cache'));
  await cache.init();
  
  const allFiles = glob.sync('**/*', { cwd: DIST_DIR, nodir: true });
  for (const file of allFiles) {
    if (file.startsWith('cache/')) continue;
    const fullPath = path.join(DIST_DIR, file);
    const content = fs.readFileSync(fullPath);
    await cache.addFile(file, content);
  }
  await cache.saveManifest();

  console.log('✓ Writing version info...');
  const versionInfo = {
    version: '1.0.0',
    build_date: new Date().toISOString(),
    database_version: '1.0',
    compatibility: {
      ps4_firmwares: dbFiles.includes('ps4.json') ? 'loaded' : 'missing',
      ps5_firmwares: dbFiles.includes('ps5.json') ? 'loaded' : 'missing',
      exploit_chains: dbFiles.includes('exploit-chains.json') ? 'loaded' : 'missing'
    }
  };
  fs.writeFileSync(
    path.join(DIST_DIR, 'version.json'),
    JSON.stringify(versionInfo, null, 2)
  );

  console.log('✓ Build complete!');
  console.log(`📦 Output: ${DIST_DIR}`);
  
  const stats = fs.statSync(path.join(DIST_DIR, 'index.html'));
  console.log(`📄 index.html: ${stats.size} bytes`);
  
  return { success: true, distDir: DIST_DIR };
}

if (require.main === module) {
  build().catch(err => {
    console.error('❌ Build failed:', err);
    process.exit(1);
  });
}

module.exports = { build };